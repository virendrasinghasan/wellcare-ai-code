# Wellcare AI Agent Upgrade

## Goal
Turn the existing `/coach` experience into a real authenticated app agent that reads and changes the current user’s Supabase-backed Wellcare data, while preserving the existing UI, personality, local-first behavior, and routes.

## Implementation

### 1. Secure agent backend
- Keep `coach.functions.ts` as a thin authenticated `createServerFn` wrapper using `requireSupabaseAuth`.
- Add a server-only agent orchestrator that sends the tool catalog to Gemini, handles multi-step function calls, and executes only allow-listed tools.
- Validate every tool argument with Zod, scope every query by the authenticated user, and rely on existing RLS policies.
- Register the existing Supabase bearer-token middleware in `src/start.ts` so protected server functions receive the active session.
- Return structured, backend-confirmed results only; failures identify exactly which action was not applied.

### 2. Real action executors
Implement server-side reads and mutations against the existing tables for:
- Workout programs and exercises: create/list/read, add/remove/update/reorder exercises, activate plans, log and summarize sessions.
- Nutrition: search foods, log/remove meal items, create custom foods/recipes, read daily totals, and update nutrition targets.
- Trackers and dashboard: enable/disable/pin/reorder trackers, goals, and values for water, steps, weight, sleep, heart rate, respiratory rate, and glucose.
- Goals and reminders: create, list, update, complete/disable, and delete where supported.
- Profile and reports: read/update profile fields and generate progress summaries from real stored activity.
- Navigation: return safe route actions from a fixed route allow-list.

Each mutation will write an `assistant_actions` audit record with prior/new values. Reversible single-object mutations will expose undo; unsafe or ambiguous reversals will fail safely rather than guessing.

### 3. Confirmation and safety policy
- Level 1 actions execute immediately after validation.
- Level 2 actions return a preview and require an explicit Confirm click before execution (plan replacement/deletion and nutrition target changes).
- Level 3 actions remain unavailable through chat.
- Enforce medical boundaries in both the model prompt and executors: tracking/organization is allowed; diagnosis, prescribing, dose changes, account/security/payment actions, and external health-data sharing are not.

### 4. Coach UI integration
- Preserve the current full-screen coach design and conversation persistence.
- Render structured action buttons such as Open Workout, View Nutrition, Open Tracker, and Undo.
- Add inline confirmation cards for pending Level 2 actions.
- Apply confirmed local mirror operations to the existing Wellcare store so nutrition/water/profile changes appear immediately, while Supabase remains the source of truth for agent mutations.
- Keep normal back navigation and use TanStack Router for all route actions.

### 5. App data consistency
- Update workout/nutrition/tracker surfaces only where needed to read agent-created Supabase records instead of showing only static/local data.
- Preserve existing offline/local behavior and merge server data without deleting current local entries.
- Add database schema only for capabilities that have no current table (for example tasks or persistent meal-plan/recipe structure), with grants and user-scoped RLS in the same migration.

### 6. Verification
- Verify the stale `src/lib/utils.ts(8,7)` report against the current file; it currently has six lines, so no speculative edit will be made there.
- Test representative authenticated flows: create a 4-day plan, replace an exercise, log food/water, pin a dashboard tracker, create a reminder, request a progress summary, confirm a Level 2 change, and undo a supported action.
- Confirm unauthorized calls fail, cross-user data cannot be read or modified, failed tools are reported honestly, and existing coach navigation/chat persistence still work.

## Technical notes
- Gemini receives only tool schemas and bounded context; it never receives Supabase credentials or direct database access.
- `*.functions.ts` files contain only imports, erased types, and exported server-function declarations; runtime helpers live in imported server-only modules.
- All returned values are serializable DTOs suitable for TanStack server functions.
