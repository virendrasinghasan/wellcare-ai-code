# Agent upgrade roadmap

- [x] Secure authenticated agent server function and Gemini tool loop
- [x] Real Supabase tool executors with validation, audit, and confirmations
- [x] Coach UI structured actions, confirmations, navigation, and local sync
- [x] Verify type/build health and unauthenticated route behavior
- [ ] Authenticated end-to-end action verification (external auth session unavailable in sandbox)
