-- Keep the text-search extension out of the public schema.
CREATE SCHEMA IF NOT EXISTS extensions;
GRANT USAGE ON SCHEMA extensions TO anon, authenticated, service_role;

DROP INDEX IF EXISTS public.foods_name_trgm_idx;
DROP INDEX IF EXISTS public.foods_brand_trgm_idx;
DROP EXTENSION IF EXISTS pg_trgm;

CREATE EXTENSION IF NOT EXISTS pg_trgm WITH SCHEMA extensions;

CREATE INDEX IF NOT EXISTS foods_name_trgm_idx ON public.foods USING gin (name extensions.gin_trgm_ops);
CREATE INDEX IF NOT EXISTS foods_brand_trgm_idx ON public.foods USING gin (brand extensions.gin_trgm_ops);