-- Replace the partial unique barcode index with a real unique constraint so
-- scanned products can be cached with a proper upsert.
DROP INDEX IF EXISTS public.foods_barcode_key;
ALTER TABLE public.foods
  ADD CONSTRAINT foods_barcode_unique UNIQUE (barcode);