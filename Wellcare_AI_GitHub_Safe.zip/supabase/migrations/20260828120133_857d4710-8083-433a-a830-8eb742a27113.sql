-- Public (signed-out) read access to the shared food catalogue, plus text search support.
GRANT SELECT ON public.foods TO anon;

DROP POLICY IF EXISTS foods_select_public_anon ON public.foods;
CREATE POLICY foods_select_public_anon
  ON public.foods FOR SELECT TO anon
  USING (is_public);

CREATE EXTENSION IF NOT EXISTS pg_trgm;
CREATE INDEX IF NOT EXISTS foods_name_trgm_idx ON public.foods USING gin (name gin_trgm_ops);
CREATE INDEX IF NOT EXISTS foods_brand_trgm_idx ON public.foods USING gin (brand gin_trgm_ops);