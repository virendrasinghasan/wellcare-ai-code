-- ============ shared enums ============
CREATE TYPE public.data_source AS ENUM ('manual', 'device', 'ai');
CREATE TYPE public.medicine_status AS ENUM ('taken', 'missed', 'skipped');
CREATE TYPE public.glucose_unit AS ENUM ('mg_dl', 'mmol_l');

-- ============ tracker preferences ============
CREATE TABLE public.tracker_prefs (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  user_id uuid NOT NULL REFERENCES auth.users(id) ON DELETE CASCADE,
  tracker_key text NOT NULL,
  enabled boolean NOT NULL DEFAULT true,
  pinned_home boolean NOT NULL DEFAULT false,
  position integer NOT NULL DEFAULT 0,
  created_at timestamptz NOT NULL DEFAULT now(),
  updated_at timestamptz NOT NULL DEFAULT now(),
  UNIQUE (user_id, tracker_key)
);
GRANT SELECT, INSERT, UPDATE, DELETE ON public.tracker_prefs TO authenticated;
GRANT ALL ON public.tracker_prefs TO service_role;
ALTER TABLE public.tracker_prefs ENABLE ROW LEVEL SECURITY;
CREATE POLICY tracker_prefs_own ON public.tracker_prefs FOR ALL TO authenticated
  USING (user_id = auth.uid()) WITH CHECK (user_id = auth.uid());
CREATE TRIGGER tracker_prefs_updated_at BEFORE UPDATE ON public.tracker_prefs
  FOR EACH ROW EXECUTE FUNCTION public.update_updated_at_column();

-- ============ sleep ============
CREATE TABLE public.sleep_entries (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  user_id uuid NOT NULL REFERENCES auth.users(id) ON DELETE CASCADE,
  logged_on date NOT NULL DEFAULT ((now() AT TIME ZONE 'utc'))::date,
  bedtime timestamptz,
  wake_time timestamptz,
  minutes integer NOT NULL DEFAULT 0,
  quality smallint,
  notes text,
  source public.data_source NOT NULL DEFAULT 'manual',
  created_at timestamptz NOT NULL DEFAULT now(),
  updated_at timestamptz NOT NULL DEFAULT now()
);
CREATE INDEX sleep_entries_user_day ON public.sleep_entries (user_id, logged_on DESC);
GRANT SELECT, INSERT, UPDATE, DELETE ON public.sleep_entries TO authenticated;
GRANT ALL ON public.sleep_entries TO service_role;
ALTER TABLE public.sleep_entries ENABLE ROW LEVEL SECURITY;
CREATE POLICY sleep_entries_own ON public.sleep_entries FOR ALL TO authenticated
  USING (user_id = auth.uid()) WITH CHECK (user_id = auth.uid());
CREATE TRIGGER sleep_entries_updated_at BEFORE UPDATE ON public.sleep_entries
  FOR EACH ROW EXECUTE FUNCTION public.update_updated_at_column();

-- ============ medicines ============
CREATE TABLE public.medicines (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  user_id uuid NOT NULL REFERENCES auth.users(id) ON DELETE CASCADE,
  name text NOT NULL,
  dose text,
  unit text,
  frequency text NOT NULL DEFAULT 'daily',
  times text[] NOT NULL DEFAULT '{}',
  start_date date NOT NULL DEFAULT ((now() AT TIME ZONE 'utc'))::date,
  end_date date,
  reminder_enabled boolean NOT NULL DEFAULT false,
  notes text,
  is_active boolean NOT NULL DEFAULT true,
  created_at timestamptz NOT NULL DEFAULT now(),
  updated_at timestamptz NOT NULL DEFAULT now()
);
CREATE INDEX medicines_user ON public.medicines (user_id, is_active);
GRANT SELECT, INSERT, UPDATE, DELETE ON public.medicines TO authenticated;
GRANT ALL ON public.medicines TO service_role;
ALTER TABLE public.medicines ENABLE ROW LEVEL SECURITY;
CREATE POLICY medicines_own ON public.medicines FOR ALL TO authenticated
  USING (user_id = auth.uid()) WITH CHECK (user_id = auth.uid());
CREATE TRIGGER medicines_updated_at BEFORE UPDATE ON public.medicines
  FOR EACH ROW EXECUTE FUNCTION public.update_updated_at_column();

CREATE TABLE public.medicine_logs (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  user_id uuid NOT NULL REFERENCES auth.users(id) ON DELETE CASCADE,
  medicine_id uuid NOT NULL REFERENCES public.medicines(id) ON DELETE CASCADE,
  logged_on date NOT NULL DEFAULT ((now() AT TIME ZONE 'utc'))::date,
  scheduled_time text,
  status public.medicine_status NOT NULL DEFAULT 'taken',
  taken_at timestamptz,
  created_at timestamptz NOT NULL DEFAULT now(),
  UNIQUE (medicine_id, logged_on, scheduled_time)
);
CREATE INDEX medicine_logs_user_day ON public.medicine_logs (user_id, logged_on DESC);
GRANT SELECT, INSERT, UPDATE, DELETE ON public.medicine_logs TO authenticated;
GRANT ALL ON public.medicine_logs TO service_role;
ALTER TABLE public.medicine_logs ENABLE ROW LEVEL SECURITY;
CREATE POLICY medicine_logs_own ON public.medicine_logs FOR ALL TO authenticated
  USING (user_id = auth.uid()) WITH CHECK (user_id = auth.uid());

-- ============ vitals ============
CREATE TABLE public.heart_rate_entries (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  user_id uuid NOT NULL REFERENCES auth.users(id) ON DELETE CASCADE,
  bpm integer NOT NULL,
  is_resting boolean NOT NULL DEFAULT false,
  context text,
  measured_at timestamptz NOT NULL DEFAULT now(),
  source public.data_source NOT NULL DEFAULT 'manual',
  created_at timestamptz NOT NULL DEFAULT now()
);
CREATE INDEX heart_rate_user_time ON public.heart_rate_entries (user_id, measured_at DESC);
GRANT SELECT, INSERT, UPDATE, DELETE ON public.heart_rate_entries TO authenticated;
GRANT ALL ON public.heart_rate_entries TO service_role;
ALTER TABLE public.heart_rate_entries ENABLE ROW LEVEL SECURITY;
CREATE POLICY heart_rate_entries_own ON public.heart_rate_entries FOR ALL TO authenticated
  USING (user_id = auth.uid()) WITH CHECK (user_id = auth.uid());

CREATE TABLE public.respiratory_rate_entries (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  user_id uuid NOT NULL REFERENCES auth.users(id) ON DELETE CASCADE,
  breaths_per_min integer NOT NULL,
  context text,
  measured_at timestamptz NOT NULL DEFAULT now(),
  source public.data_source NOT NULL DEFAULT 'manual',
  created_at timestamptz NOT NULL DEFAULT now()
);
CREATE INDEX respiratory_user_time ON public.respiratory_rate_entries (user_id, measured_at DESC);
GRANT SELECT, INSERT, UPDATE, DELETE ON public.respiratory_rate_entries TO authenticated;
GRANT ALL ON public.respiratory_rate_entries TO service_role;
ALTER TABLE public.respiratory_rate_entries ENABLE ROW LEVEL SECURITY;
CREATE POLICY respiratory_rate_entries_own ON public.respiratory_rate_entries FOR ALL TO authenticated
  USING (user_id = auth.uid()) WITH CHECK (user_id = auth.uid());

CREATE TABLE public.blood_glucose_entries (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  user_id uuid NOT NULL REFERENCES auth.users(id) ON DELETE CASCADE,
  value numeric NOT NULL,
  unit public.glucose_unit NOT NULL DEFAULT 'mg_dl',
  context text,
  measured_at timestamptz NOT NULL DEFAULT now(),
  source public.data_source NOT NULL DEFAULT 'manual',
  created_at timestamptz NOT NULL DEFAULT now()
);
CREATE INDEX glucose_user_time ON public.blood_glucose_entries (user_id, measured_at DESC);
GRANT SELECT, INSERT, UPDATE, DELETE ON public.blood_glucose_entries TO authenticated;
GRANT ALL ON public.blood_glucose_entries TO service_role;
ALTER TABLE public.blood_glucose_entries ENABLE ROW LEVEL SECURITY;
CREATE POLICY blood_glucose_entries_own ON public.blood_glucose_entries FOR ALL TO authenticated
  USING (user_id = auth.uid()) WITH CHECK (user_id = auth.uid());

-- ============ steps ============
CREATE TABLE public.step_entries (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  user_id uuid NOT NULL REFERENCES auth.users(id) ON DELETE CASCADE,
  logged_on date NOT NULL DEFAULT ((now() AT TIME ZONE 'utc'))::date,
  steps integer NOT NULL DEFAULT 0,
  source public.data_source NOT NULL DEFAULT 'manual',
  created_at timestamptz NOT NULL DEFAULT now(),
  updated_at timestamptz NOT NULL DEFAULT now(),
  UNIQUE (user_id, logged_on, source)
);
GRANT SELECT, INSERT, UPDATE, DELETE ON public.step_entries TO authenticated;
GRANT ALL ON public.step_entries TO service_role;
ALTER TABLE public.step_entries ENABLE ROW LEVEL SECURITY;
CREATE POLICY step_entries_own ON public.step_entries FOR ALL TO authenticated
  USING (user_id = auth.uid()) WITH CHECK (user_id = auth.uid());
CREATE TRIGGER step_entries_updated_at BEFORE UPDATE ON public.step_entries
  FOR EACH ROW EXECUTE FUNCTION public.update_updated_at_column();

-- ============ tracker goals ============
CREATE TABLE public.tracker_goals (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  user_id uuid NOT NULL REFERENCES auth.users(id) ON DELETE CASCADE,
  tracker_key text NOT NULL,
  target numeric NOT NULL,
  unit text,
  period text NOT NULL DEFAULT 'daily',
  created_at timestamptz NOT NULL DEFAULT now(),
  updated_at timestamptz NOT NULL DEFAULT now(),
  UNIQUE (user_id, tracker_key)
);
GRANT SELECT, INSERT, UPDATE, DELETE ON public.tracker_goals TO authenticated;
GRANT ALL ON public.tracker_goals TO service_role;
ALTER TABLE public.tracker_goals ENABLE ROW LEVEL SECURITY;
CREATE POLICY tracker_goals_own ON public.tracker_goals FOR ALL TO authenticated
  USING (user_id = auth.uid()) WITH CHECK (user_id = auth.uid());
CREATE TRIGGER tracker_goals_updated_at BEFORE UPDATE ON public.tracker_goals
  FOR EACH ROW EXECUTE FUNCTION public.update_updated_at_column();