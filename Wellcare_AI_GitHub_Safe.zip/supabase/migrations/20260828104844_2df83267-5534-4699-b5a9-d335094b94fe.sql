ALTER TABLE public.foods
  ADD COLUMN IF NOT EXISTS image_url text,
  ADD COLUMN IF NOT EXISTS ingredients text,
  ADD COLUMN IF NOT EXISTS category text,
  ADD COLUMN IF NOT EXISTS country text,
  ADD COLUMN IF NOT EXISTS source_product_id text,
  ADD COLUMN IF NOT EXISTS serving_unit text NOT NULL DEFAULT 'g';

CREATE UNIQUE INDEX IF NOT EXISTS foods_barcode_key
  ON public.foods (barcode)
  WHERE barcode IS NOT NULL;