// @lovable.dev/vite-tanstack-config already includes the following — do NOT add them manually
// or the app will break with duplicate plugins:
//   - TanStack devtools (dev-only, first), tanstackStart, viteReact, tailwindcss, tsConfigPaths,
//     nitro (build-only using cloudflare as a default target), VITE_* env injection, @ path alias,
//     React/TanStack dedupe, error logger plugins, and sandbox detection (port/host/strictPort).
// You can pass additional config via defineConfig({ vite: { ... }, etc... }) if needed.
import { fileURLToPath } from "node:url";
import { defineConfig } from "@lovable.dev/vite-tanstack-config";

export default defineConfig({
  tanstackStart: {
    // Redirect TanStack Start's bundled server entry to src/server.ts (our SSR error wrapper).
    // nitro/vite builds from this
    server: { entry: "server" },
  },
  vite: {
    resolve: {
      alias: {
        // @tensorflow-models/pose-detection statically imports `{ Pose }` from
        // @mediapipe/pose, but that package has no ESM exports and breaks the
        // Rolldown build. Coach Cam only uses the tfjs (MoveNet) runtime, so
        // alias it to a stub. See src/shims/mediapipe-pose-stub.ts.
        "@mediapipe/pose": fileURLToPath(
          new URL("./src/shims/mediapipe-pose-stub.ts", import.meta.url),
        ),
      },
    },
  },
});
