import { cn } from "@/lib/utils";

interface MacroBarProps {
  label: string;
  value: number;
  target: number;
  tone: "protein" | "carbs" | "fat" | "water";
  unit?: string;
}

const trackTone: Record<MacroBarProps["tone"], string> = {
  protein: "bg-protein",
  carbs: "bg-carbs",
  fat: "bg-fat",
  water: "bg-water",
};

export function MacroBar({ label, value, target, tone, unit = "g" }: MacroBarProps) {
  const pct = target > 0 ? Math.min((value / target) * 100, 100) : 0;

  return (
    <div className="min-w-0 space-y-2">
      <span className="block text-[12px] font-semibold text-muted-foreground">{label}</span>
      <div className="h-1.5 w-full overflow-hidden rounded-full bg-muted">
        <div
          className={cn("h-full rounded-full transition-all duration-700 ease-out", trackTone[tone])}
          style={{ width: `${pct}%` }}
        />
      </div>
      <span className="block text-[14px] text-metric">
        {Math.round(value)}
        <span className="text-[12px] font-semibold text-muted-foreground">
          {" / "}
          {Math.round(target)}
          {unit}
        </span>
      </span>
    </div>
  );
}
