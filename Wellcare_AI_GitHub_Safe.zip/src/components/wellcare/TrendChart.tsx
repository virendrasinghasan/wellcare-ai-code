/**
 * Lightweight SVG trend chart. No fake data: when there is nothing to plot the
 * caller renders an empty state instead of this component.
 */
export interface TrendPoint {
  label: string;
  value: number;
}

export function TrendChart({
  points,
  goal,
  className,
}: {
  points: TrendPoint[];
  goal?: number | null;
  className?: string;
}) {
  const w = 320;
  const h = 120;
  const pad = 8;
  const values = points.map((p) => p.value);
  const max = Math.max(...values, goal ?? 0) * 1.1 || 1;
  const min = 0;
  const span = Math.max(max - min, 1);

  const x = (i: number) =>
    points.length === 1 ? w / 2 : pad + (i * (w - pad * 2)) / (points.length - 1);
  const y = (v: number) => h - pad - ((v - min) / span) * (h - pad * 2);

  const line = points.map((p, i) => `${i === 0 ? "M" : "L"}${x(i)},${y(p.value)}`).join(" ");
  const area = `${line} L${x(points.length - 1)},${h - pad} L${x(0)},${h - pad} Z`;

  return (
    <div className={className}>
      <svg
        viewBox={`0 0 ${w} ${h}`}
        className="h-[120px] w-full"
        role="img"
        aria-label={`Trend chart with ${points.length} data points`}
      >
        {goal != null && goal > 0 && (
          <line
            x1={pad}
            x2={w - pad}
            y1={y(goal)}
            y2={y(goal)}
            stroke="currentColor"
            strokeDasharray="4 4"
            strokeWidth="1"
            className="text-muted-foreground/50"
          />
        )}
        <path d={area} className="fill-primary/10" />
        <path
          d={line}
          fill="none"
          stroke="currentColor"
          strokeWidth="2.5"
          strokeLinecap="round"
          strokeLinejoin="round"
          className="text-primary"
        />
        {points.map((p, i) => (
          <circle key={`${p.label}-${i}`} cx={x(i)} cy={y(p.value)} r="2.5" className="fill-primary" />
        ))}
      </svg>
      <div className="mt-1 flex justify-between px-1 text-[11px] font-semibold text-muted-foreground">
        <span>{points[0]?.label}</span>
        <span>{points[points.length - 1]?.label}</span>
      </div>
    </div>
  );
}
