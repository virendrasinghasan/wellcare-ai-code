import { ChevronLeft, Check } from "lucide-react";
import type { ReactNode } from "react";
import { cn } from "@/lib/utils";

export function StepShell({
  step,
  total,
  onBack,
  title,
  subtitle,
  children,
  footer,
}: {
  step: number;
  total: number;
  onBack?: (() => void) | undefined;
  title: string;
  subtitle?: string | undefined;
  children: ReactNode;
  footer: ReactNode;
}) {
  return (
    <div className="flex min-h-screen flex-col bg-background">
      <div className="px-5 pt-[max(env(safe-area-inset-top),1.25rem)]">
        <div className="flex items-center gap-3 py-2">
          <button
            type="button"
            onClick={onBack}
            disabled={!onBack}
            aria-label="Back"
            className={cn(
              "flex h-10 w-10 shrink-0 items-center justify-center rounded-full bg-muted text-foreground transition-opacity",
              !onBack && "opacity-0",
            )}
          >
            <ChevronLeft className="h-5 w-5" />
          </button>
          <div className="h-1.5 min-w-0 flex-1 overflow-hidden rounded-full bg-muted">
            <div
              className="h-full rounded-full bg-primary transition-all duration-500 ease-out"
              style={{ width: `${(step / total) * 100}%` }}
            />
          </div>
          <span className="shrink-0 text-[12px] font-semibold text-muted-foreground tabular-nums">
            {step}/{total}
          </span>
        </div>
      </div>

      <div className="flex-1 overflow-y-auto px-5 pb-6 pt-6">
        <h1 className="text-[26px] font-extrabold leading-tight tracking-[-0.03em]">{title}</h1>
        {subtitle && (
          <p className="mt-2 text-[14px] leading-relaxed text-muted-foreground">{subtitle}</p>
        )}
        <div className="mt-7">{children}</div>
      </div>

      <div className="sticky bottom-0 border-t border-border/70 bg-background px-5 pb-[max(env(safe-area-inset-bottom),1rem)] pt-3">
        {footer}
      </div>
    </div>
  );
}

export function PrimaryButton({
  children,
  onClick,
  disabled,
  type = "button",
  className,
}: {
  children: ReactNode;
  onClick?: (() => void) | undefined;
  disabled?: boolean | undefined;
  type?: "button" | "submit" | undefined;
  className?: string | undefined;
}) {
  return (
    <button
      type={type}
      onClick={onClick}
      disabled={disabled}
      className={cn(
        "flex h-14 w-full items-center justify-center rounded-[1.15rem] bg-primary text-[15px] font-bold text-primary-foreground transition-all active:scale-[0.98] disabled:opacity-35",
        className,
      )}
    >
      {children}
    </button>
  );
}

export function GhostButton({
  children,
  onClick,
  className,
}: {
  children: ReactNode;
  onClick?: (() => void) | undefined;
  className?: string | undefined;
}) {
  return (
    <button
      type="button"
      onClick={onClick}
      className={cn(
        "flex h-12 w-full items-center justify-center rounded-[1.15rem] text-[14px] font-semibold text-muted-foreground transition-colors active:bg-muted",
        className,
      )}
    >
      {children}
    </button>
  );
}

export function OptionRow({
  label,
  description,
  selected,
  onClick,
  multi = false,
}: {
  label: string;
  description?: string | undefined;
  selected: boolean;
  onClick: () => void;
  multi?: boolean | undefined;
}) {
  return (
    <button
      type="button"
      onClick={onClick}
      aria-pressed={selected}
      className={cn(
        "flex w-full items-center gap-3 rounded-[1.25rem] border p-4 text-left transition-all active:scale-[0.99]",
        selected
          ? "border-primary bg-primary-soft"
          : "border-border/70 bg-card hover:border-border",
      )}
    >
      <span className="min-w-0 flex-1">
        <span className="block text-[15px] font-bold tracking-tight">{label}</span>
        {description && (
          <span className="mt-0.5 block text-[13px] leading-snug text-muted-foreground">
            {description}
          </span>
        )}
      </span>
      <span
        className={cn(
          "flex h-6 w-6 shrink-0 items-center justify-center border transition-colors",
          multi ? "rounded-[0.5rem]" : "rounded-full",
          selected ? "border-primary bg-primary text-primary-foreground" : "border-border",
        )}
      >
        {selected && <Check className="h-3.5 w-3.5" strokeWidth={3} />}
      </span>
    </button>
  );
}

export function SegmentedControl<T extends string>({
  options,
  value,
  onChange,
}: {
  options: { value: T; label: string }[];
  value: T;
  onChange: (v: T) => void;
}) {
  return (
    <div className="inline-flex rounded-full bg-muted p-1">
      {options.map((o) => (
        <button
          key={o.value}
          type="button"
          onClick={() => onChange(o.value)}
          className={cn(
            "min-w-[54px] rounded-full px-3 py-1.5 text-[13px] font-bold transition-colors",
            value === o.value
              ? "bg-card text-foreground shadow-[var(--shadow-card)]"
              : "text-muted-foreground",
          )}
        >
          {o.label}
        </button>
      ))}
    </div>
  );
}

export function Field({
  label,
  children,
  hint,
}: {
  label: string;
  children: ReactNode;
  hint?: string | undefined;
}) {
  return (
    <label className="block">
      <span className="mb-2 block text-[13px] font-bold tracking-tight">{label}</span>
      {children}
      {hint && <span className="mt-1.5 block text-[12px] text-muted-foreground">{hint}</span>}
    </label>
  );
}

export const inputClass =
  "h-14 w-full rounded-[1.15rem] border border-border/80 bg-card px-4 text-[16px] font-semibold outline-none transition-colors placeholder:font-medium placeholder:text-muted-foreground focus:border-primary";
