import {
  Droplet,
  Droplets,
  Dumbbell,
  Flame,
  Footprints,
  HeartPulse,
  Moon,
  Pill,
  Scale,
  Wind,
} from "lucide-react";
import type { LucideIcon } from "lucide-react";
import type { TrackerMeta } from "@/lib/wellcare/trackers/registry";

const ICONS: Record<TrackerMeta["icon"], LucideIcon> = {
  flame: Flame,
  droplets: Droplets,
  footprints: Footprints,
  dumbbell: Dumbbell,
  scale: Scale,
  moon: Moon,
  pill: Pill,
  "heart-pulse": HeartPulse,
  wind: Wind,
  droplet: Droplet,
};

export function TrackerIcon({
  name,
  className,
}: {
  name: TrackerMeta["icon"];
  className?: string;
}) {
  const Icon = ICONS[name];
  return <Icon className={className} strokeWidth={2} aria-hidden />;
}
