import { useEffect, useState } from "react";
import { cn } from "@/lib/utils";
import { avatarSignedUrl } from "@/lib/wellcare/avatar";

/**
 * Profile picture with a graceful fallback to the user's initial.
 * Private storage paths are resolved to short-lived signed URLs.
 */
export function WellcareAvatar({
  name,
  path,
  local,
  className,
  textClassName,
}: {
  name: string;
  path: string | null;
  local: string | null;
  className?: string;
  textClassName?: string;
}) {
  const [remote, setRemote] = useState<string | null>(null);

  useEffect(() => {
    let cancelled = false;
    if (!path) {
      setRemote(null);
      return;
    }
    void avatarSignedUrl(path).then((url) => {
      if (!cancelled) setRemote(url);
    });
    return () => {
      cancelled = true;
    };
  }, [path]);

  const src = remote ?? local;

  return (
    <span
      className={cn(
        "relative flex shrink-0 items-center justify-center overflow-hidden rounded-full bg-primary-soft text-accent-foreground",
        className,
      )}
    >
      {src ? (
        <img src={src} alt="" className="h-full w-full object-cover" />
      ) : (
        <span className={cn("font-extrabold", textClassName)}>
          {(name || "W").slice(0, 1).toUpperCase()}
        </span>
      )}
    </span>
  );
}
