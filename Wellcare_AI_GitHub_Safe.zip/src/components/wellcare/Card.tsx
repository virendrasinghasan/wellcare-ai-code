import { cn } from "@/lib/utils";
import type { ReactNode } from "react";

export function SurfaceCard({
  className,
  children,
}: {
  className?: string;
  children: ReactNode;
}) {
  return (
    <section
      className={cn(
        "rounded-[1.75rem] border border-border/70 bg-card p-5 shadow-[var(--shadow-card)]",
        className,
      )}
    >
      {children}
    </section>
  );
}

export function SectionHeader({
  title,
  action,
  className,
}: {
  title: string;
  action?: ReactNode;
  className?: string;
}) {
  return (
    <div className={cn("mb-3 flex items-center justify-between px-1", className)}>
      <h2 className="text-[13px] font-bold uppercase tracking-[0.08em] text-muted-foreground">
        {title}
      </h2>
      {action}
    </div>
  );
}
