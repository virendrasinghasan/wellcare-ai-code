import { Link, useRouterState } from "@tanstack/react-router";
import { Home, LayoutGrid, User } from "lucide-react";
import wellcareIcon from "@/assets/wellcare-icon.svg";
import { useEffect, type ReactNode } from "react";
import { cn } from "@/lib/utils";
import { rememberRoute } from "@/lib/wellcare/last-route";

const tabs = [
  { to: "/", label: "Home", icon: Home, exact: true },
  { to: "/explore", label: "Explore", icon: LayoutGrid, exact: false },
  { to: "/profile", label: "Profile", icon: User, exact: false },
] as const;

/** Routes that own the whole screen (no bottom nav, no floating AI button). */
const FULLSCREEN = ["/welcome", "/onboarding", "/coach", "/session", "/form-coach"];

export function AppShell({ children }: { children: ReactNode }) {
  const pathname = useRouterState({ select: (s) => s.location.pathname });
  const bare = FULLSCREEN.some((p) => pathname.startsWith(p));

  // Track the last normal screen so Wellcare AI can go back to it.
  useEffect(() => {
    if (!pathname.startsWith("/coach")) rememberRoute(pathname);
  }, [pathname]);


  return (
    <div className="min-h-screen bg-muted/40">
      <div className="relative mx-auto flex min-h-screen w-full max-w-[430px] flex-col bg-background">
        <main className={cn("flex-1", bare ? "" : "pb-[7.5rem]")}>{children}</main>

        {!bare && (
          <div className="fixed inset-x-0 bottom-0 z-40 mx-auto w-full max-w-[430px] px-5 pb-[max(env(safe-area-inset-bottom),0.9rem)]">
            <div className="flex items-center gap-3">
              <nav className="flex h-16 flex-1 items-center justify-between rounded-full border border-border/70 bg-card px-2 shadow-[var(--shadow-raised)]">
                {tabs.map(({ to, label, icon: Icon, exact }) => {
                  const active = exact ? pathname === to : pathname.startsWith(to);
                  return (
                    <Link
                      key={to}
                      to={to}
                      aria-label={label}
                      className={cn(
                        "flex h-12 flex-1 items-center justify-center gap-2 rounded-full px-2 transition-colors",
                        active ? "bg-primary-soft" : "",
                      )}
                    >
                      <Icon
                        className={cn(
                          "h-[19px] w-[19px] shrink-0",
                          active ? "text-accent-foreground" : "text-muted-foreground",
                        )}
                        strokeWidth={active ? 2.4 : 1.9}
                      />
                      <span
                        className={cn(
                          "text-[12.5px] font-bold tracking-tight",
                          active ? "text-accent-foreground" : "hidden",
                        )}
                      >
                        {label}
                      </span>
                    </Link>
                  );
                })}
              </nav>

              <Link
                to="/coach"
                aria-label="Wellcare AI coach"
                className="flex h-16 w-16 shrink-0 items-center justify-center rounded-full bg-card shadow-[var(--shadow-float)] transition-transform active:scale-95"
              >
                <img src={wellcareIcon} alt="" className="h-16 w-16" />
              </Link>
            </div>
          </div>
        )}
      </div>
    </div>
  );
}
