import { useEffect, useRef, useState } from "react";
import { Dumbbell } from "lucide-react";
import { cn } from "@/lib/utils";
import { getExerciseMedia } from "@/lib/wellcare/workout/media";

/** Deterministic soft tint so placeholders never look like one repeated image. */
function tint(id: string) {
  let h = 0;
  for (let i = 0; i < id.length; i += 1) h = (h * 31 + id.charCodeAt(i)) % 360;
  return h;
}

function initials(name: string) {
  return name
    .replace(/[^a-zA-Z ]/g, " ")
    .split(/\s+/)
    .filter(Boolean)
    .slice(0, 2)
    .map((w) => w[0]!.toUpperCase())
    .join("");
}

function Placeholder({ id, name, compact }: { id: string; name: string; compact?: boolean }) {
  const h = tint(id);
  return (
    <div
      className="flex h-full w-full flex-col items-center justify-center gap-1"
      style={{
        background: `linear-gradient(150deg, oklch(0.92 0.045 ${h}), oklch(0.86 0.06 ${h}))`,
      }}
      aria-hidden
    >
      <Dumbbell
        className={cn("text-foreground/45", compact ? "h-4 w-4" : "h-6 w-6")}
        strokeWidth={1.8}
      />
      <span
        className={cn(
          "font-extrabold tracking-[-0.02em] text-foreground/60",
          compact ? "text-[11px]" : "text-[15px]",
        )}
      >
        {initials(name)}
      </span>
    </div>
  );
}

/**
 * Square-cropped still frame of the movement. Lazy-loaded, so a long library
 * list only fetches what scrolls into view.
 */
export function ExerciseThumb({
  exerciseId,
  name,
  className,
  compact,
}: {
  exerciseId: string;
  name: string;
  className?: string;
  compact?: boolean;
}) {
  const media = getExerciseMedia(exerciseId);
  const [failed, setFailed] = useState(false);
  const src = media.thumbnailUrl;

  return (
    <div
      className={cn(
        "relative shrink-0 overflow-hidden rounded-[1rem] bg-muted",
        compact ? "h-12 w-12" : "h-16 w-16",
        className,
      )}
    >
      {src && !failed ? (
        <img
          src={src}
          alt={`${name} demonstration`}
          loading="lazy"
          decoding="async"
          onError={() => setFailed(true)}
          className="h-full w-full object-cover"
        />
      ) : (
        <Placeholder id={exerciseId} name={name} compact={compact ?? false} />
      )}
    </div>
  );
}

/**
 * Looping demonstration built from the real start/end photographs of the lift.
 * Frames only load on the detail screen, never in the list.
 */
export function ExerciseDemo({
  exerciseId,
  name,
  className,
}: {
  exerciseId: string;
  name: string;
  className?: string;
}) {
  const media = getExerciseMedia(exerciseId);
  const [frame, setFrame] = useState(0);
  const [failed, setFailed] = useState(false);
  const count = media.frames.length;
  const timer = useRef<ReturnType<typeof setInterval> | null>(null);

  useEffect(() => {
    if (count < 2) return;
    if (window.matchMedia("(prefers-reduced-motion: reduce)").matches) return;
    timer.current = setInterval(() => setFrame((f) => (f + 1) % count), 1100);
    return () => {
      if (timer.current) clearInterval(timer.current);
    };
  }, [count, exerciseId]);

  return (
    <figure
      className={cn(
        "relative overflow-hidden rounded-[1.5rem] border border-border/70 bg-muted",
        className,
      )}
    >
      <div className="aspect-[4/3] w-full">
        {count > 0 && !failed ? (
          media.frames.map((f, i) => (
            <img
              key={f}
              src={f}
              alt={`${name} demonstration, position ${i + 1}`}
              decoding="async"
              onError={() => setFailed(true)}
              className={cn(
                "absolute inset-0 h-full w-full object-cover transition-opacity duration-500",
                i === frame ? "opacity-100" : "opacity-0",
              )}
            />
          ))
        ) : (
          <Placeholder id={exerciseId} name={name} />
        )}
      </div>
      {count > 1 && !failed && (
        <div className="absolute bottom-3 left-1/2 flex -translate-x-1/2 gap-1.5">
          {media.frames.map((f, i) => (
            <span
              key={f}
              className={cn(
                "h-1.5 rounded-full transition-all",
                i === frame ? "w-4 bg-foreground/70" : "w-1.5 bg-foreground/25",
              )}
            />
          ))}
        </div>
      )}
    </figure>
  );
}

/** Collage cover for plan / workout cards, built from its own exercises. */
export function ExerciseCollage({
  exerciseIds,
  names,
  className,
}: {
  exerciseIds: string[];
  names: string[];
  className?: string;
}) {
  const ids = exerciseIds.slice(0, 3);
  return (
    <div className={cn("flex h-20 w-20 shrink-0 gap-0.5 overflow-hidden rounded-[1.15rem]", className)}>
      <div className="flex-1">
        <ExerciseThumb
          exerciseId={ids[0] ?? "unknown"}
          name={names[0] ?? "Workout"}
          className="h-full w-full rounded-none"
        />
      </div>
      <div className="flex w-[38%] flex-col gap-0.5">
        {[1, 2].map((i) => (
          <ExerciseThumb
            key={i}
            exerciseId={ids[i] ?? `unknown-${i}`}
            name={names[i] ?? "Workout"}
            compact
            className="h-full w-full rounded-none"
          />
        ))}
      </div>
    </div>
  );
}
