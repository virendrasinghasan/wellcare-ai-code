import wellcareIcon from "@/assets/wellcare-icon.svg";
import wellcareLogo from "@/assets/wellcare-logo.svg";
import wellcareLogoDark from "@/assets/wellcare-logo-dark.svg";
import { cn } from "@/lib/utils";

/**
 * Premium boot screen: the mark sits inside a slowly drawing progress arc while
 * a live ECG trace sweeps underneath. Flat brand surface, no gradient wash,
 * works in both colour schemes, and fades out the moment boot finishes.
 */
export function Splash({ exiting = false }: { exiting?: boolean }) {
  return (
    <div
      className={cn(
        "fixed inset-0 z-[100] flex flex-col items-center justify-center bg-background transition-opacity duration-300",
        exiting ? "opacity-0" : "opacity-100",
      )}
    >
      <div className="relative flex h-36 w-36 items-center justify-center">
        <svg viewBox="0 0 100 100" className="absolute inset-0 h-full w-full -rotate-90">
          <circle
            cx="50"
            cy="50"
            r="46"
            fill="none"
            className="stroke-border"
            strokeWidth="1.5"
          />
          <circle
            cx="50"
            cy="50"
            r="46"
            fill="none"
            className="stroke-primary [stroke-dasharray:70_220] [stroke-linecap:round] animate-[wc-arc_1.5s_cubic-bezier(0.4,0,0.2,1)_infinite]"
            strokeWidth="3"
          />
        </svg>
        <img
          src={wellcareIcon}
          alt=""
          className="relative h-16 w-16 animate-[wc-breathe_2.4s_ease-in-out_infinite]"
        />
      </div>

      <div className="mt-9 h-8 w-52 overflow-hidden">
        <svg viewBox="0 0 200 32" className="h-full w-full" aria-hidden>
          <path
            d="M0 16 H62 l6 -11 l7 22 l7 -18 l6 7 H200"
            fill="none"
            className="stroke-primary/70 [stroke-dasharray:230] [stroke-linecap:round] [stroke-linejoin:round] animate-[wc-trace_1.9s_linear_infinite]"
            strokeWidth="2"
          />
        </svg>
      </div>

      <div className="mt-4 flex flex-col items-center text-center">
        <picture>
          <source media="(prefers-color-scheme: dark)" srcSet={wellcareLogoDark} />
          <img src={wellcareLogo} alt="Wellcare AI" className="h-6 w-auto" />
        </picture>
        <p className="mt-2.5 text-[12.5px] font-medium tracking-[0.02em] text-muted-foreground">
          Health, without the guesswork.
        </p>
      </div>

      <style>{`
@keyframes wc-arc{0%{stroke-dashoffset:289}100%{stroke-dashoffset:0}}
@keyframes wc-breathe{0%,100%{transform:scale(1)}50%{transform:scale(1.05)}}
@keyframes wc-trace{0%{stroke-dashoffset:230}100%{stroke-dashoffset:-230}}
@media (prefers-reduced-motion: reduce){
  .animate-\\[wc-arc_1\\.5s_cubic-bezier\\(0\\.4\\,0\\,0\\.2\\,1\\)_infinite\\],
  .animate-\\[wc-breathe_2\\.4s_ease-in-out_infinite\\],
  .animate-\\[wc-trace_1\\.9s_linear_infinite\\]{animation:none}
}
      `}</style>
    </div>
  );
}
