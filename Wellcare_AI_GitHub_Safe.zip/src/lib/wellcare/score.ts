import type { DayLog, MacroTotals, WellcareProfile } from "./types";
import { todayKey } from "./store";

export interface HealthScore {
  score: number;
  label: string;
  parts: { label: string; value: number }[];
}

const clamp = (n: number) => Math.max(0, Math.min(100, Math.round(n)));

/**
 * Daily health score - a blunt weighted read of how today is actually going.
 * Nothing is invented: every part comes from data the user logged.
 */
export function dailyHealthScore(
  profile: WellcareProfile,
  consumed: MacroTotals,
  log: DayLog,
): HealthScore {
  const targets = profile.targets ?? { calories: 2200, protein: 150, carbs: 240, fat: 70 };

  // Calories: full marks inside +/-10% of target, falling away outside it.
  const calRatio = targets.calories > 0 ? consumed.calories / targets.calories : 0;
  const calories = clamp(100 - Math.max(0, Math.abs(calRatio - 1) - 0.1) * 250);

  const protein = clamp(
    targets.protein > 0 ? (consumed.protein / targets.protein) * 100 : 0,
  );
  const water = clamp(
    profile.waterTargetMl > 0 ? (log.waterMl / profile.waterTargetMl) * 100 : 0,
  );
  const logging = clamp((log.entries.length / 3) * 100);

  const score = clamp(calories * 0.35 + protein * 0.3 + water * 0.2 + logging * 0.15);

  const label =
    log.entries.length === 0
      ? "Nothing to score yet"
      : score >= 85
        ? "Dialled in"
        : score >= 70
          ? "Solid day"
          : score >= 50
            ? "Patchy"
            : "Off the rails";

  return {
    score,
    label,
    parts: [
      { label: "Calories", value: calories },
      { label: "Protein", value: protein },
      { label: "Water", value: water },
      { label: "Logging", value: logging },
    ],
  };
}

function dayKeyOffset(offset: number): string {
  const d = new Date();
  d.setDate(d.getDate() - offset);
  return todayKey(d);
}

/** Consecutive days (ending today or yesterday) with at least one food entry. */
export function loggingStreak(logs: Record<string, DayLog>): number {
  const active = (key: string) => (logs[key]?.entries.length ?? 0) > 0;
  let start = 0;
  if (!active(dayKeyOffset(0))) {
    if (!active(dayKeyOffset(1))) return 0;
    start = 1;
  }
  let streak = 0;
  for (let i = start; i < 400; i += 1) {
    if (!active(dayKeyOffset(i))) break;
    streak += 1;
  }
  return streak;
}

/** One concrete next action, chosen from what today is missing most. */
export function nextBestAction(
  profile: WellcareProfile,
  consumed: MacroTotals,
  log: DayLog,
): { title: string; detail: string; to: "/scan-meal" | "/trackers" | "/add-food" | "/workout" } {
  const targets = profile.targets ?? { calories: 2200, protein: 150, carbs: 240, fat: 70 };
  const hour = new Date().getHours();

  if (log.entries.length === 0) {
    return {
      title: "Log your first meal",
      detail: "Scan it or search it. The numbers only mean something once something is in them.",
      to: "/scan-meal",
    };
  }

  const waterPct = log.waterMl / Math.max(1, profile.waterTargetMl);
  const proteinLeft = targets.protein - consumed.protein;

  if (waterPct < 0.4 && hour >= 13) {
    return {
      title: "Drink some water",
      detail: `You're at ${(log.waterMl / 1000).toFixed(1)} L of ${(profile.waterTargetMl / 1000).toFixed(1)} L. Easiest win on this page.`,
      to: "/trackers",
    };
  }

  if (proteinLeft > 30) {
    return {
      title: `${Math.round(proteinLeft)}g protein still missing`,
      detail: "Pick something protein-heavy for the next meal instead of hoping it works out.",
      to: "/add-food",
    };
  }

  if (profile.daysPerWeek && profile.daysPerWeek > 0) {
    return {
      title: "Get today's session in",
      detail: "Food's on track. Training is the other half of the deal.",
      to: "/workout",
    };
  }

  return {
    title: "Keep it boring",
    detail: "Targets are close enough. Log the rest of the day and don't overthink it.",
    to: "/add-food",
  };
}
