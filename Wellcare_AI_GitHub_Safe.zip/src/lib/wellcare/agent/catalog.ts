/**
 * Wellcare AI agent tool catalog.
 *
 * Declarations only - every tool is executed by a validated server-side
 * executor (see executors.server.ts) that runs as the signed-in user under RLS.
 * The model never touches the database directly.
 */

import type { ConfirmLevel } from "./types";

export interface ToolParam {
  type: "string" | "number" | "boolean" | "array" | "object";
  description: string;
  enum?: string[];
  items?: { type: string; properties?: Record<string, unknown>; required?: string[] };
  properties?: Record<string, unknown>;
}

export interface ToolSpec {
  name: string;
  description: string;
  /** 1 = run immediately, 2 = preview + confirm, 3 = never run from chat. */
  level: ConfirmLevel;
  parameters: Record<string, ToolParam>;
  required?: string[];
}

const str = (description: string, rest: Partial<ToolParam> = {}): ToolParam => ({
  type: "string",
  description,
  ...rest,
});
const num = (description: string): ToolParam => ({ type: "number", description });
const bool = (description: string): ToolParam => ({ type: "boolean", description });

export const NAV_ROUTES: Record<string, string> = {
  home: "/",
  nutrition: "/nutrition",
  add_food: "/add-food",
  barcode_scanner: "/scan-barcode",
  meal_scanner: "/scan-meal",
  workout: "/workout",
  exercises: "/exercises",
  session: "/session",
  progress: "/progress",
  trackers: "/trackers",
  profile: "/profile",
  edit_profile: "/edit-profile",
  explore: "/explore",
};

export const TOOLS: ToolSpec[] = [
  /* ------------------------------- nutrition ------------------------------ */
  {
    name: "search_food",
    description: "Search the Wellcare food database by name or brand. Use before logging when unsure of nutrition values.",
    level: 1,
    parameters: { query: str("Food name, e.g. 'greek yogurt'"), limit: num("Max results, default 8") },
    required: ["query"],
  },
  {
    name: "log_food",
    description:
      "Log a food/meal into today's (or a given day's) diary with its nutrition. Values are per the portion actually eaten.",
    level: 1,
    parameters: {
      name: str("What was eaten, e.g. '2 eggs and toast'"),
      meal_type: str("Which meal", { enum: ["breakfast", "lunch", "dinner", "snack"] }),
      calories: num("Calories (kcal)"),
      protein_g: num("Protein grams"),
      carbs_g: num("Carb grams"),
      fat_g: num("Fat grams"),
      quantity: num("How much was eaten, e.g. 100 for 100g. Defaults to 1."),
      unit: str("Unit for quantity, e.g. 'g', 'ml', 'piece', 'serving'."),
      logged_on: str("ISO date YYYY-MM-DD. Defaults to today."),
    },
    required: ["name", "meal_type", "calories", "protein_g", "carbs_g", "fat_g"],
  },
  {
    name: "remove_food_entry",
    description: "Remove a food entry logged today, matched by name.",
    level: 1,
    parameters: { name: str("Name of the entry to remove") },
    required: ["name"],
  },
  {
    name: "log_water",
    description: "Add water to today's hydration total.",
    level: 1,
    parameters: { ml: num("Millilitres to add. A glass is ~250 ml.") },
    required: ["ml"],
  },
  {
    name: "update_food_entry",
    description: "Edit a food entry already logged (rename, change macros, quantity or which meal it belongs to).",
    level: 1,
    parameters: {
      name: str("Current name of the logged entry"),
      logged_on: str("ISO date of the log, defaults to today"),
      new_name: str("New name"),
      meal_type: str("Move to this meal", { enum: ["breakfast", "lunch", "dinner", "snack"] }),
      calories: num("New calories"),
      protein_g: num("New protein in grams"),
      carbs_g: num("New carbs in grams"),
      fat_g: num("New fat in grams"),
      quantity: num("New quantity"),
    },
    required: ["name"],
  },
  {
    name: "create_custom_food",
    description: "Save a reusable custom food or recipe to the user's food library (per serving nutrition).",
    level: 1,
    parameters: {
      name: str("Food or recipe name"),
      serving_label: str("Serving description, e.g. '1 bowl (300 g)'"),
      serving_grams: num("Serving weight in grams"),
      calories: num("Calories per serving"),
      protein_g: num("Protein per serving"),
      carbs_g: num("Carbs per serving"),
      fat_g: num("Fat per serving"),
      brand: str("Optional brand"),
    },
    required: ["name", "serving_label", "calories", "protein_g", "carbs_g", "fat_g"],
  },
  {
    name: "nutrition_summary",
    description: "Read logged nutrition for a day: totals, remaining calories/macros and the entries.",
    level: 1,
    parameters: { logged_on: str("ISO date YYYY-MM-DD, defaults to today") },
  },

  /* -------------------------------- trackers ------------------------------ */
  {
    name: "log_tracker",
    description:
      "Log a reading for a tracker. Keys: water, steps, weight, sleep (minutes), heart_rate, respiratory, glucose.",
    level: 1,
    parameters: {
      key: str("Tracker key", {
        enum: ["water", "steps", "weight", "sleep", "heart_rate", "respiratory", "glucose"],
      }),
      value: num("The value in the tracker's unit"),
      at: str("ISO datetime, defaults to now"),
      note: str("Optional short context, e.g. 'after breakfast'"),
    },
    required: ["key", "value"],
  },
  {
    name: "read_tracker_history",
    description: "Read recent entries for a tracker with a short statistical summary.",
    level: 1,
    parameters: {
      key: str("Tracker key", {
        enum: ["water", "steps", "weight", "sleep", "heart_rate", "respiratory", "glucose"],
      }),
      days: num("How many days back, default 30"),
    },
    required: ["key"],
  },
  {
    name: "set_tracker_goal",
    description: "Create or update the target for a tracker (e.g. 10000 steps daily).",
    level: 1,
    parameters: {
      key: str("Tracker key"),
      target: num("Target value"),
      period: str("Period", { enum: ["daily", "weekly", "monthly"] }),
      unit: str("Optional unit override"),
    },
    required: ["key", "target"],
  },
  {
    name: "set_tracker_pref",
    description:
      "Enable/disable a tracker or pin it to the home dashboard, and set its dashboard position (reordering).",
    level: 1,
    parameters: {
      key: str("Tracker key"),
      enabled: bool("Whether the tracker is active"),
      pinned_home: bool("Whether it shows on the home dashboard"),
      position: num("Dashboard order, lower is higher up"),
    },
    required: ["key"],
  },
  {
    name: "list_trackers",
    description: "List available trackers with the user's enabled/pinned settings and goals.",
    level: 1,
    parameters: {},
  },

  /* -------------------------------- medicine ------------------------------ */
  {
    name: "create_medicine",
    description: "Add a medicine with its schedule and optional reminders.",
    level: 1,
    parameters: {
      name: str("Medicine name"),
      dose: str("Dose, e.g. '500'"),
      unit: str("Dose unit, e.g. 'mg'"),
      frequency: str("Frequency", { enum: ["daily", "twice_daily", "weekly", "as_needed"] }),
      times: { type: "array", description: "Times of day in HH:MM, e.g. ['08:00','20:00']", items: { type: "string" } },
      reminder_enabled: bool("Whether to remind at those times"),
      notes: str("Optional notes"),
    },
    required: ["name", "frequency", "times"],
  },
  {
    name: "log_medicine",
    description: "Record that a medicine was taken, missed or skipped today.",
    level: 1,
    parameters: {
      name: str("Medicine name"),
      status: str("Outcome", { enum: ["taken", "missed", "skipped"] }),
      scheduled_time: str("Which scheduled time, HH:MM"),
    },
    required: ["name", "status"],
  },
  { name: "list_medicines", description: "List the user's active medicines and today's doses.", level: 1, parameters: {} },

  /* -------------------------------- workouts ------------------------------ */
  {
    name: "search_exercises",
    description: "Search the Wellcare exercise library. Always use this to get real exercise ids before building a plan.",
    level: 1,
    parameters: {
      query: str("Free text, e.g. 'row'"),
      muscle: str("Primary muscle filter, e.g. chest, back, quadriceps"),
      equipment: str("Equipment filter, e.g. dumbbell, barbell, bodyweight"),
      difficulty: str("beginner | intermediate | advanced"),
      limit: num("Max results, default 12"),
    },
  },
  {
    name: "create_workout_program",
    description:
      "Create a workout split/plan with its days and exercises, saved to the user's workouts. Use search_exercises first for real exercise names.",
    level: 1,
    parameters: {
      name: str("Program name, e.g. 'Push Pull Legs'"),
      description: str("One-line description"),
      goal: str("Goal", { enum: ["lose_fat", "maintain", "build_muscle", "recomp", "performance"] }),
      weeks: num("Program length in weeks, default 8"),
      activate: bool("Make this the active program"),
      days: {
        type: "array",
        description: "Training days in order",
        items: {
          type: "object",
          properties: {
            label: { type: "string", description: "Day name, e.g. 'Push'" },
            exercises: {
              type: "array",
              items: {
                type: "object",
                properties: {
                  name: { type: "string", description: "Exercise name" },
                  exercise_id: { type: "string", description: "Library id from search_exercises" },
                  sets: { type: "number", description: "Target sets" },
                  reps: { type: "string", description: "Target reps, e.g. '8-12'" },
                  rest_seconds: { type: "number", description: "Rest between sets" },
                  notes: { type: "string", description: "Optional cue" },
                },
                required: ["name", "sets", "reps"],
              },
              description: "Exercises for the day, in order",
            },
          },
          required: ["label", "exercises"],
        },
      },
    },
    required: ["name", "days"],
  },
  {
    name: "list_workout_programs",
    description: "List the user's saved workout programs, with which one is active.",
    level: 1,
    parameters: {},
  },
  {
    name: "get_workout_program",
    description: "Read one program's days and exercises. Use before editing.",
    level: 1,
    parameters: { program: str("Program name or id; defaults to the active program") },
  },
  {
    name: "add_exercise_to_program",
    description: "Add an exercise to a day of a program.",
    level: 1,
    parameters: {
      program: str("Program name or id"),
      day_label: str("Day name, e.g. 'Friday' or 'Legs'"),
      name: str("Exercise name"),
      exercise_id: str("Library id if known"),
      sets: num("Target sets"),
      reps: str("Target reps"),
      rest_seconds: num("Rest seconds"),
    },
    required: ["day_label", "name"],
  },
  {
    name: "remove_exercise_from_program",
    description: "Remove an exercise from a program (optionally only from one day).",
    level: 1,
    parameters: {
      program: str("Program name or id"),
      name: str("Exercise name to remove"),
      day_label: str("Restrict to this day"),
    },
    required: ["name"],
  },
  {
    name: "update_program_exercise",
    description: "Change sets, reps, rest or order for an exercise in a program.",
    level: 1,
    parameters: {
      program: str("Program name or id"),
      name: str("Exercise name"),
      day_label: str("Restrict to this day"),
      sets: num("New target sets"),
      reps: str("New target reps"),
      rest_seconds: num("New rest seconds"),
      position: num("New order within the day"),
    },
    required: ["name"],
  },
  {
    name: "set_active_program",
    description: "Make a program the active one. Replaces whatever plan is currently active.",
    level: 2,
    parameters: { program: str("Program name or id") },
    required: ["program"],
  },
  {
    name: "delete_workout_program",
    description: "Delete a workout program and its exercises.",
    level: 2,
    parameters: { program: str("Program name or id") },
    required: ["program"],
  },
  {
    name: "log_workout_session",
    description: "Log a completed workout session, optionally with the sets performed.",
    level: 1,
    parameters: {
      title: str("Session title, e.g. 'Push day'"),
      performed_on: str("ISO date, defaults to today"),
      duration_minutes: num("Duration in minutes"),
      perceived_effort: num("RPE 1-10"),
      notes: str("Optional notes"),
      sets: {
        type: "array",
        description: "Sets performed",
        items: {
          type: "object",
          properties: {
            exercise_name: { type: "string", description: "Exercise" },
            reps: { type: "number", description: "Reps" },
            weight_kg: { type: "number", description: "Load in kg" },
          },
          required: ["exercise_name"],
        },
      },
    },
    required: ["title"],
  },
  {
    name: "workout_history",
    description: "Read recent workout sessions.",
    level: 1,
    parameters: { limit: num("How many sessions, default 10") },
  },

  /* ---------------------------------- goals ------------------------------- */
  {
    name: "create_goal",
    description: "Create a personal goal, e.g. 'lose 5 kg by June'.",
    level: 1,
    parameters: {
      title: str("Goal title"),
      metric: str("What is measured, e.g. weight, steps, protein"),
      target_value: num("Target value"),
      current_value: num("Where they are now"),
      unit: str("Unit, e.g. kg"),
      due_on: str("ISO date deadline"),
      notes: str("Optional notes"),
    },
    required: ["title"],
  },
  {
    name: "update_goal",
    description: "Update a goal's target, progress or status (active, completed, paused).",
    level: 1,
    parameters: {
      title: str("Existing goal title to match"),
      target_value: num("New target"),
      current_value: num("New current value"),
      due_on: str("New deadline"),
      status: str("New status", { enum: ["active", "completed", "paused"] }),
    },
    required: ["title"],
  },
  {
    name: "delete_goal",
    description: "Delete a goal.",
    level: 2,
    parameters: { title: str("Goal title") },
    required: ["title"],
  },
  { name: "list_goals", description: "List the user's goals.", level: 1, parameters: {} },

  /* -------------------------------- reminders ----------------------------- */
  {
    name: "create_reminder",
    description: "Create a reminder at a time of day, optionally on specific weekdays.",
    level: 1,
    parameters: {
      title: str("What to remind about"),
      time_of_day: str("HH:MM 24h"),
      category: str("Category", { enum: ["general", "meal", "workout", "medicine", "water", "sleep"] }),
      days_of_week: { type: "array", description: "0=Sunday..6=Saturday. Empty means every day.", items: { type: "number" } },
      notes: str("Optional notes"),
    },
    required: ["title", "time_of_day"],
  },
  {
    name: "update_reminder",
    description: "Change a reminder's time, or enable/disable it.",
    level: 1,
    parameters: {
      title: str("Reminder title to match"),
      time_of_day: str("New HH:MM"),
      enabled: bool("Turn on/off"),
    },
    required: ["title"],
  },
  {
    name: "delete_reminder",
    description: "Delete a reminder.",
    level: 1,
    parameters: { title: str("Reminder title") },
    required: ["title"],
  },
  { name: "list_reminders", description: "List the user's reminders.", level: 1, parameters: {} },

  /* --------------------------------- profile ------------------------------ */
  {
    name: "get_profile",
    description: "Read the user's stored profile, targets and preferences.",
    level: 1,
    parameters: {},
  },
  {
    name: "update_profile",
    description: "Update profile details and preferences (not calorie/macro targets - use set_nutrition_targets).",
    level: 1,
    parameters: {
      first_name: str("First name"),
      weight_kg: num("Body weight in kg"),
      height_cm: num("Height in cm"),
      goal: str("Primary goal", { enum: ["lose_fat", "maintain", "build_muscle", "recomp", "performance"] }),
      activity_level: str("Activity level", {
        enum: ["sedentary", "light", "moderate", "active", "very_active"],
      }),
      training_days_per_week: num("Planned training days"),
      diet_type: str("Diet", { enum: ["omnivore", "vegetarian", "vegan", "pescatarian", "no_preference"] }),
      weight_unit: str("kg or lb", { enum: ["kg", "lb"] }),
      height_unit: str("cm or ftin", { enum: ["cm", "ftin"] }),
      equipment: { type: "array", description: "Available equipment keys", items: { type: "string" } },
      daily_water_target_ml: num("Daily water target in ml"),
    },
  },
  {
    name: "set_nutrition_targets",
    description: "Change daily calorie and/or macro targets.",
    level: 2,
    parameters: {
      calories: num("Daily calories"),
      protein_g: num("Daily protein grams"),
      carbs_g: num("Daily carb grams"),
      fat_g: num("Daily fat grams"),
    },
  },

  /* --------------------------------- reports ------------------------------ */
  {
    name: "progress_report",
    description:
      "Aggregate real numbers for a period: weight change, steps, sleep, water, workouts logged. Use before summarising progress or comparing periods.",
    level: 1,
    parameters: { days: num("Window in days, default 30"), compare_previous: bool("Also return the previous window") },
  },

  /* ---------------------------------- meta -------------------------------- */
  {
    name: "navigate",
    description: "Send the user to a screen in the app. Adds an action button to your reply.",
    level: 1,
    parameters: {
      screen: str("Screen key", { enum: Object.keys(NAV_ROUTES) }),
      label: str("Button label, e.g. 'Open workout'"),
    },
    required: ["screen"],
  },
  {
    name: "recent_changes",
    description: "List recent changes you made for this user.",
    level: 1,
    parameters: { limit: num("Default 10") },
  },
  {
    name: "undo_last_action",
    description: "Undo the most recent change you made (restores the previous state).",
    level: 1,
    parameters: {},
  },
];

export const TOOL_MAP: Record<string, ToolSpec> = Object.fromEntries(TOOLS.map((t) => [t.name, t]));
