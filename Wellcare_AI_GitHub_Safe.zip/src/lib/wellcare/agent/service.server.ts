import type { SupabaseClient } from "@supabase/supabase-js";
import type { Database } from "@/integrations/supabase/types";
import { TOOLS, TOOL_MAP } from "./catalog";
import { executeTool, toolResultSummary } from "./executors.server";
import type { AgentReply, AgentChatMessage, ClientOp, PerformedAction, AgentAction, AgentValue } from "./types";
import { WELLCARE_SYSTEM_PROMPT } from "../ai/persona.server";

interface AgentRequest {
  question: string;
  history: AgentChatMessage[];
  snapshot?: Record<string, unknown>;
}

interface GeminiPart {
  text?: string;
  functionCall?: { name?: string; args?: Record<string, AgentValue> };
  functionResponse?: { name: string; response: Record<string, AgentValue> };
}

interface GeminiContent { role: "user" | "model"; parts: GeminiPart[] }

const AGENT_RULES = `
You can operate the Wellcare app with the provided tools. Use tools whenever the user asks you to read or change app data. Never claim an action succeeded until its function response says ok. For multi-action requests, execute each action and report failures. Use search tools before editing ambiguous records. Keep confirmations concise. Before saying anything was logged, changed or deleted, you MUST have called the matching tool and received ok:true in its function response. If a tool returns ok:false, say plainly that it failed and why - never claim success. When the user states a food and amount ("I had 100g paneer"), call search_food first when unsure of the macros, scale them to the stated amount, then call log_food with the computed values. If search_food returns no match, do NOT ask the user for macros - use your own nutrition knowledge to estimate calories, protein, carbs and fat for the stated amount, log it, and mention briefly that the numbers are an estimate. Medical data can be tracked and organized, but never diagnose, prescribe, change doses, make emergency decisions, or alter account/security/payment settings. End successful workout creation with navigate(screen="workout", label="Open Workout").
`;

function declarations() {
  return TOOLS.filter((tool) => tool.level < 3).map((tool) => ({
    name: tool.name,
    description: tool.description,
    parameters: { type: "object", properties: tool.parameters, required: tool.required ?? [] },
  }));
}

async function callGemini(contents: GeminiContent[]) {
  const apiKey = process.env["GEMINI_API_KEY"];
  const model = process.env["GEMINI_MODEL"] || "gemini-2.5-flash";
  if (!apiKey) throw new Error("The assistant is not configured.");
  const response = await fetch(`https://generativelanguage.googleapis.com/v1beta/models/${encodeURIComponent(model)}:generateContent`, {
    method: "POST",
    headers: { "Content-Type": "application/json", "x-goog-api-key": apiKey },
    body: JSON.stringify({ systemInstruction: { parts: [{ text: `${WELLCARE_SYSTEM_PROMPT}\n${AGENT_RULES}` }] }, contents, tools: [{ functionDeclarations: declarations() }], generationConfig: { temperature: 0.35, maxOutputTokens: 2048, thinkingConfig: { thinkingBudget: 0 } } }),
  });
  if (!response.ok) {
    console.error("[agent] gemini error", response.status, (await response.text()).slice(0, 800));
    throw new Error(`Assistant provider returned ${response.status}.`);
  }
  const body = (await response.json()) as {
    candidates?: Array<{ content?: Partial<GeminiContent>; finishReason?: string }>;
  };
  const candidate = body.candidates?.[0];
  const parts = candidate?.content?.parts;
  if (!parts?.length) {
    console.error("[agent] empty gemini candidate", candidate?.finishReason ?? "unknown");
    throw new Error("The assistant returned no result.");
  }
  return { role: "model", parts } satisfies GeminiContent;
}

export async function runAgent(
  request: AgentRequest,
  context: { supabase: SupabaseClient<Database>; userId: string },
): Promise<AgentReply> {
  const snapshot = (request.snapshot ?? {}) as Record<string, unknown>;
  const activity = (snapshot["activity"] ?? {}) as Record<string, unknown>;
  const candidate = [snapshot["local_date"], activity["local_date"]].find(
    (value) => typeof value === "string" && /^\d{4}-\d{2}-\d{2}$/.test(value),
  );
  const localDate = typeof candidate === "string" ? candidate : new Date().toISOString().slice(0, 10);
  const contents: GeminiContent[] = [
    {
      role: "user",
      parts: [{ text: `Context for this conversation (do not repeat verbatim). Today's date is ${localDate}. Current app state:\n${JSON.stringify(snapshot).slice(0, 4000)}` }],
    },
    { role: "model", parts: [{ text: "Got it." }] },
    ...request.history.slice(-10).map((message) => ({ role: (message.role === "you" ? "user" : "model") as "user" | "model", parts: [{ text: message.text }] })),
  ];
  contents.push({ role: "user", parts: [{ text: request.question }] });
  const actions: AgentAction[] = [];
  const clientOps: ClientOp[] = [];
  const performed: PerformedAction[] = [];
  let undoable = false;

  for (let turn = 0; turn < 8; turn += 1) {
    const modelContent = await callGemini(contents);
    contents.push(modelContent);
    const calls = modelContent.parts.filter((part) => part.functionCall?.name);
    if (!calls.length) {
      const reply = modelContent.parts.map((part) => part.text ?? "").join("").trim();
      const failures = performed.filter((item) => !item.ok);
      const base = reply || (performed.some((item) => item.ok) ? "Done." : "I couldn't complete that request.");
      const text = failures.length
        ? `${base}\n\nHeads up - this did not save: ${failures.map((item) => `${item.summary}${item.error ? ` (${item.error})` : ""}`).join("; ")}.`
        : base;
      return { ok: failures.length === 0, reply: text, actions, clientOps, performed, undoable };
    }
    const responses: GeminiPart[] = [];
    for (const part of calls) {
      const call = part.functionCall;
      const name = call?.name ?? "";
      const spec = TOOL_MAP[name];
      if (!spec) {
        responses.push({ functionResponse: { name, response: { ok: false, error: "Unsupported action" } } });
        performed.push({ tool: name, summary: "Unsupported action", ok: false, error: "Unsupported action" });
        continue;
      }
      if (spec.level >= 2) {
        return { ok: true, reply: `Review this before I apply it: ${spec.description}`, actions, clientOps, performed, pending: { name, args: call?.args ?? {}, summary: spec.description }, undoable };
      }
      try {
        const output = await executeTool(name, call?.args ?? {}, { ...context, request: request.question, todayDate: localDate });
        if (output.action) actions.push(output.action);
        if (output.clientOp) clientOps.push(output.clientOp);
        if (output.performed) performed.push(output.performed);
        undoable ||= Boolean(output.undoable);
        responses.push({ functionResponse: { name, response: JSON.parse(JSON.stringify({ ok: true, ...output.result })) as Record<string, AgentValue> } });
      } catch (error) {
        const message = error instanceof Error ? error.message : "Action failed";
        performed.push({ tool: name, summary: `${name.replaceAll("_", " ")} failed`, ok: false, error: message });
        responses.push({ functionResponse: { name, response: { ok: false, error: message } } });
      }
    }
    contents.push({ role: "user", parts: responses });
  }
  return { ok: false, reply: "I stopped before making any more changes because the request became too complex. Try splitting it into two steps.", actions, clientOps, performed, undoable };
}

export async function confirmAgentTool(
  request: { name: string; args: Record<string, AgentValue>; originalRequest: string },
  context: { supabase: SupabaseClient<Database>; userId: string },
): Promise<AgentReply> {
  const spec = TOOL_MAP[request.name];
  if (!spec || spec.level !== 2) return { ok: false, reply: "That action cannot be confirmed here.", actions: [], clientOps: [], performed: [], undoable: false };
  try {
    const output = await executeTool(request.name, request.args, { ...context, request: request.originalRequest });
    return { ok: true, reply: `${toolResultSummary(request.name, output)}.`, actions: output.action ? [output.action] : [], clientOps: output.clientOp ? [output.clientOp] : [], performed: output.performed ? [output.performed] : [], undoable: Boolean(output.undoable) };
  } catch (error) {
    const message = error instanceof Error ? error.message : "Action failed";
    return { ok: false, reply: `Couldn't apply that change. Nothing else was changed. ${message}`, actions: [], clientOps: [], performed: [{ tool: request.name, summary: "Confirmation failed", ok: false, error: message }], undoable: false };
  }
}