import { getRequestHeader } from "@tanstack/react-start/server";
import { createClient, type SupabaseClient } from "@supabase/supabase-js";
import type { Database } from "@/integrations/supabase/types";

export interface OptionalAuth {
  supabase: SupabaseClient<Database>;
  userId: string;
}

function isNewApiKey(value: string) {
  return value.startsWith("sb_publishable_") || value.startsWith("sb_secret_");
}

/** Mirrors the generated middleware: opaque sb_ keys must not be sent as bearer tokens. */
function keyAwareFetch(apiKey: string): typeof fetch {
  return (input, init) => {
    const headers = new Headers(
      typeof Request !== "undefined" && input instanceof Request ? input.headers : undefined,
    );
    if (init?.headers) new Headers(init.headers).forEach((value, key) => headers.set(key, value));
    if (isNewApiKey(apiKey) && headers.get("Authorization") === `Bearer ${apiKey}`) {
      headers.delete("Authorization");
    }
    headers.set("apikey", apiKey);
    return fetch(input, { ...init, headers });
  };
}

/**
 * The coach also answers signed-out users (onboarding has "Skip for now").
 * Returns an RLS-scoped client when a valid bearer token is present, else null.
 * `reason` explains why auth was not established so the caller can be honest about it.
 */
export async function resolveOptionalAuth(): Promise<
  { auth: OptionalAuth; reason: null } | { auth: null; reason: string }
> {
  const url = process.env["SUPABASE_URL"];
  const key = process.env["SUPABASE_PUBLISHABLE_KEY"];
  if (!url || !key) return { auth: null, reason: "server-misconfigured" };

  const authHeader = getRequestHeader("authorization");
  if (!authHeader?.startsWith("Bearer ")) return { auth: null, reason: "no-session" };
  const token = authHeader.slice(7).trim();
  if (token.split(".").length !== 3) return { auth: null, reason: "no-session" };

  const supabase = createClient<Database>(url, key, {
    global: { fetch: keyAwareFetch(key), headers: { Authorization: `Bearer ${token}` } },
    auth: { storage: undefined, persistSession: false, autoRefreshToken: false },
  });

  try {
    const { data, error } = await supabase.auth.getUser(token);
    if (!error && data.user?.id) return { auth: { supabase, userId: data.user.id }, reason: null };
  } catch {
    /* fall through to claim verification */
  }

  try {
    const { data, error } = await supabase.auth.getClaims(token);
    const userId = data?.claims?.sub;
    if (error || !userId) return { auth: null, reason: "invalid-session" };
    return { auth: { supabase, userId }, reason: null };
  } catch {
    return { auth: null, reason: "invalid-session" };
  }
}
