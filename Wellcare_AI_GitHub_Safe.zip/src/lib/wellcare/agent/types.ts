/** Client-safe types for the Wellcare AI agent (tool-calling assistant). */

export type ConfirmLevel = 1 | 2 | 3;

export type AgentValue = string | number | boolean | null | AgentValue[] | { [key: string]: AgentValue };

/** Mutations the chat UI applies to the local-first store after the backend saved them. */
export type ClientOp =
  | {
      type: "add_food";
      payload: {
        name: string;
        meal: "breakfast" | "lunch" | "dinner" | "snack";
        calories: number;
        protein: number;
        carbs: number;
        fat: number;
      };
    }
  | { type: "add_water"; payload: { ml: number } }
  | { type: "remove_food"; payload: { name: string } }
  | {
      type: "patch_profile";
      payload: {
        firstName?: string;
        weightKg?: number | null;
        heightCm?: number | null;
        targets?: { calories: number; protein: number; carbs: number; fat: number };
      };
    };

export interface AgentAction {
  label: string;
  to: string;
}

export interface PerformedAction {
  tool: string;
  summary: string;
  ok: boolean;
  error?: string;
}

export interface PendingConfirmation {
  name: string;
  args: Record<string, AgentValue>;
  summary: string;
}

export interface AgentReply {
  ok: boolean;
  reply: string;
  actions: AgentAction[];
  clientOps: ClientOp[];
  performed: PerformedAction[];
  pending?: PendingConfirmation;
  undoable: boolean;
}

export interface AgentChatMessage {
  role: "you" | "coach";
  text: string;
}
