import { z } from "zod";
import type { SupabaseClient } from "@supabase/supabase-js";
import type { Database } from "@/integrations/supabase/types";
import { NAV_ROUTES } from "./catalog";
import type { AgentAction, ClientOp, PerformedAction } from "./types";

type Db = SupabaseClient<Database>;
type Json = string | number | boolean | null | Json[] | { [key: string]: Json | undefined };

export interface ExecuteContext {
  supabase: Db;
  userId: string;
  request: string;
  /** Caller's local calendar date (YYYY-MM-DD); keeps logs on the user's day, not UTC's. */
  todayDate?: string;
}

export interface ToolResult {
  result: Record<string, unknown>;
  action?: AgentAction;
  clientOp?: ClientOp;
  performed?: PerformedAction;
  undoable?: boolean;
}

const objectArgs = z.record(z.string(), z.unknown());
const text = z.string().trim().min(1).max(300);
const optionalText = z.string().trim().max(1000).optional();
const finite = z.number().finite();
const positive = finite.positive();
const nonnegative = finite.nonnegative();
const isoDate = z.string().regex(/^\d{4}-\d{2}-\d{2}$/);
const mealType = z.enum(["breakfast", "lunch", "dinner", "snack"]);
const goalType = z.enum(["lose_fat", "maintain", "build_muscle", "recomp", "performance"]);

const UNDOABLE_TABLES = [
  "meal_items",
  "meals",
  "water_logs",
  "step_entries",
  "sleep_entries",
  "heart_rate_entries",
  "respiratory_rate_entries",
  "blood_glucose_entries",
  "progress_entries",
  "user_goals",
  "reminders",
  "medicines",
  "medicine_logs",
  "tracker_prefs",
  "tracker_goals",
  "workout_programs",
  "program_exercises",
  "workout_sessions",
] as const;
type UndoableTable = (typeof UNDOABLE_TABLES)[number];

function utcToday() {
  return new Date().toISOString().slice(0, 10);
}

function summary(name: string, result: Record<string, unknown>) {
  const value = typeof result["summary"] === "string" ? result["summary"] : `${name.replaceAll("_", " ")} completed`;
  return value;
}

async function audit(
  ctx: ExecuteContext,
  tool: string,
  op: string,
  targetTable: string,
  targetId: string | null,
  previousValue: Record<string, unknown> | null,
  newValue: Record<string, unknown> | null,
  label: string,
) {
  const { error } = await ctx.supabase.from("assistant_actions").insert({
    user_id: ctx.userId,
    tool,
    op,
    summary: label,
    request: ctx.request,
    target_table: targetTable,
    target_id: targetId,
    previous_value: previousValue as Json,
    new_value: newValue as Json,
  });
  if (error) throw new Error(`Action saved, but audit logging failed: ${error.message}`);
}

async function findProgram(ctx: ExecuteContext, value?: string) {
  let query = ctx.supabase.from("workout_programs").select("*").eq("user_id", ctx.userId);
  if (value) query = /^[0-9a-f-]{36}$/i.test(value) ? query.eq("id", value) : query.ilike("name", value);
  else query = query.eq("is_active", true);
  const { data, error } = await query.order("updated_at", { ascending: false }).limit(1).maybeSingle();
  if (error) throw new Error(error.message);
  if (!data) throw new Error(value ? `Workout program “${value}” was not found.` : "No active workout program was found.");
  return data;
}

async function logMutation(
  ctx: ExecuteContext,
  tool: string,
  table: string,
  id: string,
  op: "insert" | "update" | "delete",
  before: Record<string, unknown> | null,
  after: Record<string, unknown> | null,
  label: string,
  clientOp?: ClientOp,
): Promise<ToolResult> {
  await audit(ctx, tool, op, table, id, before, after, label);
  return {
    result: { ok: true, summary: label, id },
    performed: { tool, summary: label, ok: true },
    undoable: true,
    ...(clientOp ? { clientOp } : {}),
  };
}

export async function executeTool(name: string, raw: unknown, ctx: ExecuteContext): Promise<ToolResult> {
  const args = objectArgs.parse(raw);
  const today = () => ctx.todayDate ?? utcToday();

  if (name === "navigate") {
    const parsed = z.object({ screen: z.string(), label: z.string().optional() }).parse(args);
    const to = NAV_ROUTES[parsed.screen];
    if (!to) throw new Error("That screen is not available.");
    const action = { label: parsed.label || `Open ${parsed.screen.replaceAll("_", " ")}`, to };
    return { result: { ok: true, summary: action.label, to }, action };
  }

  if (name === "search_exercises") {
    const parsed = z.object({ query: z.string().optional(), muscle: z.string().optional(), equipment: z.string().optional(), difficulty: z.string().optional(), limit: z.number().int().min(1).max(20).default(12) }).parse(args);
    let query = ctx.supabase.from("exercises").select("id,name,primary_muscle,equipment,difficulty,instructions").or(`is_public.eq.true,created_by.eq.${ctx.userId}`);
    if (parsed.query) query = query.ilike("name", `%${parsed.query}%`);
    if (parsed.muscle) query = query.ilike("primary_muscle", `%${parsed.muscle}%`);
    if (parsed.equipment) query = query.ilike("equipment", `%${parsed.equipment}%`);
    if (parsed.difficulty) query = query.eq("difficulty", parsed.difficulty);
    const { data, error } = await query.limit(parsed.limit);
    if (error) throw new Error(error.message);
    return { result: { matches: data ?? [], count: data?.length ?? 0 } };
  }

  if (name === "create_workout_program") {
    const parsed = z.object({
      name: text,
      description: optionalText,
      goal: goalType.optional(),
      weeks: z.number().int().min(1).max(52).default(8),
      activate: z.boolean().default(false),
      days: z.array(z.object({ label: text, exercises: z.array(z.object({ name: text, exercise_id: z.string().uuid().optional(), sets: z.number().int().min(1).max(20), reps: text, rest_seconds: z.number().int().min(0).max(1800).default(90), notes: optionalText })).min(1) })).min(1).max(7),
    }).parse(args);
    if (parsed.activate) {
      const { error } = await ctx.supabase.from("workout_programs").update({ is_active: false }).eq("user_id", ctx.userId).eq("is_active", true);
      if (error) throw new Error(error.message);
    }
    const { data: program, error } = await ctx.supabase.from("workout_programs").insert({
      user_id: ctx.userId, name: parsed.name, description: parsed.description ?? null, goal: parsed.goal ?? null,
      days_per_week: parsed.days.length, weeks: parsed.weeks, is_active: parsed.activate, generated_by_ai: true,
    }).select().single();
    if (error) throw new Error(error.message);
    const rows = parsed.days.flatMap((day, dayIndex) => day.exercises.map((exercise, position) => ({
      program_id: program.id, user_id: ctx.userId, exercise_id: exercise.exercise_id ?? null,
      day_index: dayIndex, day_label: day.label, position, target_sets: exercise.sets,
      target_reps: exercise.reps, rest_seconds: exercise.rest_seconds, notes: exercise.notes ?? exercise.name,
    })));
    const { error: exerciseError } = await ctx.supabase.from("program_exercises").insert(rows);
    if (exerciseError) {
      await ctx.supabase.from("workout_programs").delete().eq("id", program.id).eq("user_id", ctx.userId);
      throw new Error(`The workout was not saved: ${exerciseError.message}`);
    }
    return logMutation(ctx, name, "workout_programs", program.id, "insert", null, program, `Created ${parsed.name} with ${parsed.days.length} training days`);
  }

  if (name === "list_workout_programs") {
    const { data, error } = await ctx.supabase.from("workout_programs").select("id,name,description,goal,days_per_week,weeks,is_active,updated_at").eq("user_id", ctx.userId).order("updated_at", { ascending: false });
    if (error) throw new Error(error.message);
    return { result: { programs: data ?? [] } };
  }

  if (name === "get_workout_program") {
    const parsed = z.object({ program: z.string().optional() }).parse(args);
    const program = await findProgram(ctx, parsed.program);
    const { data, error } = await ctx.supabase.from("program_exercises").select("*").eq("user_id", ctx.userId).eq("program_id", program.id).order("day_index").order("position");
    if (error) throw new Error(error.message);
    return { result: { program, exercises: data ?? [] } };
  }

  if (["add_exercise_to_program", "remove_exercise_from_program", "update_program_exercise"].includes(name)) {
    const programName = z.string().optional().parse(args["program"]);
    const program = await findProgram(ctx, programName);
    const exerciseName = text.parse(args["name"]);
    const dayLabel = z.string().optional().parse(args["day_label"]);
    if (name === "add_exercise_to_program") {
      const parsed = z.object({ day_label: text, name: text, exercise_id: z.string().uuid().optional(), sets: z.number().int().min(1).max(20).default(3), reps: z.string().default("8-12"), rest_seconds: z.number().int().min(0).max(1800).default(90) }).parse(args);
      const { data: existing } = await ctx.supabase.from("program_exercises").select("position").eq("user_id", ctx.userId).eq("program_id", program.id).eq("day_label", parsed.day_label).order("position", { ascending: false }).limit(1);
      const row = { program_id: program.id, user_id: ctx.userId, exercise_id: parsed.exercise_id ?? null, day_index: 0, day_label: parsed.day_label, position: (existing?.[0]?.position ?? -1) + 1, target_sets: parsed.sets, target_reps: parsed.reps, rest_seconds: parsed.rest_seconds, notes: parsed.name };
      const { data, error } = await ctx.supabase.from("program_exercises").insert(row).select().single();
      if (error) throw new Error(error.message);
      return logMutation(ctx, name, "program_exercises", data.id, "insert", null, data, `Added ${exerciseName} to ${parsed.day_label}`);
    }
    let query = ctx.supabase.from("program_exercises").select("*").eq("user_id", ctx.userId).eq("program_id", program.id).ilike("notes", exerciseName);
    if (dayLabel) query = query.ilike("day_label", dayLabel);
    const { data: row, error: findError } = await query.limit(1).maybeSingle();
    if (findError) throw new Error(findError.message);
    if (!row) throw new Error(`${exerciseName} was not found in ${program.name}.`);
    if (name === "remove_exercise_from_program") {
      const { error } = await ctx.supabase.from("program_exercises").delete().eq("id", row.id).eq("user_id", ctx.userId);
      if (error) throw new Error(error.message);
      return logMutation(ctx, name, "program_exercises", row.id, "delete", row, null, `Removed ${exerciseName} from ${row.day_label ?? "the program"}`);
    }
    const parsed = z.object({ sets: z.number().int().min(1).max(20).optional(), reps: z.string().optional(), rest_seconds: z.number().int().min(0).max(1800).optional(), position: z.number().int().min(0).optional() }).parse(args);
    const patch = { ...(parsed.sets == null ? {} : { target_sets: parsed.sets }), ...(parsed.reps == null ? {} : { target_reps: parsed.reps }), ...(parsed.rest_seconds == null ? {} : { rest_seconds: parsed.rest_seconds }), ...(parsed.position == null ? {} : { position: parsed.position }) };
    if (!Object.keys(patch).length) throw new Error("No workout changes were provided.");
    const { data, error } = await ctx.supabase.from("program_exercises").update(patch).eq("id", row.id).eq("user_id", ctx.userId).select().single();
    if (error) throw new Error(error.message);
    return logMutation(ctx, name, "program_exercises", row.id, "update", row, data, `Updated ${exerciseName} in ${row.day_label ?? program.name}`);
  }

  if (name === "set_active_program") {
    const parsed = z.object({ program: text }).parse(args);
    const program = await findProgram(ctx, parsed.program);
    const { data: previous } = await ctx.supabase.from("workout_programs").select("*").eq("user_id", ctx.userId).eq("is_active", true);
    const { error: offError } = await ctx.supabase.from("workout_programs").update({ is_active: false }).eq("user_id", ctx.userId);
    if (offError) throw new Error(offError.message);
    const { data, error } = await ctx.supabase.from("workout_programs").update({ is_active: true }).eq("id", program.id).eq("user_id", ctx.userId).select().single();
    if (error) throw new Error(error.message);
    return logMutation(ctx, name, "workout_programs", program.id, "update", { active: previous ?? [] }, data, `${program.name} is now your active workout plan`);
  }

  if (name === "delete_workout_program") {
    const parsed = z.object({ program: text }).parse(args);
    const program = await findProgram(ctx, parsed.program);
    const { data: exercises } = await ctx.supabase.from("program_exercises").select("*").eq("user_id", ctx.userId).eq("program_id", program.id);
    const { error } = await ctx.supabase.from("workout_programs").delete().eq("id", program.id).eq("user_id", ctx.userId);
    if (error) throw new Error(error.message);
    return logMutation(ctx, name, "workout_programs", program.id, "delete", { program, exercises: exercises ?? [] }, null, `Deleted ${program.name}`);
  }

  if (name === "search_food") {
    const parsed = z.object({ query: text, limit: z.number().int().min(1).max(20).default(8) }).parse(args);
    const { data, error } = await ctx.supabase.from("foods").select("id,name,brand,serving_label,calories,protein_g,carbs_g,fat_g").or(`is_public.eq.true,created_by.eq.${ctx.userId}`).or(`name.ilike.%${parsed.query}%,brand.ilike.%${parsed.query}%`).limit(parsed.limit);
    if (error) throw new Error(error.message);
    return { result: { matches: data ?? [], count: data?.length ?? 0 } };
  }

  if (name === "log_food") {
    const parsed = z.object({ name: text, meal_type: mealType, calories: nonnegative.max(10000), protein_g: nonnegative.max(1000), carbs_g: nonnegative.max(2000), fat_g: nonnegative.max(1000), quantity: positive.max(10000).default(1), unit: z.string().trim().max(20).default("serving"), logged_on: isoDate.default(today()) }).parse(args);
    let { data: meal, error: mealError } = await ctx.supabase.from("meals").select("*").eq("user_id", ctx.userId).eq("logged_on", parsed.logged_on).eq("meal_type", parsed.meal_type).limit(1).maybeSingle();
    if (mealError) throw new Error(mealError.message);
    if (!meal) {
      const created = await ctx.supabase.from("meals").insert({ user_id: ctx.userId, logged_on: parsed.logged_on, meal_type: parsed.meal_type, title: parsed.meal_type }).select().single();
      if (created.error) throw new Error(created.error.message);
      meal = created.data;
    }
    const row = { meal_id: meal.id, user_id: ctx.userId, name: parsed.name, quantity: parsed.quantity, unit: parsed.unit, calories: parsed.calories, protein_g: parsed.protein_g, carbs_g: parsed.carbs_g, fat_g: parsed.fat_g };
    const { data, error } = await ctx.supabase.from("meal_items").insert(row).select().single();
    if (error) throw new Error(error.message);
    const check = await ctx.supabase.from("meal_items").select("id,name,calories").eq("id", data.id).eq("user_id", ctx.userId).maybeSingle();
    if (check.error) throw new Error(check.error.message);
    if (!check.data) throw new Error("The food entry did not persist. Nothing was saved.");
    return logMutation(ctx, name, "meal_items", data.id, "insert", null, data, `Logged ${parsed.name} for ${parsed.meal_type}`, { type: "add_food", payload: { name: parsed.name, meal: parsed.meal_type, calories: parsed.calories, protein: parsed.protein_g, carbs: parsed.carbs_g, fat: parsed.fat_g } });
  }

  if (name === "remove_food_entry") {
    const parsed = z.object({ name: text }).parse(args);
    const { data: meals, error: mealsError } = await ctx.supabase.from("meals").select("id").eq("user_id", ctx.userId).eq("logged_on", today());
    if (mealsError) throw new Error(mealsError.message);
    const ids = (meals ?? []).map((meal) => meal.id);
    if (!ids.length) throw new Error("There are no food entries today.");
    const { data: row, error: findError } = await ctx.supabase.from("meal_items").select("*").eq("user_id", ctx.userId).in("meal_id", ids).ilike("name", parsed.name).limit(1).maybeSingle();
    if (findError) throw new Error(findError.message);
    if (!row) throw new Error(`${parsed.name} was not found in today’s food log.`);
    const { error } = await ctx.supabase.from("meal_items").delete().eq("id", row.id).eq("user_id", ctx.userId);
    if (error) throw new Error(error.message);
    return logMutation(ctx, name, "meal_items", row.id, "delete", row, null, `Removed ${row.name} from today’s food log`, { type: "remove_food", payload: { name: row.name } });
  }

  if (name === "create_custom_food") {
    const parsed = z.object({ name: text, serving_label: text, serving_grams: positive.default(100), calories: nonnegative, protein_g: nonnegative, carbs_g: nonnegative, fat_g: nonnegative, brand: optionalText }).parse(args);
    const { data, error } = await ctx.supabase.from("foods").insert({ created_by: ctx.userId, name: parsed.name, serving_label: parsed.serving_label, serving_grams: parsed.serving_grams, serving_unit: "serving", calories: parsed.calories, protein_g: parsed.protein_g, carbs_g: parsed.carbs_g, fat_g: parsed.fat_g, brand: parsed.brand ?? null, source: "custom", is_public: false }).select().single();
    if (error) throw new Error(error.message);
    return logMutation(ctx, name, "foods", data.id, "insert", null, data, `Saved ${parsed.name} to your food library`);
  }

  if (name === "log_water") {
    const parsed = z.object({ ml: z.number().int().min(1).max(10000) }).parse(args);
    const { data, error } = await ctx.supabase.from("water_logs").insert({ user_id: ctx.userId, logged_on: today(), amount_ml: parsed.ml }).select().single();
    if (error) throw new Error(error.message);
    return logMutation(ctx, name, "water_logs", data.id, "insert", null, data, `Logged ${parsed.ml} ml of water`, { type: "add_water", payload: { ml: parsed.ml } });
  }

  if (name === "nutrition_summary") {
    const parsed = z.object({ logged_on: isoDate.default(today()) }).parse(args);
    const { data: meals, error } = await ctx.supabase.from("meals").select("id,meal_type,title,meal_items(*)").eq("user_id", ctx.userId).eq("logged_on", parsed.logged_on);
    if (error) throw new Error(error.message);
    const items = (meals ?? []).flatMap((meal) => meal.meal_items ?? []);
    const total = (key: "calories" | "protein_g" | "carbs_g" | "fat_g") => items.reduce((sum, item) => sum + Number(item[key]), 0);
    const { data: profile } = await ctx.supabase.from("profiles").select("daily_calorie_target,daily_protein_target_g,daily_carbs_target_g,daily_fat_target_g").eq("id", ctx.userId).maybeSingle();
    return { result: { date: parsed.logged_on, totals: { calories: total("calories"), protein_g: total("protein_g"), carbs_g: total("carbs_g"), fat_g: total("fat_g") }, targets: profile, meals } };
  }

  if (name === "set_tracker_pref") {
    const parsed = z.object({ key: text, enabled: z.boolean().optional(), pinned_home: z.boolean().optional(), position: z.number().int().min(0).optional() }).parse(args);
    const { data: before } = await ctx.supabase.from("tracker_prefs").select("*").eq("user_id", ctx.userId).eq("tracker_key", parsed.key).maybeSingle();
    const row = { user_id: ctx.userId, tracker_key: parsed.key, enabled: parsed.enabled ?? before?.enabled ?? true, pinned_home: parsed.pinned_home ?? before?.pinned_home ?? false, position: parsed.position ?? before?.position ?? 0 };
    const mutation = before
      ? ctx.supabase.from("tracker_prefs").update(row).eq("id", before.id).eq("user_id", ctx.userId).select().single()
      : ctx.supabase.from("tracker_prefs").insert(row).select().single();
    const { data, error } = await mutation;
    if (error) throw new Error(error.message);
    return logMutation(ctx, name, "tracker_prefs", data.id, before ? "update" : "insert", before, data, `${parsed.key} tracking is ${data.enabled ? "enabled" : "disabled"}${data.pinned_home ? " and shown on Home" : ""}`);
  }

  if (name === "set_tracker_goal") {
    const parsed = z.object({ key: text, target: positive, period: z.enum(["daily", "weekly", "monthly"]).default("daily"), unit: z.string().optional() }).parse(args);
    const { data: before } = await ctx.supabase.from("tracker_goals").select("*").eq("user_id", ctx.userId).eq("tracker_key", parsed.key).maybeSingle();
    const row = { user_id: ctx.userId, tracker_key: parsed.key, target: parsed.target, period: parsed.period, unit: parsed.unit ?? null };
    const mutation = before
      ? ctx.supabase.from("tracker_goals").update(row).eq("id", before.id).eq("user_id", ctx.userId).select().single()
      : ctx.supabase.from("tracker_goals").insert(row).select().single();
    const { data, error } = await mutation;
    if (error) throw new Error(error.message);
    return logMutation(ctx, name, "tracker_goals", data.id, before ? "update" : "insert", before, data, `Set ${parsed.key} goal to ${parsed.target}${parsed.unit ? ` ${parsed.unit}` : ""}`);
  }

  if (name === "list_trackers") {
    const [prefs, goals] = await Promise.all([ctx.supabase.from("tracker_prefs").select("*").eq("user_id", ctx.userId).order("position"), ctx.supabase.from("tracker_goals").select("*").eq("user_id", ctx.userId)]);
    if (prefs.error) throw new Error(prefs.error.message);
    if (goals.error) throw new Error(goals.error.message);
    return { result: { preferences: prefs.data ?? [], goals: goals.data ?? [] } };
  }

  if (name === "log_tracker") {
    const parsed = z.object({ key: z.enum(["water", "steps", "weight", "sleep", "heart_rate", "respiratory", "glucose"]), value: positive, at: z.string().datetime().optional(), note: optionalText }).parse(args);
    if (parsed.key === "water") return executeTool("log_water", { ml: parsed.value }, ctx);
    const at = parsed.at ?? new Date().toISOString();
    const date = at.slice(0, 10);
    const tableRows = {
      steps: ["step_entries", { user_id: ctx.userId, logged_on: date, steps: Math.round(parsed.value), source: "ai" as const }],
      weight: ["progress_entries", { user_id: ctx.userId, recorded_on: date, weight_kg: parsed.value, notes: parsed.note ?? null }],
      sleep: ["sleep_entries", { user_id: ctx.userId, logged_on: date, minutes: Math.round(parsed.value), notes: parsed.note ?? null, source: "ai" as const }],
      heart_rate: ["heart_rate_entries", { user_id: ctx.userId, bpm: Math.round(parsed.value), measured_at: at, context: parsed.note ?? null, source: "ai" as const, is_resting: false }],
      respiratory: ["respiratory_rate_entries", { user_id: ctx.userId, breaths_per_min: Math.round(parsed.value), measured_at: at, context: parsed.note ?? null, source: "ai" as const }],
      glucose: ["blood_glucose_entries", { user_id: ctx.userId, value: parsed.value, unit: "mg_dl" as const, measured_at: at, context: parsed.note ?? null, source: "ai" as const }],
    } as const;
    const selected = tableRows[parsed.key];
    const table = selected[0];
    const mutation = table === "step_entries" ? ctx.supabase.from(table).insert(selected[1]).select().single()
      : table === "progress_entries" ? ctx.supabase.from(table).insert(selected[1]).select().single()
      : table === "sleep_entries" ? ctx.supabase.from(table).insert(selected[1]).select().single()
      : table === "heart_rate_entries" ? ctx.supabase.from(table).insert(selected[1]).select().single()
      : table === "respiratory_rate_entries" ? ctx.supabase.from(table).insert(selected[1]).select().single()
      : ctx.supabase.from("blood_glucose_entries").insert(selected[1]).select().single();
    const { data, error } = await mutation;
    if (error) throw new Error(error.message);
    return logMutation(ctx, name, table, data.id, "insert", null, data, `Logged ${parsed.value} for ${parsed.key.replaceAll("_", " ")}`);
  }

  if (["create_goal", "update_goal", "delete_goal", "list_goals"].includes(name)) {
    if (name === "list_goals") {
      const { data, error } = await ctx.supabase.from("user_goals").select("*").eq("user_id", ctx.userId).order("updated_at", { ascending: false });
      if (error) throw new Error(error.message);
      return { result: { goals: data ?? [] } };
    }
    const title = text.parse(args["title"]);
    if (name === "create_goal") {
      const parsed = z.object({ title: text, metric: z.string().optional(), target_value: finite.optional(), current_value: finite.optional(), unit: z.string().optional(), due_on: isoDate.optional(), notes: optionalText }).parse(args);
      const { data, error } = await ctx.supabase.from("user_goals").insert({ user_id: ctx.userId, title: parsed.title, metric: parsed.metric ?? null, target_value: parsed.target_value ?? null, current_value: parsed.current_value ?? null, unit: parsed.unit ?? null, due_on: parsed.due_on ?? null, notes: parsed.notes ?? null, status: "active" }).select().single();
      if (error) throw new Error(error.message);
      return logMutation(ctx, name, "user_goals", data.id, "insert", null, data, `Created goal: ${title}`);
    }
    const { data: before, error: findError } = await ctx.supabase.from("user_goals").select("*").eq("user_id", ctx.userId).ilike("title", title).limit(1).maybeSingle();
    if (findError) throw new Error(findError.message);
    if (!before) throw new Error(`Goal “${title}” was not found.`);
    if (name === "delete_goal") {
      const { error } = await ctx.supabase.from("user_goals").delete().eq("id", before.id).eq("user_id", ctx.userId);
      if (error) throw new Error(error.message);
      return logMutation(ctx, name, "user_goals", before.id, "delete", before, null, `Deleted goal: ${before.title}`);
    }
    const parsed = z.object({ target_value: finite.optional(), current_value: finite.optional(), due_on: isoDate.optional(), status: z.enum(["active", "completed", "paused"]).optional() }).parse(args);
    const patch = { ...(parsed.target_value == null ? {} : { target_value: parsed.target_value }), ...(parsed.current_value == null ? {} : { current_value: parsed.current_value }), ...(parsed.due_on == null ? {} : { due_on: parsed.due_on }), ...(parsed.status == null ? {} : { status: parsed.status }) };
    const { data, error } = await ctx.supabase.from("user_goals").update(patch).eq("id", before.id).eq("user_id", ctx.userId).select().single();
    if (error) throw new Error(error.message);
    return logMutation(ctx, name, "user_goals", before.id, "update", before, data, `Updated goal: ${before.title}`);
  }

  if (["create_reminder", "update_reminder", "delete_reminder", "list_reminders"].includes(name)) {
    if (name === "list_reminders") {
      const { data, error } = await ctx.supabase.from("reminders").select("*").eq("user_id", ctx.userId).order("time_of_day");
      if (error) throw new Error(error.message);
      return { result: { reminders: data ?? [] } };
    }
    const title = text.parse(args["title"]);
    if (name === "create_reminder") {
      const parsed = z.object({ title: text, time_of_day: z.string().regex(/^([01]\d|2[0-3]):[0-5]\d$/), category: z.string().default("general"), days_of_week: z.array(z.number().int().min(0).max(6)).default([]), notes: optionalText }).parse(args);
      const { data, error } = await ctx.supabase.from("reminders").insert({ user_id: ctx.userId, title: parsed.title, time_of_day: parsed.time_of_day, category: parsed.category, days_of_week: parsed.days_of_week, notes: parsed.notes ?? null, enabled: true }).select().single();
      if (error) throw new Error(error.message);
      return logMutation(ctx, name, "reminders", data.id, "insert", null, data, `Created reminder “${title}” for ${parsed.time_of_day}`);
    }
    const { data: before, error: findError } = await ctx.supabase.from("reminders").select("*").eq("user_id", ctx.userId).ilike("title", title).limit(1).maybeSingle();
    if (findError) throw new Error(findError.message);
    if (!before) throw new Error(`Reminder “${title}” was not found.`);
    if (name === "delete_reminder") {
      const { error } = await ctx.supabase.from("reminders").delete().eq("id", before.id).eq("user_id", ctx.userId);
      if (error) throw new Error(error.message);
      return logMutation(ctx, name, "reminders", before.id, "delete", before, null, `Deleted reminder: ${before.title}`);
    }
    const parsed = z.object({ time_of_day: z.string().regex(/^([01]\d|2[0-3]):[0-5]\d$/).optional(), enabled: z.boolean().optional() }).parse(args);
    const patch = { ...(parsed.time_of_day == null ? {} : { time_of_day: parsed.time_of_day }), ...(parsed.enabled == null ? {} : { enabled: parsed.enabled }) };
    const { data, error } = await ctx.supabase.from("reminders").update(patch).eq("id", before.id).eq("user_id", ctx.userId).select().single();
    if (error) throw new Error(error.message);
    return logMutation(ctx, name, "reminders", before.id, "update", before, data, `Updated reminder: ${before.title}`);
  }

  if (name === "get_profile") {
    const { data, error } = await ctx.supabase.from("profiles").select("*").eq("id", ctx.userId).maybeSingle();
    if (error) throw new Error(error.message);
    return { result: { profile: data } };
  }

  if (name === "update_profile" || name === "set_nutrition_targets") {
    const { data: before, error: findError } = await ctx.supabase.from("profiles").select("*").eq("id", ctx.userId).maybeSingle();
    if (findError) throw new Error(findError.message);
    if (!before) throw new Error("Your profile has not been created yet.");
    const patch = name === "set_nutrition_targets"
      ? (() => { const p = z.object({ calories: z.number().int().min(800).max(10000).optional(), protein_g: z.number().int().min(0).max(1000).optional(), carbs_g: z.number().int().min(0).max(2000).optional(), fat_g: z.number().int().min(0).max(1000).optional() }).parse(args); return { ...(p.calories == null ? {} : { daily_calorie_target: p.calories }), ...(p.protein_g == null ? {} : { daily_protein_target_g: p.protein_g }), ...(p.carbs_g == null ? {} : { daily_carbs_target_g: p.carbs_g }), ...(p.fat_g == null ? {} : { daily_fat_target_g: p.fat_g }) }; })()
      : (() => { const p = z.object({ first_name: z.string().optional(), weight_kg: positive.optional(), height_cm: positive.optional(), goal: goalType.optional(), activity_level: z.enum(["sedentary", "light", "moderate", "active", "very_active"]).optional(), training_days_per_week: z.number().int().min(0).max(7).optional(), diet_type: z.string().optional(), weight_unit: z.enum(["kg", "lb"]).optional(), height_unit: z.enum(["cm", "ftin"]).optional(), equipment: z.array(z.string()).optional(), daily_water_target_ml: z.number().int().min(250).max(15000).optional() }).parse(args); return { ...(p.first_name == null ? {} : { first_name: p.first_name }), ...(p.weight_kg == null ? {} : { weight_kg: p.weight_kg }), ...(p.height_cm == null ? {} : { height_cm: p.height_cm }), ...(p.goal == null ? {} : { goal: p.goal }), ...(p.activity_level == null ? {} : { activity_level: p.activity_level }), ...(p.training_days_per_week == null ? {} : { training_days_per_week: p.training_days_per_week }), ...(p.diet_type == null ? {} : { diet_type: p.diet_type }), ...(p.weight_unit == null ? {} : { weight_unit: p.weight_unit }), ...(p.height_unit == null ? {} : { height_unit: p.height_unit }), ...(p.equipment == null ? {} : { equipment: p.equipment }), ...(p.daily_water_target_ml == null ? {} : { daily_water_target_ml: p.daily_water_target_ml }) }; })();
    if (!Object.keys(patch).length) throw new Error("No profile changes were provided.");
    const { data, error } = await ctx.supabase.from("profiles").update(patch).eq("id", ctx.userId).select().single();
    if (error) throw new Error(error.message);
    const clientPatch: { firstName?: string; weightKg?: number | null; heightCm?: number | null; targets?: { calories: number; protein: number; carbs: number; fat: number } } = {};
    if (data.first_name !== before.first_name && data.first_name != null) clientPatch.firstName = data.first_name;
    if (data.weight_kg !== before.weight_kg) clientPatch.weightKg = data.weight_kg;
    if (data.height_cm !== before.height_cm) clientPatch.heightCm = data.height_cm;
    if (name === "set_nutrition_targets") clientPatch.targets = { calories: data.daily_calorie_target, protein: data.daily_protein_target_g, carbs: data.daily_carbs_target_g, fat: data.daily_fat_target_g };
    return logMutation(ctx, name, "profiles", ctx.userId, "update", before, data, name === "set_nutrition_targets" ? "Updated your nutrition targets" : "Updated your profile", { type: "patch_profile", payload: clientPatch });
  }

  if (name === "progress_report") {
    const parsed = z.object({ days: z.number().int().min(1).max(365).default(30), compare_previous: z.boolean().default(false) }).parse(args);
    const start = new Date(Date.now() - parsed.days * 86400000).toISOString().slice(0, 10);
    const [progress, steps, sleep, water, workouts] = await Promise.all([
      ctx.supabase.from("progress_entries").select("recorded_on,weight_kg,body_fat_pct").eq("user_id", ctx.userId).gte("recorded_on", start).order("recorded_on"),
      ctx.supabase.from("step_entries").select("logged_on,steps").eq("user_id", ctx.userId).gte("logged_on", start),
      ctx.supabase.from("sleep_entries").select("logged_on,minutes,quality").eq("user_id", ctx.userId).gte("logged_on", start),
      ctx.supabase.from("water_logs").select("logged_on,amount_ml").eq("user_id", ctx.userId).gte("logged_on", start),
      ctx.supabase.from("workout_sessions").select("performed_on,duration_seconds,perceived_effort").eq("user_id", ctx.userId).gte("performed_on", start),
    ]);
    const error = progress.error || steps.error || sleep.error || water.error || workouts.error;
    if (error) throw new Error(error.message);
    const weights = (progress.data ?? []).filter((x) => x.weight_kg != null);
    return { result: { days: parsed.days, weight_change_kg: weights.length > 1 ? Number(weights.at(-1)?.weight_kg) - Number(weights[0]?.weight_kg) : null, average_steps: steps.data?.length ? Math.round(steps.data.reduce((n, x) => n + x.steps, 0) / steps.data.length) : null, average_sleep_hours: sleep.data?.length ? sleep.data.reduce((n, x) => n + x.minutes, 0) / sleep.data.length / 60 : null, water_litres: (water.data ?? []).reduce((n, x) => n + x.amount_ml, 0) / 1000, workouts: workouts.data?.length ?? 0 } };
  }

  if (name === "recent_changes") {
    const limit = z.number().int().min(1).max(30).default(10).parse(args["limit"]);
    const { data, error } = await ctx.supabase.from("assistant_actions").select("id,tool,summary,undone,created_at").eq("user_id", ctx.userId).order("created_at", { ascending: false }).limit(limit);
    if (error) throw new Error(error.message);
    return { result: { changes: data ?? [] } };
  }

  if (name === "update_food_entry") {
    const parsed = z.object({ name: text, logged_on: isoDate.default(today()), new_name: z.string().trim().max(300).optional(), meal_type: mealType.optional(), calories: nonnegative.max(10000).optional(), protein_g: nonnegative.max(1000).optional(), carbs_g: nonnegative.max(2000).optional(), fat_g: nonnegative.max(1000).optional(), quantity: positive.optional() }).parse(args);
    const { data: meals, error: mealsError } = await ctx.supabase.from("meals").select("id,meal_type").eq("user_id", ctx.userId).eq("logged_on", parsed.logged_on);
    if (mealsError) throw new Error(mealsError.message);
    const ids = (meals ?? []).map((meal) => meal.id);
    if (!ids.length) throw new Error(`There are no food entries on ${parsed.logged_on}.`);
    const { data: before, error: findError } = await ctx.supabase.from("meal_items").select("*").eq("user_id", ctx.userId).in("meal_id", ids).ilike("name", `%${parsed.name}%`).limit(1).maybeSingle();
    if (findError) throw new Error(findError.message);
    if (!before) throw new Error(`“${parsed.name}” was not found in the ${parsed.logged_on} food log.`);

    let mealId = before.meal_id;
    if (parsed.meal_type) {
      const existing = (meals ?? []).find((meal) => meal.meal_type === parsed.meal_type);
      if (existing) mealId = existing.id;
      else {
        const created = await ctx.supabase.from("meals").insert({ user_id: ctx.userId, logged_on: parsed.logged_on, meal_type: parsed.meal_type, title: parsed.meal_type }).select().single();
        if (created.error) throw new Error(created.error.message);
        mealId = created.data.id;
      }
    }
    const patch = {
      ...(parsed.new_name ? { name: parsed.new_name } : {}),
      ...(parsed.calories == null ? {} : { calories: parsed.calories }),
      ...(parsed.protein_g == null ? {} : { protein_g: parsed.protein_g }),
      ...(parsed.carbs_g == null ? {} : { carbs_g: parsed.carbs_g }),
      ...(parsed.fat_g == null ? {} : { fat_g: parsed.fat_g }),
      ...(parsed.quantity == null ? {} : { quantity: parsed.quantity }),
      ...(mealId === before.meal_id ? {} : { meal_id: mealId }),
    };
    if (!Object.keys(patch).length) throw new Error("No changes were provided for that food entry.");
    const { data, error } = await ctx.supabase.from("meal_items").update(patch).eq("id", before.id).eq("user_id", ctx.userId).select().single();
    if (error) throw new Error(error.message);
    return logMutation(ctx, name, "meal_items", before.id, "update", before, data, `Updated ${data.name} in your food log`);
  }

  if (name === "log_workout_session") {
    const parsed = z.object({
      title: text,
      performed_on: isoDate.default(today()),
      duration_minutes: z.number().finite().min(1).max(600).optional(),
      perceived_effort: z.number().int().min(1).max(10).optional(),
      notes: optionalText,
      sets: z.array(z.object({ exercise_name: text, reps: z.number().int().min(1).max(500).optional(), weight_kg: nonnegative.max(1000).optional(), duration_seconds: z.number().int().min(1).max(36000).optional() })).max(60).optional(),
    }).parse(args);
    const { data: session, error } = await ctx.supabase.from("workout_sessions").insert({
      user_id: ctx.userId,
      title: parsed.title,
      performed_on: parsed.performed_on,
      completed_at: new Date().toISOString(),
      duration_seconds: parsed.duration_minutes == null ? null : Math.round(parsed.duration_minutes * 60),
      perceived_effort: parsed.perceived_effort ?? null,
      notes: parsed.notes ?? null,
    }).select().single();
    if (error) throw new Error(error.message);

    let logged = 0;
    if (parsed.sets?.length) {
      const counters = new Map<string, number>();
      const rows = parsed.sets.map((set) => {
        const next = (counters.get(set.exercise_name.toLowerCase()) ?? 0) + 1;
        counters.set(set.exercise_name.toLowerCase(), next);
        return {
          session_id: session.id,
          user_id: ctx.userId,
          exercise_name: set.exercise_name,
          set_number: next,
          reps: set.reps ?? null,
          weight_kg: set.weight_kg ?? null,
          duration_seconds: set.duration_seconds ?? null,
        };
      });
      const inserted = await ctx.supabase.from("workout_set_logs").insert(rows).select("id");
      if (inserted.error) throw new Error(inserted.error.message);
      logged = inserted.data?.length ?? 0;
    }
    return logMutation(ctx, name, "workout_sessions", session.id, "insert", null, session, `Logged workout “${parsed.title}”${logged ? ` with ${logged} sets` : ""}`);
  }

  if (name === "workout_history") {
    const limit = z.number().int().min(1).max(30).default(10).parse(args["limit"] ?? 10);
    const { data, error } = await ctx.supabase
      .from("workout_sessions")
      .select("id,title,performed_on,duration_seconds,perceived_effort,notes,workout_set_logs(exercise_name,set_number,reps,weight_kg)")
      .eq("user_id", ctx.userId)
      .order("performed_on", { ascending: false })
      .limit(limit);
    if (error) throw new Error(error.message);
    return { result: { sessions: data ?? [], count: data?.length ?? 0 } };
  }

  if (name === "read_tracker_history") {
    const parsed = z.object({ key: z.enum(["water", "steps", "weight", "sleep", "heart_rate", "respiratory", "glucose"]), days: z.number().int().min(1).max(365).default(30) }).parse(args);
    const startDate = new Date(Date.now() - parsed.days * 86400000).toISOString().slice(0, 10);
    const startStamp = new Date(Date.now() - parsed.days * 86400000).toISOString();
    const read = async () => {
      switch (parsed.key) {
        case "water":
          return ctx.supabase.from("water_logs").select("logged_on,amount_ml").eq("user_id", ctx.userId).gte("logged_on", startDate).order("logged_on");
        case "steps":
          return ctx.supabase.from("step_entries").select("logged_on,steps,source").eq("user_id", ctx.userId).gte("logged_on", startDate).order("logged_on");
        case "weight":
          return ctx.supabase.from("progress_entries").select("recorded_on,weight_kg,body_fat_pct").eq("user_id", ctx.userId).gte("recorded_on", startDate).order("recorded_on");
        case "sleep":
          return ctx.supabase.from("sleep_entries").select("logged_on,minutes,quality,source").eq("user_id", ctx.userId).gte("logged_on", startDate).order("logged_on");
        case "heart_rate":
          return ctx.supabase.from("heart_rate_entries").select("measured_at,bpm,is_resting,source").eq("user_id", ctx.userId).gte("measured_at", startStamp).order("measured_at");
        case "respiratory":
          return ctx.supabase.from("respiratory_rate_entries").select("measured_at,breaths_per_min,source").eq("user_id", ctx.userId).gte("measured_at", startStamp).order("measured_at");
        default:
          return ctx.supabase.from("blood_glucose_entries").select("measured_at,value,unit,context,source").eq("user_id", ctx.userId).gte("measured_at", startStamp).order("measured_at");
      }
    };
    const { data, error } = await read();
    if (error) throw new Error(error.message);
    const rows = (data ?? []) as Array<Record<string, unknown>>;
    const field = { water: "amount_ml", steps: "steps", weight: "weight_kg", sleep: "minutes", heart_rate: "bpm", respiratory: "breaths_per_min", glucose: "value" }[parsed.key];
    const values = rows.map((row) => Number(row[field])).filter((value) => Number.isFinite(value));
    const stats = values.length
      ? { count: values.length, average: Math.round((values.reduce((sum, value) => sum + value, 0) / values.length) * 10) / 10, min: Math.min(...values), max: Math.max(...values), latest: values.at(-1) ?? null }
      : { count: 0, average: null, min: null, max: null, latest: null };
    return { result: { key: parsed.key, days: parsed.days, entries: rows.slice(-60), stats } };
  }

  if (name === "list_medicines") {
    const [medicines, logs] = await Promise.all([
      ctx.supabase.from("medicines").select("*").eq("user_id", ctx.userId).eq("is_active", true).order("name"),
      ctx.supabase.from("medicine_logs").select("*").eq("user_id", ctx.userId).eq("logged_on", today()),
    ]);
    if (medicines.error) throw new Error(medicines.error.message);
    if (logs.error) throw new Error(logs.error.message);
    return { result: { medicines: medicines.data ?? [], today: logs.data ?? [] } };
  }

  if (name === "create_medicine") {
    const parsed = z.object({
      name: text,
      dose: z.string().trim().max(60).optional(),
      unit: z.string().trim().max(30).optional(),
      frequency: z.enum(["daily", "twice_daily", "weekly", "as_needed"]),
      times: z.array(z.string().regex(/^([01]\d|2[0-3]):[0-5]\d$/)).min(1).max(8),
      reminder_enabled: z.boolean().default(true),
      notes: optionalText,
    }).parse(args);
    const { data, error } = await ctx.supabase.from("medicines").insert({
      user_id: ctx.userId,
      name: parsed.name,
      dose: parsed.dose ?? null,
      unit: parsed.unit ?? null,
      frequency: parsed.frequency,
      times: parsed.times,
      start_date: today(),
      reminder_enabled: parsed.reminder_enabled,
      notes: parsed.notes ?? null,
      is_active: true,
    }).select().single();
    if (error) throw new Error(error.message);
    return logMutation(ctx, name, "medicines", data.id, "insert", null, data, `Added ${parsed.name} at ${parsed.times.join(", ")}`);
  }

  if (name === "log_medicine") {
    const parsed = z.object({ name: text, status: z.enum(["taken", "missed", "skipped"]), scheduled_time: z.string().regex(/^([01]\d|2[0-3]):[0-5]\d$/).optional() }).parse(args);
    const { data: medicine, error: findError } = await ctx.supabase.from("medicines").select("*").eq("user_id", ctx.userId).ilike("name", `%${parsed.name}%`).limit(1).maybeSingle();
    if (findError) throw new Error(findError.message);
    if (!medicine) throw new Error(`“${parsed.name}” is not in your medicine list.`);
    const { data, error } = await ctx.supabase.from("medicine_logs").insert({
      user_id: ctx.userId,
      medicine_id: medicine.id,
      logged_on: today(),
      scheduled_time: parsed.scheduled_time ?? medicine.times?.[0] ?? null,
      status: parsed.status,
      taken_at: parsed.status === "taken" ? new Date().toISOString() : null,
    }).select().single();
    if (error) throw new Error(error.message);
    return logMutation(ctx, name, "medicine_logs", data.id, "insert", null, data, `Marked ${medicine.name} as ${parsed.status}`);
  }

  if (name === "update_program_exercise") {
    const parsed = z.object({ program: z.string().trim().max(300).optional(), name: text, day_label: z.string().trim().max(120).optional(), sets: z.number().int().min(1).max(20).optional(), reps: z.string().trim().max(40).optional(), rest_seconds: z.number().int().min(0).max(900).optional(), position: z.number().int().min(0).max(50).optional() }).parse(args);
    const program = await findProgram(ctx, parsed.program);
    let query = ctx.supabase.from("program_exercises").select("*").eq("user_id", ctx.userId).eq("program_id", program.id);
    if (parsed.day_label) query = query.ilike("day_label", `%${parsed.day_label}%`);
    const { data: rows, error: findError } = await query;
    if (findError) throw new Error(findError.message);
    const { data: exerciseRows, error: exError } = await ctx.supabase.from("exercises").select("id,name").ilike("name", `%${parsed.name}%`).limit(10);
    if (exError) throw new Error(exError.message);
    const matchIds = new Set((exerciseRows ?? []).map((row) => row.id));
    const target = (rows ?? []).find((row) => (row.exercise_id ? matchIds.has(row.exercise_id) : false) || (row.notes ?? "").toLowerCase().includes(parsed.name.toLowerCase()));
    if (!target) throw new Error(`“${parsed.name}” was not found in ${program.name}.`);
    const patch = {
      ...(parsed.sets == null ? {} : { target_sets: parsed.sets }),
      ...(parsed.reps == null ? {} : { target_reps: parsed.reps }),
      ...(parsed.rest_seconds == null ? {} : { rest_seconds: parsed.rest_seconds }),
      ...(parsed.position == null ? {} : { position: parsed.position }),
    };
    if (!Object.keys(patch).length) throw new Error("No changes were provided for that exercise.");
    const { data, error } = await ctx.supabase.from("program_exercises").update(patch).eq("id", target.id).eq("user_id", ctx.userId).select().single();
    if (error) throw new Error(error.message);
    return logMutation(ctx, name, "program_exercises", target.id, "update", target, data, `Updated ${parsed.name} in ${program.name}`);
  }

  if (name === "undo_last_action") {
    const { data: last, error: findError } = await ctx.supabase
      .from("assistant_actions")
      .select("*")
      .eq("user_id", ctx.userId)
      .eq("undone", false)
      .in("op", ["insert", "update", "delete"])
      .order("created_at", { ascending: false })
      .limit(1)
      .maybeSingle();
    if (findError) throw new Error(findError.message);
    if (!last) throw new Error("There is nothing of mine left to undo.");
    const table = last.target_table as UndoableTable | null;
    if (!table || !UNDOABLE_TABLES.includes(table)) throw new Error("That change can't be undone automatically.");
    const rowId = last.target_id;
    if (last.op === "insert") {
      if (!rowId) throw new Error("That change can't be undone automatically.");
      const { error } = await ctx.supabase.from(table).delete().eq("id", rowId).eq("user_id", ctx.userId);
      if (error) throw new Error(error.message);
    } else if (last.op === "update") {
      const previous = last.previous_value as Record<string, unknown> | null;
      if (!previous || !rowId) throw new Error("The previous value wasn't stored, so I can't undo it.");
      const restore = { ...previous };
      delete restore["id"];
      delete restore["created_at"];
      const { error } = await ctx.supabase.from(table).update(restore as never).eq("id", rowId).eq("user_id", ctx.userId);
      if (error) throw new Error(error.message);
    } else {
      const previous = last.previous_value as Record<string, unknown> | null;
      if (!previous) throw new Error("The deleted record wasn't stored, so I can't restore it.");
      const { error } = await ctx.supabase.from(table).insert(previous as never);
      if (error) throw new Error(error.message);
    }
    const { error: markError } = await ctx.supabase.from("assistant_actions").update({ undone: true }).eq("id", last.id).eq("user_id", ctx.userId);
    if (markError) throw new Error(markError.message);
    return { result: { ok: true, summary: `Undone: ${last.summary}` }, performed: { tool: name, summary: `Undone: ${last.summary}`, ok: true } };
  }

  throw new Error(`${name.replaceAll("_", " ")} is not available yet.`);

}

export function toolResultSummary(name: string, result: ToolResult) {
  return summary(name, result.result);
}