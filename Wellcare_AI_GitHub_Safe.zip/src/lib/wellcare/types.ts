/**
 * Domain types for Wellcare AI.
 *
 * These mirror the Supabase schema (public.profiles, public.meals, ...) so that
 * screens can be wired to real queries later without changing component APIs.
 */

export type MealType = "breakfast" | "lunch" | "dinner" | "snack";

export type Sex = "male" | "female" | "other";

export type PrimaryGoal =
  | "lose_weight"
  | "gain_muscle"
  | "maintain_weight"
  | "build_strength"
  | "improve_fitness"
  | "improve_health";

export type ActivityLevel = "sedentary" | "light" | "moderate" | "active" | "very_active";

export type Experience = "beginner" | "intermediate" | "advanced";

export type Equipment =
  | "full_gym"
  | "home_gym"
  | "dumbbells"
  | "bands"
  | "bodyweight"
  | "other";

export type DietType = "omnivore" | "vegetarian" | "vegan" | "pescatarian" | "no_preference";

export type WeightUnit = "kg" | "lb";
export type HeightUnit = "cm" | "ftin";

export interface MacroTotals {
  calories: number;
  protein: number;
  carbs: number;
  fat: number;
}

export interface FoodEntry {
  id: string;
  meal: MealType;
  name: string;
  time: string;
  calories: number;
  protein: number;
  carbs: number;
  fat: number;
}

export interface DayLog {
  /** YYYY-MM-DD */
  date: string;
  entries: FoodEntry[];
  waterMl: number;
}

export interface HealthConnection {
  connected: boolean;
  provider: "apple_health" | "google_fit" | null;
  metrics: ("steps" | "activity" | "sleep")[];
}

export interface WellcareProfile {
  firstName: string;
  /** Storage path in the private `avatars` bucket (signed-in users). */
  avatarPath: string | null;
  /** Locally stored data URL, used before sign-in or as an offline fallback. */
  avatarLocal: string | null;
  sex: Sex | null;
  /** Which way the user chose to give their age. */
  ageMode: "age" | "birth_year";
  ageYears: number | null;
  birthYear: number | null;
  heightCm: number | null;
  weightKg: number | null;
  bodyFatPct: number | null;
  weightUnit: WeightUnit;
  heightUnit: HeightUnit;
  goal: PrimaryGoal | null;
  secondaryGoals: PrimaryGoal[];
  activityLevel: ActivityLevel | null;
  experience: Experience | null;
  daysPerWeek: number | null;
  equipment: Equipment[];
  dietType: DietType | null;
  allergies: string[];
  avoidedFoods: string[];
  tdeeEstimate: number | null;
  tdeeMethod: string | null;
  targets: MacroTotals | null;
  waterTargetMl: number;
  health: HealthConnection;
  onboardingCompleted: boolean;
}

export const emptyProfile: WellcareProfile = {
  firstName: "",
  avatarPath: null,
  avatarLocal: null,
  sex: null,
  ageMode: "age",
  ageYears: null,
  birthYear: null,
  heightCm: null,
  weightKg: null,
  bodyFatPct: null,
  weightUnit: "kg",
  heightUnit: "cm",
  goal: null,
  secondaryGoals: [],
  activityLevel: null,
  experience: null,
  daysPerWeek: null,
  equipment: [],
  dietType: null,
  allergies: [],
  avoidedFoods: [],
  tdeeEstimate: null,
  tdeeMethod: null,
  targets: null,
  waterTargetMl: 2500,
  health: { connected: false, provider: null, metrics: [] },
  onboardingCompleted: false,
};

export interface WorkoutSummary {
  id: string;
  title: string;
  focus: string;
  exerciseCount: number;
  estimatedMinutes: number;
  completed: boolean;
}
