/**
 * Energy expenditure + macro targets.
 *
 * Three recognised approaches are implemented independently so they can be
 * tuned or swapped without touching the UI:
 *   - Mifflin-St Jeor   (BMR from weight/height/age/sex)
 *   - Harris-Benedict    (revised BMR from weight/height/age/sex)
 *   - Katch-McArdle      (BMR from lean body mass, needs body fat %)
 *
 * Nothing here is presented as medical certainty - the result is a starting
 * estimate that gets corrected by real progress data later.
 */

import type { ActivityLevel, MacroTotals, PrimaryGoal, Sex } from "./types";

export const ACTIVITY_MULTIPLIER: Record<ActivityLevel, number> = {
  sedentary: 1.2,
  light: 1.375,
  moderate: 1.55,
  active: 1.725,
  very_active: 1.9,
};

export interface TdeeInputs {
  sex: Sex;
  ageYears: number;
  heightCm: number;
  weightKg: number;
  bodyFatPct?: number | null;
  activityLevel: ActivityLevel;
}

export interface TdeeMethodResult {
  key: "mifflin_st_jeor" | "harris_benedict" | "katch_mcardle";
  label: string;
  bmr: number;
  tdee: number;
}

export interface TdeeResult {
  methods: TdeeMethodResult[];
  /** Average of every method that had enough information. */
  estimate: number;
  method: string;
  target: number;
  macros: MacroTotals;
}

/** Age from whichever of the two supported inputs the user gave us. */
export function resolveAgeYears(
  p: { ageMode: "age" | "birth_year"; ageYears: number | null; birthYear: number | null },
  now: Date = new Date(),
): number | null {
  const raw = p.ageMode === "birth_year" && p.birthYear ? now.getFullYear() - p.birthYear : p.ageYears;
  if (!raw || !Number.isFinite(raw)) return null;
  return Math.max(13, Math.min(100, Math.round(raw)));
}

export function ageFromBirthDate(birthDate: string, now: Date = new Date()): number {
  const b = new Date(birthDate);
  let age = now.getFullYear() - b.getFullYear();
  const m = now.getMonth() - b.getMonth();
  if (m < 0 || (m === 0 && now.getDate() < b.getDate())) age -= 1;
  return Math.max(13, Math.min(100, age));
}

export function mifflinStJeorBmr({ sex, ageYears, heightCm, weightKg }: TdeeInputs): number {
  const base = 10 * weightKg + 6.25 * heightCm - 5 * ageYears;
  if (sex === "male") return base + 5;
  if (sex === "female") return base - 161;
  return base - 78; // midpoint when sex isn't specified
}

export function harrisBenedictBmr({ sex, ageYears, heightCm, weightKg }: TdeeInputs): number {
  const male = 88.362 + 13.397 * weightKg + 4.799 * heightCm - 5.677 * ageYears;
  const female = 447.593 + 9.247 * weightKg + 3.098 * heightCm - 4.33 * ageYears;
  if (sex === "male") return male;
  if (sex === "female") return female;
  return (male + female) / 2;
}

export function katchMcArdleBmr(inputs: TdeeInputs): number | null {
  const bf = inputs.bodyFatPct;
  if (bf == null || bf <= 0 || bf >= 70) return null; // never fabricate body fat
  const leanMass = inputs.weightKg * (1 - bf / 100);
  return 370 + 21.6 * leanMass;
}

const GOAL_ADJUSTMENT: Record<PrimaryGoal, number> = {
  lose_weight: -0.18,
  gain_muscle: 0.1,
  maintain_weight: 0,
  build_strength: 0.05,
  improve_fitness: 0,
  improve_health: -0.03,
};

/** Protein grams per kg of bodyweight, by goal. */
const PROTEIN_PER_KG: Record<PrimaryGoal, number> = {
  lose_weight: 2.0,
  gain_muscle: 1.9,
  maintain_weight: 1.6,
  build_strength: 1.9,
  improve_fitness: 1.7,
  improve_health: 1.6,
};

/** Fat as a share of total calories, by goal. */
const FAT_SHARE: Record<PrimaryGoal, number> = {
  lose_weight: 0.28,
  gain_muscle: 0.25,
  maintain_weight: 0.3,
  build_strength: 0.27,
  improve_fitness: 0.28,
  improve_health: 0.3,
};

export function calculateMacros(
  calories: number,
  weightKg: number,
  goal: PrimaryGoal,
): MacroTotals {
  const protein = Math.round(PROTEIN_PER_KG[goal] * weightKg);
  const fat = Math.round((calories * FAT_SHARE[goal]) / 9);
  const carbs = Math.max(50, Math.round((calories - protein * 4 - fat * 9) / 4));
  return { calories: Math.round(calories), protein, carbs, fat };
}

export function calculateTdee(inputs: TdeeInputs, goal: PrimaryGoal): TdeeResult {
  const multiplier = ACTIVITY_MULTIPLIER[inputs.activityLevel];
  const methods: TdeeMethodResult[] = [];

  const mifflin = mifflinStJeorBmr(inputs);
  methods.push({
    key: "mifflin_st_jeor",
    label: "Mifflin-St Jeor",
    bmr: Math.round(mifflin),
    tdee: Math.round(mifflin * multiplier),
  });

  const harris = harrisBenedictBmr(inputs);
  methods.push({
    key: "harris_benedict",
    label: "Harris-Benedict",
    bmr: Math.round(harris),
    tdee: Math.round(harris * multiplier),
  });

  const katch = katchMcArdleBmr(inputs);
  if (katch != null) {
    methods.push({
      key: "katch_mcardle",
      label: "Katch-McArdle",
      bmr: Math.round(katch),
      tdee: Math.round(katch * multiplier),
    });
  }

  const estimate = Math.round(
    methods.reduce((sum, m) => sum + m.tdee, 0) / methods.length / 10,
  ) * 10;

  const target = Math.round((estimate * (1 + GOAL_ADJUSTMENT[goal])) / 10) * 10;

  return {
    methods,
    estimate,
    method:
      methods.length === 3
        ? "average_of_three"
        : "average_of_mifflin_and_harris",
    target,
    macros: calculateMacros(target, inputs.weightKg, goal),
  };
}

/** Water target: 35 ml per kg, rounded to the nearest 100 ml, floor 1.8 L. */
export function waterTargetMl(weightKg: number): number {
  return Math.max(1800, Math.round((weightKg * 35) / 100) * 100);
}

/* Unit helpers ---------------------------------------------------------- */

export const lbToKg = (lb: number) => lb * 0.45359237;
export const kgToLb = (kg: number) => kg / 0.45359237;
export const ftInToCm = (ft: number, inch: number) => (ft * 12 + inch) * 2.54;
export const cmToFtIn = (cm: number) => {
  const totalIn = cm / 2.54;
  const ft = Math.floor(totalIn / 12);
  return { ft, inch: Math.round(totalIn - ft * 12) };
};
