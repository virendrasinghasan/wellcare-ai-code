import { createServerFn } from "@tanstack/react-start";
import { z } from "zod";
import type { MealVisionResult } from "./meal-vision.server";

export type { MealVisionItem, MealVisionResult } from "./meal-vision.server";

/** ~6 MB of base64 keeps a phone photo comfortably in range. */
const MAX_BASE64 = 6_000_000;

const Input = z.object({
  imageBase64: z.string().min(100).max(MAX_BASE64),
  mimeType: z.enum(["image/jpeg", "image/png", "image/webp"]).default("image/jpeg"),
});

/** Estimates what's on a plate from a photo. The photo is never stored. */
export const analyseMeal = createServerFn({ method: "POST" })
  .inputValidator((input: unknown) => Input.parse(input))
  .handler(async ({ data }): Promise<MealVisionResult> => {
    const { analyseMealPhoto } = await import("./meal-vision.server");
    return analyseMealPhoto(data.imageBase64, data.mimeType);
  });
