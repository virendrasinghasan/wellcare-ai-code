/**
 * Server-only meal photo analysis through Gemini vision.
 *
 * The photo is sent straight to the model and never stored anywhere. What comes
 * back is a plain list of foods with estimated portions and macros, which the
 * user edits before anything is logged.
 */

export interface MealVisionItem {
  name: string;
  portion: string;
  calories: number;
  protein: number;
  carbs: number;
  fat: number;
}

export interface MealVisionSuccess {
  ok: true;
  title: string;
  items: MealVisionItem[];
  /** One short, blunt line about the plate. */
  verdict: string;
  confidence: "high" | "medium" | "low";
}

export type MealVisionResult = MealVisionSuccess | { ok: false; message: string };

const MODEL = process.env["GEMINI_VISION_MODEL"] || "gemini-2.5-flash";

const SYSTEM = `You are Wellcare AI's food vision estimator.

Look at the photo and identify each distinct food or drink on the plate.
Estimate the portion from visual cues (plate size, utensils, packaging) and give
per-item calories and macros in grams.

Rules:
- Be realistic, not flattering. Cooking oil, dressings, and sauces count.
- Always make your best estimate. Blurry, dim, badly angled, half-eaten and
  home-cooked plates are normal: guess the most likely dish and set confidence
  to "medium" or "low" rather than refusing.
- Home-cooked and mixed dishes (curries, stir fries, casseroles, bowls, sandwiches)
  are broken into their main visible components, including the cooking fat.
- Multiple foods on one plate are listed separately, one item each, even when they
  overlap or share a bowl.
- If a food is ambiguous, pick the most likely everyday version and say so in the verdict.
- Return an empty items array ONLY when the photo clearly contains no food or drink at all.
- The verdict is ONE short sentence in Wellcare AI's voice: blunt, human, a touch
  dry, opinionated about the plate. Judge the balance ("solid protein, the rice is
  doing most of the damage"), never just describe what you see, never lecture, no emoji.
- Reply with JSON only, no markdown fences.


JSON shape:
{"title":string,"confidence":"high"|"medium"|"low","verdict":string,
 "items":[{"name":string,"portion":string,"calories":number,"protein":number,"carbs":number,"fat":number}]}`;

const round = (n: unknown, d = 0): number => {
  const v = typeof n === "number" ? n : Number(n);
  if (!Number.isFinite(v) || v < 0) return 0;
  const f = 10 ** d;
  return Math.round(v * f) / f;
};

function parsePayload(text: string): MealVisionSuccess | null {
  const cleaned = text
    .replace(/^```(?:json)?/i, "")
    .replace(/```$/, "")
    .trim();
  const start = cleaned.indexOf("{");
  const end = cleaned.lastIndexOf("}");
  if (start < 0 || end <= start) return null;

  let raw: Record<string, unknown>;
  try {
    raw = JSON.parse(cleaned.slice(start, end + 1)) as Record<string, unknown>;
  } catch {
    return null;
  }

  const items = Array.isArray(raw["items"]) ? (raw["items"] as Record<string, unknown>[]) : [];
  const parsed: MealVisionItem[] = items
    .map((it) => ({
      name: String(it["name"] ?? "").trim().slice(0, 60),
      portion: String(it["portion"] ?? "1 serving").trim().slice(0, 40),
      calories: round(it["calories"]),
      protein: round(it["protein"], 1),
      carbs: round(it["carbs"], 1),
      fat: round(it["fat"], 1),
    }))
    .filter((it) => it.name.length > 0 && it.calories > 0)
    .slice(0, 12);

  const confidence = ["high", "medium", "low"].includes(String(raw["confidence"]))
    ? (String(raw["confidence"]) as MealVisionSuccess["confidence"])
    : "medium";

  return {
    ok: true,
    title: String(raw["title"] ?? "Your meal").trim().slice(0, 60) || "Your meal",
    items: parsed,
    verdict: String(raw["verdict"] ?? "").trim().slice(0, 240),
    confidence,
  };
}

/** `imageBase64` is the raw base64 body, without the data URL prefix. */
export async function analyseMealPhoto(
  imageBase64: string,
  mimeType: string,
): Promise<MealVisionResult> {
  const apiKey = process.env["GEMINI_API_KEY"];
  if (!apiKey) {
    return { ok: false, message: "My vision model isn't switched on yet. Log this one by hand." };
  }

  let res: Response;
  try {
    res = await fetch(
      `https://generativelanguage.googleapis.com/v1beta/models/${encodeURIComponent(MODEL)}:generateContent`,
      {
        method: "POST",
        headers: { "Content-Type": "application/json", "x-goog-api-key": apiKey },
        body: JSON.stringify({
          systemInstruction: { parts: [{ text: SYSTEM }] },
          contents: [
            {
              role: "user",
              parts: [
                { inline_data: { mime_type: mimeType, data: imageBase64 } },
                {
                  text:
                    "Estimate what's on this plate. For the verdict, give an opinion, not a " +
                    "description - e.g. \"Protein's sorted, the rice is where the calories hide\" " +
                    "or \"Nice plate, but that dressing is quietly a third of the fat.\"",
                },
              ],
            },
          ],
          generationConfig: {
            temperature: 0.35,
            maxOutputTokens: 900,
            responseMimeType: "application/json",
          },
        }),
      },
    );
  } catch {
    return {
      ok: false,
      message: "I couldn't reach the vision model. Check your connection and try again.",
    };
  }

  if (!res.ok) {
    if (res.status === 429) {
      return { ok: false, message: "Too many photos too fast. Give it a minute, then try again." };
    }
    if (res.status === 401 || res.status === 403) {
      return { ok: false, message: "My vision access isn't set up correctly. Log this one by hand." };
    }
    return { ok: false, message: "The vision model had a wobble. Try another photo, or log it by hand." };
  }

  const payload = (await res.json().catch(() => null)) as {
    candidates?: { content?: { parts?: { text?: string }[] } }[];
  } | null;

  const text = (payload?.candidates?.[0]?.content?.parts ?? [])
    .map((p) => p.text ?? "")
    .join("")
    .trim();

  const parsed = text ? parsePayload(text) : null;
  if (!parsed) {
    return { ok: false, message: "I couldn't read that photo. Try better light, or log it by hand." };
  }
  if (parsed.items.length === 0) {
    return {
      ok: false,
      message: "That doesn't look like food to me. Point the camera at the plate and try again.",
    };
  }
  return parsed;
}
