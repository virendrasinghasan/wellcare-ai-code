/** Server-only barcode lookups against public food databases. */

export interface NormalizedFood {
  barcode: string;
  name: string;
  brand: string | null;
  imageUrl: string | null;
  ingredients: string | null;
  category: string | null;
  country: string | null;
  servingLabel: string;
  servingGrams: number;
  servingUnit: string;
  /** Per serving. */
  calories: number;
  protein: number;
  carbs: number;
  fat: number;
  fiber: number | null;
  sugar: number | null;
  sodiumMg: number | null;
  /** Where the numbers came from: our catalogue, Open Food Facts, or USDA. */
  source: "cache" | "off" | "usda";
  sourceProductId: string | null;
}

const num = (v: unknown): number | null => {
  const n = typeof v === "string" ? Number(v) : typeof v === "number" ? v : NaN;
  return Number.isFinite(n) ? n : null;
};

const round = (n: number, d = 1) => Math.round(n * 10 ** d) / 10 ** d;

async function fetchJson(url: string, timeoutMs = 7000): Promise<unknown | null> {
  const controller = new AbortController();
  const timer = setTimeout(() => controller.abort(), timeoutMs);
  try {
    const res = await fetch(url, {
      signal: controller.signal,
      headers: { "User-Agent": "WellcareAI/1.0 (nutrition app)", Accept: "application/json" },
    });
    if (!res.ok) return null;
    return (await res.json()) as unknown;
  } catch {
    return null;
  } finally {
    clearTimeout(timer);
  }
}

/* --------------------------- Open Food Facts --------------------------- */

function fromOpenFoodFacts(barcode: string, payload: unknown): NormalizedFood | null {
  const root = payload as { status?: number; product?: Record<string, unknown> } | null;
  const p = root?.product;
  if (!p || root?.status !== 1) return null;

  const n = (p['nutriments'] ?? {}) as Record<string, unknown>;
  const name =
    (p['product_name'] as string) || (p['generic_name'] as string) || (p['abbreviated_product_name'] as string);
  if (!name) return null;

  const per100Kcal = num(n['energy-kcal_100g']) ?? (num(n['energy_100g']) ? num(n['energy_100g'])! / 4.184 : null);
  if (per100Kcal == null) return null;

  const servingGrams = num(p['serving_quantity']) ?? 100;
  const scale = servingGrams / 100;
  const servingLabel = (p['serving_size'] as string) || `${round(servingGrams, 0)} g`;

  const per = (key: string) => {
    const v = num(n[`${key}_100g`]);
    return v == null ? null : round(v * scale);
  };

  return {
    barcode,
    name: name.trim(),
    brand: ((p['brands'] as string) || "").split(",")[0]?.trim() || null,
    imageUrl: (p['image_front_url'] as string) || (p['image_url'] as string) || null,
    ingredients: (p['ingredients_text'] as string) || null,
    category: ((p['categories'] as string) || "").split(",")[0]?.trim() || null,
    country: ((p['countries'] as string) || "").split(",")[0]?.trim() || null,
    servingLabel,
    servingGrams: round(servingGrams, 0),
    servingUnit: "g",
    calories: Math.round(per100Kcal * scale),
    protein: per("proteins") ?? 0,
    carbs: per("carbohydrates") ?? 0,
    fat: per("fat") ?? 0,
    fiber: per("fiber"),
    sugar: per("sugars"),
    sodiumMg: (() => {
      const sodium = num(n['sodium_100g']);
      if (sodium != null) return Math.round(sodium * 1000 * scale);
      const salt = num(n['salt_100g']);
      return salt != null ? Math.round((salt / 2.5) * 1000 * scale) : null;
    })(),
    source: "off",
    sourceProductId: barcode,
  };
}

/* --------------------------------- USDA --------------------------------- */

function fromUsda(barcode: string, payload: unknown): NormalizedFood | null {
  const root = payload as { foods?: Record<string, unknown>[] } | null;
  const food = root?.foods?.[0];
  if (!food) return null;

  const nutrients = (food['foodNutrients'] ?? []) as Record<string, unknown>[];
  const byName = (needle: string) =>
    num(
      nutrients.find((x) =>
        String(x['nutrientName'] ?? "")
          .toLowerCase()
          .startsWith(needle),
      )?.['value'],
    );

  const kcal = byName("energy");
  if (kcal == null) return null;

  const servingGrams = num(food['servingSize']) ?? 100;
  const scale = servingGrams / 100;
  const label = food['householdServingFullText']
    ? String(food['householdServingFullText'])
    : `${round(servingGrams, 0)} ${String(food['servingSizeUnit'] ?? "g")}`;

  const per = (v: number | null) => (v == null ? null : round(v * scale));

  return {
    barcode,
    name: String(food['description'] ?? "").trim() || "Packaged food",
    brand: (food['brandOwner'] as string) || (food['brandName'] as string) || null,
    imageUrl: null,
    ingredients: (food['ingredients'] as string) || null,
    category: (food['foodCategory'] as string) || null,
    country: "United States",
    servingLabel: label,
    servingGrams: round(servingGrams, 0),
    servingUnit: String(food['servingSizeUnit'] ?? "g"),
    calories: Math.round(kcal * scale),
    protein: per(byName("protein")) ?? 0,
    carbs: per(byName("carbohydrate")) ?? 0,
    fat: per(byName("total lipid")) ?? 0,
    fiber: per(byName("fiber")),
    sugar: per(byName("sugars")),
    sodiumMg: per(byName("sodium")),
    source: "usda",
    sourceProductId: String(food['fdcId'] ?? barcode),
  };
}

export interface BarcodeLookupResult {
  found: boolean;
  food: NormalizedFood | null;
  /** Plain-language explanation when nothing was found. */
  message: string | null;
}

export async function lookupExternalBarcode(barcode: string): Promise<BarcodeLookupResult> {
  const off = fromOpenFoodFacts(
    barcode,
    await fetchJson(`https://world.openfoodfacts.org/api/v2/product/${barcode}.json`),
  );
  if (off) return { found: true, food: off, message: null };

  const key = process.env['USDA_FDC_API_KEY'] ?? "DEMO_KEY";
  const usda = fromUsda(
    barcode,
    await fetchJson(
      `https://api.nal.usda.gov/fdc/v1/foods/search?query=${encodeURIComponent(barcode)}&dataType=Branded&pageSize=1&api_key=${key}`,
    ),
  );
  if (usda) return { found: true, food: usda, message: null };

  return {
    found: false,
    food: null,
    message: "That product isn't in the public databases yet. Type the label numbers in and move on.",
  };
}

/**
 * Full lookup order: our own catalogue first (instant, works signed out),
 * then Open Food Facts, then USDA. Anything new gets cached on the way back.
 */
export async function lookupFood(barcode: string): Promise<BarcodeLookupResult> {
  const { findCachedBarcode, cacheFood } = await import("./catalogue.server");

  const cached = await findCachedBarcode(barcode);
  if (cached) return { found: true, food: cached, message: null };

  const external = await lookupExternalBarcode(barcode);
  if (external.found && external.food) await cacheFood(external.food);
  return external;
}
