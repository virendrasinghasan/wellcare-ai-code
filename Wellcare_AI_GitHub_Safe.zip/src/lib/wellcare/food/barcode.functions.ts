import { createServerFn } from "@tanstack/react-start";

/**
 * Looks a barcode up: our own food catalogue first, then Open Food Facts,
 * then USDA. Runs server-side so the app isn't at the mercy of third-party
 * CORS rules and so results get cached for everyone.
 */
export const lookupBarcode = createServerFn({ method: "GET" })
  .inputValidator((input: { barcode: string }) => {
    const barcode = String(input?.barcode ?? "").replace(/\D/g, "");
    if (barcode.length < 6 || barcode.length > 14) {
      throw new Error("That doesn't look like a barcode.");
    }
    return { barcode };
  })
  .handler(async ({ data }) => {
    const { lookupFood } = await import("./barcode.server");
    return lookupFood(data.barcode);
  });

/** Free-text search across the shared food catalogue. */
export const searchFoods = createServerFn({ method: "GET" })
  .inputValidator((input: { term: string }) => ({
    term: String(input?.term ?? "").slice(0, 60),
  }))
  .handler(async ({ data }) => {
    const { searchCatalogue } = await import("./catalogue.server");
    return { results: await searchCatalogue(data.term) };
  });
