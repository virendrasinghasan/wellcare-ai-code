/**
 * Server-only access to the shared food catalogue in Supabase.
 *
 * Everything here runs with the service role so a lookup works whether or not
 * the person scanning is signed in, and every fresh lookup is cached back so
 * the catalogue keeps growing.
 */
import type { NormalizedFood } from "./barcode.server";

type FoodRow = {
  barcode: string | null;
  name: string;
  brand: string | null;
  image_url: string | null;
  ingredients: string | null;
  category: string | null;
  country: string | null;
  serving_label: string;
  serving_grams: number | string;
  serving_unit: string;
  calories: number | string;
  protein_g: number | string;
  carbs_g: number | string;
  fat_g: number | string;
  fiber_g: number | string | null;
  sugar_g: number | string | null;
  sodium_mg: number | string | null;
  source: string;
  source_product_id: string | null;
};

const n = (v: number | string | null | undefined): number => {
  const x = typeof v === "string" ? Number(v) : (v ?? 0);
  return Number.isFinite(x) ? x : 0;
};
const nOrNull = (v: number | string | null | undefined): number | null =>
  v == null ? null : n(v);

function toNormalized(row: FoodRow, barcode: string): NormalizedFood {
  const source =
    row.source === "usda" ? "usda" : row.source === "seeded" ? "cache" : "off";
  return {
    barcode,
    name: row.name,
    brand: row.brand,
    imageUrl: row.image_url,
    ingredients: row.ingredients,
    category: row.category,
    country: row.country,
    servingLabel: row.serving_label,
    servingGrams: n(row.serving_grams),
    servingUnit: row.serving_unit,
    calories: n(row.calories),
    protein: n(row.protein_g),
    carbs: n(row.carbs_g),
    fat: n(row.fat_g),
    fiber: nOrNull(row.fiber_g),
    sugar: nOrNull(row.sugar_g),
    sodiumMg: nOrNull(row.sodium_mg),
    source: source as NormalizedFood["source"],
    sourceProductId: row.source_product_id,
  };
}

/** Looks a barcode up in our own catalogue. Returns null when we've never seen it. */
export async function findCachedBarcode(barcode: string): Promise<NormalizedFood | null> {
  try {
    const { supabaseAdmin } = await import("@/integrations/supabase/client.server");
    const { data } = await supabaseAdmin
      .from("foods")
      .select("*")
      .eq("barcode", barcode)
      .maybeSingle();
    return data ? toNormalized(data as unknown as FoodRow, barcode) : null;
  } catch {
    return null;
  }
}

/** Saves a freshly looked-up product so the next scan is instant. Never throws. */
export async function cacheFood(food: NormalizedFood): Promise<void> {
  try {
    const { supabaseAdmin } = await import("@/integrations/supabase/client.server");
    await supabaseAdmin.from("foods").upsert(
      {
        barcode: food.barcode,
        name: food.name,
        brand: food.brand,
        image_url: food.imageUrl,
        ingredients: food.ingredients,
        category: food.category,
        country: food.country,
        serving_label: food.servingLabel,
        serving_grams: food.servingGrams,
        serving_unit: food.servingUnit,
        calories: food.calories,
        protein_g: food.protein,
        carbs_g: food.carbs,
        fat_g: food.fat,
        fiber_g: food.fiber,
        sugar_g: food.sugar,
        sodium_mg: food.sodiumMg,
        source: food.source === "usda" ? "usda" : "open_food_facts",
        source_product_id: food.sourceProductId,
        is_public: true,
      },
      { onConflict: "barcode" },
    );
  } catch {
    /* Caching is a nicety, never a blocker. */
  }
}

export interface CatalogueHit {
  barcode: string | null;
  name: string;
  brand: string | null;
  imageUrl: string | null;
  servingLabel: string;
  calories: number;
  protein: number;
  carbs: number;
  fat: number;
}

/** Free-text search across the shared catalogue, best matches first. */
export async function searchCatalogue(term: string, limit = 25): Promise<CatalogueHit[]> {
  const q = term.trim();
  if (q.length < 2) return [];
  try {
    const { supabaseAdmin } = await import("@/integrations/supabase/client.server");
    const pattern = `%${q.replace(/[%_,]/g, " ")}%`;
    const { data } = await supabaseAdmin
      .from("foods")
      .select(
        "barcode,name,brand,image_url,serving_label,calories,protein_g,carbs_g,fat_g",
      )
      .or(`name.ilike.${pattern},brand.ilike.${pattern}`)
      .eq("is_public", true)
      .limit(limit);

    return (data ?? []).map((row) => ({
      barcode: row.barcode,
      name: row.name,
      brand: row.brand,
      imageUrl: row.image_url,
      servingLabel: row.serving_label,
      calories: n(row.calories),
      protein: n(row.protein_g),
      carbs: n(row.carbs_g),
      fat: n(row.fat_g),
    }));
  } catch {
    return [];
  }
}
