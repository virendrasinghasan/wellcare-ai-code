const KEY = "wellcare:route-before-coach";

/** Remember the screen the user was on before opening Wellcare AI. */
export function rememberRoute(path: string) {
  if (typeof window === "undefined") return;
  try {
    window.sessionStorage.setItem(KEY, path);
  } catch {
    /* storage blocked - back button falls back to Home */
  }
}

export function readRouteBeforeCoach(): string {
  if (typeof window === "undefined") return "/";
  try {
    const v = window.sessionStorage.getItem(KEY);
    return v && v !== "/coach" ? v : "/";
  } catch {
    return "/";
  }
}
