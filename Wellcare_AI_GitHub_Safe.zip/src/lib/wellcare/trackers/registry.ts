/**
 * Tracker registry - plain, client-safe metadata shared by the hub, the detail
 * screens and the server functions. Adding a tracker means adding a row here.
 */

export type TrackerKey =
  | "calories"
  | "water"
  | "steps"
  | "workout"
  | "weight"
  | "sleep"
  | "medicine"
  | "heart_rate"
  | "respiratory"
  | "glucose";

export type TrackerKind = "numeric" | "local" | "medicine";

export interface TrackerMeta {
  key: TrackerKey;
  label: string;
  blurb: string;
  /** lucide icon name resolved in the UI layer */
  icon:
    | "flame"
    | "droplets"
    | "footprints"
    | "dumbbell"
    | "scale"
    | "moon"
    | "pill"
    | "heart-pulse"
    | "wind"
    | "droplet";
  kind: TrackerKind;
  unit: string;
  /** Short unit shown next to numbers */
  unitShort: string;
  /** Supabase table for numeric trackers */
  table?: string;
  valueColumn?: string;
  /** "date" columns store a day, "ts" columns store an instant */
  timeColumn?: string;
  timeKind?: "date" | "ts";
  /** One row per day (upsert) rather than an append-only log */
  dailyTotal?: boolean;
  defaultGoal?: number;
  higherIsBetter: boolean;
  inputStep: number;
  inputHint: string;
  /** Existing screen that already owns this data */
  linkTo?: string;
}

export const TRACKERS: TrackerMeta[] = [
  {
    key: "calories",
    label: "Calories",
    blurb: "Food logged against your daily target",
    icon: "flame",
    kind: "local",
    unit: "kcal",
    unitShort: "kcal",
    higherIsBetter: false,
    inputStep: 1,
    inputHint: "Log food to move this",
    linkTo: "/nutrition",
  },
  {
    key: "water",
    label: "Water",
    blurb: "Hydration through the day",
    icon: "droplets",
    kind: "numeric",
    unit: "millilitres",
    unitShort: "ml",
    table: "water_logs",
    valueColumn: "amount_ml",
    timeColumn: "logged_on",
    timeKind: "date",
    defaultGoal: 2500,
    higherIsBetter: true,
    inputStep: 50,
    inputHint: "e.g. 250",
  },
  {
    key: "steps",
    label: "Steps",
    blurb: "Daily movement",
    icon: "footprints",
    kind: "numeric",
    unit: "steps",
    unitShort: "",
    table: "step_entries",
    valueColumn: "steps",
    timeColumn: "logged_on",
    timeKind: "date",
    dailyTotal: true,
    defaultGoal: 10000,
    higherIsBetter: true,
    inputStep: 100,
    inputHint: "e.g. 7800",
  },
  {
    key: "workout",
    label: "Workout",
    blurb: "Sessions and sets",
    icon: "dumbbell",
    kind: "local",
    unit: "sessions",
    unitShort: "",
    higherIsBetter: true,
    inputStep: 1,
    inputHint: "Start a session to log this",
    linkTo: "/workout",
  },
  {
    key: "weight",
    label: "Weight",
    blurb: "Body weight trend",
    icon: "scale",
    kind: "numeric",
    unit: "kilograms",
    unitShort: "kg",
    table: "progress_entries",
    valueColumn: "weight_kg",
    timeColumn: "recorded_on",
    timeKind: "date",
    higherIsBetter: false,
    inputStep: 0.1,
    inputHint: "e.g. 74.5",
  },
  {
    key: "sleep",
    label: "Sleep",
    blurb: "Bedtime, wake time and total rest",
    icon: "moon",
    kind: "numeric",
    unit: "minutes",
    unitShort: "min",
    table: "sleep_entries",
    valueColumn: "minutes",
    timeColumn: "logged_on",
    timeKind: "date",
    defaultGoal: 480,
    higherIsBetter: true,
    inputStep: 5,
    inputHint: "Bedtime and wake time",
  },
  {
    key: "medicine",
    label: "Medicine",
    blurb: "Doses, schedule and what you took",
    icon: "pill",
    kind: "medicine",
    unit: "doses",
    unitShort: "",
    higherIsBetter: true,
    inputStep: 1,
    inputHint: "Add a medicine",
  },
  {
    key: "heart_rate",
    label: "Heart rate",
    blurb: "BPM and resting heart rate",
    icon: "heart-pulse",
    kind: "numeric",
    unit: "beats per minute",
    unitShort: "bpm",
    table: "heart_rate_entries",
    valueColumn: "bpm",
    timeColumn: "measured_at",
    timeKind: "ts",
    higherIsBetter: false,
    inputStep: 1,
    inputHint: "e.g. 62",
  },
  {
    key: "respiratory",
    label: "Respiratory rate",
    blurb: "Breaths per minute",
    icon: "wind",
    kind: "numeric",
    unit: "breaths per minute",
    unitShort: "br/min",
    table: "respiratory_rate_entries",
    valueColumn: "breaths_per_min",
    timeColumn: "measured_at",
    timeKind: "ts",
    higherIsBetter: false,
    inputStep: 1,
    inputHint: "e.g. 14",
  },
  {
    key: "glucose",
    label: "Blood glucose",
    blurb: "Readings with context",
    icon: "droplet",
    kind: "numeric",
    unit: "mg/dL",
    unitShort: "mg/dL",
    table: "blood_glucose_entries",
    valueColumn: "value",
    timeColumn: "measured_at",
    timeKind: "ts",
    higherIsBetter: false,
    inputStep: 1,
    inputHint: "e.g. 96",
  },
];

export const TRACKER_MAP: Record<string, TrackerMeta> = Object.fromEntries(
  TRACKERS.map((t) => [t.key, t]),
);

export function isTrackerKey(value: string): value is TrackerKey {
  return value in TRACKER_MAP;
}

/** Trackers shown on Home unless the user changes it. */
export const DEFAULT_HOME_TRACKERS: TrackerKey[] = ["calories", "water", "steps", "workout"];

export interface TrackerEntry {
  id: string;
  /** ISO instant or YYYY-MM-DD depending on the tracker */
  at: string;
  value: number;
  source: "manual" | "device" | "ai";
  context?: string | null;
}

export interface MedicineItem {
  id: string;
  name: string;
  dose: string | null;
  unit: string | null;
  frequency: string;
  times: string[];
  reminderEnabled: boolean;
  isActive: boolean;
}

export interface MedicineLogItem {
  id: string;
  medicineId: string;
  loggedOn: string;
  scheduledTime: string | null;
  status: "taken" | "missed" | "skipped";
}

/** Formats a tracker value for display (sleep gets h/m). */
export function formatTrackerValue(key: TrackerKey, value: number): string {
  if (key === "sleep") {
    const h = Math.floor(value / 60);
    const m = Math.round(value % 60);
    return `${h}h ${String(m).padStart(2, "0")}m`;
  }
  if (key === "water") return `${(value / 1000).toFixed(1)} L`;
  if (key === "weight") return `${value.toFixed(1)} kg`;
  if (key === "steps" || key === "calories") return Math.round(value).toLocaleString();
  return `${Math.round(value * 10) / 10}`;
}
