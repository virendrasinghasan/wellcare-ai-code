import { createServerFn } from "@tanstack/react-start";
import { z } from "zod";
import { requireSupabaseAuth } from "@/integrations/supabase/auth-middleware";
import { TRACKER_MAP } from "./registry";
import type { MedicineItem, MedicineLogItem, TrackerEntry, TrackerKey } from "./registry";

const KeyInput = z.object({
  key: z.string(),
  days: z.number().int().min(1).max(400).default(90),
});

/** Reads recent entries for a numeric tracker, newest first. */
export const listTrackerEntries = createServerFn({ method: "POST" })
  .middleware([requireSupabaseAuth])
  .inputValidator((input: unknown) => KeyInput.parse(input))
  .handler(async ({ data, context }): Promise<TrackerEntry[]> => {
    const meta = TRACKER_MAP[data.key];
    if (!meta?.table || !meta.valueColumn || !meta.timeColumn) return [];

    const since = new Date(Date.now() - data.days * 86_400_000);
    const sinceValue =
      meta.timeKind === "ts" ? since.toISOString() : since.toISOString().slice(0, 10);

    // eslint-disable-next-line @typescript-eslint/no-explicit-any
    const sb = context.supabase as any;
    const hasSource = meta.table !== "water_logs" && meta.table !== "progress_entries";
    const columns = [
      "id",
      meta.timeColumn,
      meta.valueColumn,
      hasSource ? "source" : null,
      meta.table === "blood_glucose_entries" ||
      meta.table === "heart_rate_entries" ||
      meta.table === "respiratory_rate_entries"
        ? "context"
        : null,
    ]
      .filter(Boolean)
      .join(", ");

    const { data: rows, error } = await sb
      .from(meta.table)
      .select(columns)
      .eq("user_id", context.userId)
      .gte(meta.timeColumn, sinceValue)
      .order(meta.timeColumn, { ascending: false })
      .limit(500);

    if (error) throw new Error(error.message);

    // eslint-disable-next-line @typescript-eslint/no-explicit-any
    return (rows ?? [])
      // eslint-disable-next-line @typescript-eslint/no-explicit-any
      .filter((r: any) => r[meta.valueColumn!] !== null)
      // eslint-disable-next-line @typescript-eslint/no-explicit-any
      .map((r: any) => ({
        id: String(r.id),
        at: String(r[meta.timeColumn!]),
        value: Number(r[meta.valueColumn!]),
        source: (r.source ?? "manual") as TrackerEntry["source"],
        context: r.context ?? null,
      }));
  });

const AddInput = z.object({
  key: z.string(),
  value: z.number().finite(),
  at: z.string().optional(),
  context: z.string().max(120).optional(),
  bedtime: z.string().optional(),
  wakeTime: z.string().optional(),
});

/** Adds a manual reading. Steps replace the day's manual total; the rest append. */
export const addTrackerEntry = createServerFn({ method: "POST" })
  .middleware([requireSupabaseAuth])
  .inputValidator((input: unknown) => AddInput.parse(input))
  .handler(async ({ data, context }) => {
    const meta = TRACKER_MAP[data.key];
    if (!meta?.table || !meta.valueColumn || !meta.timeColumn) {
      throw new Error("That tracker does not accept manual entries.");
    }

    const when = data.at ? new Date(data.at) : new Date();
    if (Number.isNaN(when.getTime())) throw new Error("That date does not look right.");
    const timeValue =
      meta.timeKind === "ts" ? when.toISOString() : when.toISOString().slice(0, 10);

    // eslint-disable-next-line @typescript-eslint/no-explicit-any
    const row: Record<string, any> = {
      user_id: context.userId,
      [meta.timeColumn]: timeValue,
      [meta.valueColumn]: data.value,
    };
    if (meta.table !== "water_logs" && meta.table !== "progress_entries") row['source'] = "manual";
    if (data.context) row['context'] = data.context;
    if (meta.table === "sleep_entries") {
      if (data.bedtime) row['bedtime'] = new Date(data.bedtime).toISOString();
      if (data.wakeTime) row['wake_time'] = new Date(data.wakeTime).toISOString();
      if (data.context) {
        delete row['context'];
        row['notes'] = data.context;
      }
    }

    // eslint-disable-next-line @typescript-eslint/no-explicit-any
    const sb = context.supabase as any;
    const query = meta.dailyTotal
      ? sb.from(meta.table).upsert(row, { onConflict: "user_id,logged_on,source" })
      : sb.from(meta.table).insert(row);
    const { error } = await query;
    if (error) throw new Error(error.message);
    return { ok: true };
  });

export const deleteTrackerEntry = createServerFn({ method: "POST" })
  .middleware([requireSupabaseAuth])
  .inputValidator((input: unknown) =>
    z.object({ key: z.string(), id: z.string().uuid() }).parse(input),
  )
  .handler(async ({ data, context }) => {
    const meta = TRACKER_MAP[data.key];
    if (!meta?.table) throw new Error("Unknown tracker.");
    // eslint-disable-next-line @typescript-eslint/no-explicit-any
    const sb = context.supabase as any;
    const { error } = await sb
      .from(meta.table)
      .delete()
      .eq("id", data.id)
      .eq("user_id", context.userId);
    if (error) throw new Error(error.message);
    return { ok: true };
  });

/** Which trackers the user keeps on the dashboard. */
export const listTrackerPrefs = createServerFn({ method: "GET" })
  .middleware([requireSupabaseAuth])
  .handler(async ({ context }) => {
    const { data, error } = await context.supabase
      .from("tracker_prefs")
      .select("tracker_key, enabled, pinned_home, position")
      .eq("user_id", context.userId)
      .order("position", { ascending: true });
    if (error) throw new Error(error.message);
    return (data ?? []).map((r) => ({
      key: r.tracker_key as TrackerKey,
      enabled: r.enabled,
      pinnedHome: r.pinned_home,
      position: r.position,
    }));
  });

export const setTrackerPref = createServerFn({ method: "POST" })
  .middleware([requireSupabaseAuth])
  .inputValidator((input: unknown) =>
    z
      .object({
        key: z.string(),
        enabled: z.boolean().optional(),
        pinnedHome: z.boolean().optional(),
        position: z.number().int().optional(),
      })
      .parse(input),
  )
  .handler(async ({ data, context }) => {
    const patch = {
      user_id: context.userId,
      tracker_key: data.key,
      ...(data.enabled === undefined ? {} : { enabled: data.enabled }),
      ...(data.pinnedHome === undefined ? {} : { pinned_home: data.pinnedHome }),
      ...(data.position === undefined ? {} : { position: data.position }),
    };
    const { error } = await context.supabase
      .from("tracker_prefs")
      .upsert(patch, { onConflict: "user_id,tracker_key" });
    if (error) throw new Error(error.message);
    return { ok: true };
  });

export const listTrackerGoals = createServerFn({ method: "GET" })
  .middleware([requireSupabaseAuth])
  .handler(async ({ context }) => {
    const { data, error } = await context.supabase
      .from("tracker_goals")
      .select("tracker_key, target, unit, period")
      .eq("user_id", context.userId);
    if (error) throw new Error(error.message);
    return (data ?? []).map((r) => ({
      key: r.tracker_key as TrackerKey,
      target: Number(r.target),
      unit: r.unit,
      period: r.period,
    }));
  });

export const setTrackerGoal = createServerFn({ method: "POST" })
  .middleware([requireSupabaseAuth])
  .inputValidator((input: unknown) =>
    z
      .object({
        key: z.string(),
        target: z.number().finite().positive(),
        unit: z.string().max(20).optional(),
        period: z.enum(["daily", "weekly", "monthly"]).default("daily"),
      })
      .parse(input),
  )
  .handler(async ({ data, context }) => {
    const { error } = await context.supabase.from("tracker_goals").upsert(
      {
        user_id: context.userId,
        tracker_key: data.key,
        target: data.target,
        unit: data.unit ?? null,
        period: data.period,
      },
      { onConflict: "user_id,tracker_key" },
    );
    if (error) throw new Error(error.message);
    return { ok: true };
  });

/* ------------------------------- medicine -------------------------------- */

export const listMedicines = createServerFn({ method: "GET" })
  .middleware([requireSupabaseAuth])
  .handler(
    async ({ context }): Promise<{ medicines: MedicineItem[]; todayLogs: MedicineLogItem[] }> => {
      const today = new Date().toISOString().slice(0, 10);
      const [meds, logs] = await Promise.all([
        context.supabase
          .from("medicines")
          .select("*")
          .eq("user_id", context.userId)
          .order("created_at", { ascending: true }),
        context.supabase
          .from("medicine_logs")
          .select("*")
          .eq("user_id", context.userId)
          .eq("logged_on", today),
      ]);
      if (meds.error) throw new Error(meds.error.message);
      if (logs.error) throw new Error(logs.error.message);

      return {
        medicines: (meds.data ?? []).map((m) => ({
          id: m.id,
          name: m.name,
          dose: m.dose,
          unit: m.unit,
          frequency: m.frequency,
          times: m.times ?? [],
          reminderEnabled: m.reminder_enabled,
          isActive: m.is_active,
        })),
        todayLogs: (logs.data ?? []).map((l) => ({
          id: l.id,
          medicineId: l.medicine_id,
          loggedOn: l.logged_on,
          scheduledTime: l.scheduled_time,
          status: l.status,
        })),
      };
    },
  );

export const addMedicine = createServerFn({ method: "POST" })
  .middleware([requireSupabaseAuth])
  .inputValidator((input: unknown) =>
    z
      .object({
        name: z.string().min(1).max(80),
        dose: z.string().max(40).optional(),
        unit: z.string().max(20).optional(),
        frequency: z.string().max(40).default("daily"),
        times: z.array(z.string().max(10)).max(8).default([]),
        reminderEnabled: z.boolean().default(false),
      })
      .parse(input),
  )
  .handler(async ({ data, context }) => {
    const { error } = await context.supabase.from("medicines").insert({
      user_id: context.userId,
      name: data.name,
      dose: data.dose ?? null,
      unit: data.unit ?? null,
      frequency: data.frequency,
      times: data.times,
      reminder_enabled: data.reminderEnabled,
    });
    if (error) throw new Error(error.message);
    return { ok: true };
  });

export const deleteMedicine = createServerFn({ method: "POST" })
  .middleware([requireSupabaseAuth])
  .inputValidator((input: unknown) => z.object({ id: z.string().uuid() }).parse(input))
  .handler(async ({ data, context }) => {
    const { error } = await context.supabase
      .from("medicines")
      .delete()
      .eq("id", data.id)
      .eq("user_id", context.userId);
    if (error) throw new Error(error.message);
    return { ok: true };
  });

export const logMedicine = createServerFn({ method: "POST" })
  .middleware([requireSupabaseAuth])
  .inputValidator((input: unknown) =>
    z
      .object({
        medicineId: z.string().uuid(),
        scheduledTime: z.string().max(10).nullable().default(null),
        status: z.enum(["taken", "missed", "skipped"]),
      })
      .parse(input),
  )
  .handler(async ({ data, context }) => {
    const { error } = await context.supabase.from("medicine_logs").upsert(
      {
        user_id: context.userId,
        medicine_id: data.medicineId,
        scheduled_time: data.scheduledTime ?? "",
        status: data.status,
        taken_at: data.status === "taken" ? new Date().toISOString() : null,
      },
      { onConflict: "medicine_id,logged_on,scheduled_time" },
    );
    if (error) throw new Error(error.message);
    return { ok: true };
  });
