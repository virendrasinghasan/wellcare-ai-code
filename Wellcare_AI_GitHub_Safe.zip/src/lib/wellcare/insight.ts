import type { MacroTotals, WellcareProfile } from "./types";

/**
 * Deterministic stand-in for the AI coach. Same tone the model will use:
 * blunt, human, occasionally funny, never cheerleader-y. Swapped for a real
 * generation call later - the inputs are already the user's real data.
 */
export function buildInsight(
  profile: WellcareProfile,
  consumed: MacroTotals,
  entryCount: number,
  hour: number = new Date().getHours(),
): string {
  const targets = profile.targets;
  const name = profile.firstName || "there";

  if (!targets) {
    return `Finish setting up your profile, ${name} - I can't coach numbers I don't have.`;
  }

  if (entryCount === 0) {
    if (hour < 11) return "Nothing logged yet. Start with breakfast and today stays honest.";
    if (hour < 17)
      return "Half the day gone, zero food logged. Either you didn't eat or you didn't tell me. One of those is fixable.";
    return "Nothing logged today. Log what you actually ate - guessing tomorrow won't help either.";
  }

  const proteinLeft = targets.protein - consumed.protein;
  const calsLeft = targets.calories - consumed.calories;

  if (consumed.calories > targets.calories * 1.12) {
    return `You're ${Math.round(consumed.calories - targets.calories)} kcal over target. Not a disaster - just don't stack a second day on it.`;
  }

  if (proteinLeft > 35 && hour >= 15) {
    return `You're ${Math.round(proteinLeft)}g short on protein today. Dinner has some work to do.`;
  }

  if (calsLeft > targets.calories * 0.45 && hour >= 18) {
    return `${Math.round(calsLeft)} kcal still on the table this late. Under-eating isn't discipline, it's a rebound waiting to happen.`;
  }

  if (proteinLeft <= 0) {
    return `Protein target hit with ${Math.round(calsLeft)} kcal left. That's the hard part done - the rest is just food.`;
  }

  if (profile.daysPerWeek && profile.daysPerWeek >= 5 && hour < 12) {
    return `${profile.daysPerWeek} training days a week only works if you eat like it. ${Math.round(proteinLeft)}g protein left today.`;
  }

  return `${Math.round(calsLeft)} kcal and ${Math.round(proteinLeft)}g protein left. Comfortable pace - keep it boring.`;
}
