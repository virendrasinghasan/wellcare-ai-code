import {
  createContext,
  useCallback,
  useContext,
  useEffect,
  useMemo,
  useRef,
  useState,
  type ReactNode,
} from "react";
import { supabase } from "@/integrations/supabase/client";
import { loadProfile, saveProfile } from "./profile.functions";
import { deleteDiaryEntry, loadDiary, saveDiaryEntry, saveWaterLog } from "./diary.functions";
import { emptyProfile } from "./types";
import type { DayLog, FoodEntry, MacroTotals, WellcareProfile } from "./types";

const STORAGE_KEY = "wellcare:state:v1";

interface PersistedState {
  profile: WellcareProfile;
  logs: Record<string, DayLog>;
}

export function todayKey(d: Date = new Date()): string {
  return `${d.getFullYear()}-${String(d.getMonth() + 1).padStart(2, "0")}-${String(d.getDate()).padStart(2, "0")}`;
}

const emptyState: PersistedState = { profile: emptyProfile, logs: {} };

function readLocal(): PersistedState {
  if (typeof window === "undefined") return emptyState;
  try {
    const raw = window.localStorage.getItem(STORAGE_KEY);
    if (!raw) return emptyState;
    const parsed = JSON.parse(raw) as Partial<PersistedState>;
    return {
      profile: { ...emptyProfile, ...(parsed.profile ?? {}) },
      logs: parsed.logs ?? {},
    };
  } catch {
    return emptyState;
  }
}

function writeLocal(state: PersistedState) {
  if (typeof window === "undefined") return;
  try {
    window.localStorage.setItem(STORAGE_KEY, JSON.stringify(state));
  } catch {
    /* storage full or blocked - the app still works in-memory */
  }
}

interface WellcareContextValue {
  hydrated: boolean;
  signedIn: boolean;
  profile: WellcareProfile;
  logs: Record<string, DayLog>;
  todayLog: DayLog;
  consumed: MacroTotals;
  updateProfile: (patch: Partial<WellcareProfile>) => void;
  completeOnboarding: (patch: Partial<WellcareProfile>) => Promise<void>;
  addEntry: (entry: Omit<FoodEntry, "id" | "time"> & { time?: string }) => void;
  removeEntry: (id: string) => void;
  addWater: (ml: number) => void;
  /** Re-pull meals and water from Supabase (used after the assistant writes). */
  refreshDiary: () => Promise<void>;
  resetAll: () => void;
}

const WellcareContext = createContext<WellcareContextValue | null>(null);

export function WellcareProvider({ children }: { children: ReactNode }) {
  const [state, setState] = useState<PersistedState>(emptyState);
  const [hydrated, setHydrated] = useState(false);
  const [signedIn, setSignedIn] = useState(false);
  const stateRef = useRef(state);
  stateRef.current = state;
  const refreshDiaryRef = useRef<() => Promise<void>>(async () => {});

  // Hydrate from localStorage, then overlay the Supabase profile if signed in.
  useEffect(() => {
    let cancelled = false;
    const local = readLocal();
    setState(local);

    (async () => {
      const { data } = await supabase.auth.getSession();
      const hasSession = Boolean(data.session);
      if (cancelled) return;
      setSignedIn(hasSession);

      if (hasSession) {
        try {
          const remote = await loadProfile();
          if (cancelled) return;
          if (remote?.onboardingCompleted) {
            setState((s) => ({ ...s, profile: remote }));
          } else if (local.profile.onboardingCompleted) {
            // Skipped auth first, signed in later - push local answers up.
            await saveProfile({ data: local.profile });
          }
        } catch {
          /* offline or RLS hiccup - local state keeps the app usable */
        }
        await refreshDiaryRef.current();
      }
      if (!cancelled) setHydrated(true);
    })();

    const { data: sub } = supabase.auth.onAuthStateChange((event, session) => {
      if (event !== "SIGNED_IN" && event !== "SIGNED_OUT") return;
      setSignedIn(Boolean(session));
      if (event === "SIGNED_IN") {
        if (stateRef.current.profile.onboardingCompleted) {
          void saveProfile({ data: stateRef.current.profile }).catch(() => {});
        }
        void refreshDiaryRef.current();
      }
    });

    return () => {
      cancelled = true;
      sub.subscription.unsubscribe();
    };
  }, []);

  const persist = useCallback((next: PersistedState) => {
    setState(next);
    writeLocal(next);
  }, []);

  const refreshDiary = useCallback(async () => {
    const { data } = await supabase.auth.getSession();
    if (!data.session) return;
    const to = todayKey();
    const fromDate = new Date();
    fromDate.setDate(fromDate.getDate() - 29);
    const from = todayKey(fromDate);
    try {
      const logs = await loadDiary({ data: { from, to } });
      // Server is the source of truth for the synced window; keep older local days.
      persist({ ...stateRef.current, logs: { ...stateRef.current.logs, ...logs } });
    } catch {
      /* offline - local copy stays on screen */
    }
  }, [persist]);
  refreshDiaryRef.current = refreshDiary;

  const updateProfile = useCallback(
    (patch: Partial<WellcareProfile>) => {
      const next = {
        ...stateRef.current,
        profile: { ...stateRef.current.profile, ...patch },
      };
      persist(next);
    },
    [persist],
  );

  const completeOnboarding = useCallback(
    async (patch: Partial<WellcareProfile>) => {
      const profile = {
        ...stateRef.current.profile,
        ...patch,
        onboardingCompleted: true,
      };
      persist({ ...stateRef.current, profile });
      const { data } = await supabase.auth.getSession();
      if (data.session) {
        try {
          await saveProfile({ data: profile });
        } catch {
          /* queued: it re-syncs on the next SIGNED_IN */
        }
      }
    },
    [persist],
  );

  const key = todayKey();
  const todayLog = state.logs[key] ?? { date: key, entries: [], waterMl: 0 };

  const addEntry = useCallback<WellcareContextValue["addEntry"]>(
    (entry) => {
      const k = todayKey();
      const current = stateRef.current.logs[k] ?? { date: k, entries: [], waterMl: 0 };
      const full: FoodEntry = {
        id: crypto.randomUUID(),
        time:
          entry.time ??
          new Date().toLocaleTimeString([], { hour: "2-digit", minute: "2-digit" }),
        ...entry,
      };
      persist({
        ...stateRef.current,
        logs: { ...stateRef.current.logs, [k]: { ...current, entries: [...current.entries, full] } },
      });
      void (async () => {
        const { data } = await supabase.auth.getSession();
        if (!data.session) return;
        try {
          await saveDiaryEntry({
            data: {
              date: k,
              meal: full.meal,
              name: full.name,
              quantity: 1,
              unit: "serving",
              calories: full.calories,
              protein: full.protein,
              carbs: full.carbs,
              fat: full.fat,
            },
          });
          await refreshDiaryRef.current();
        } catch {
          /* stays local; the next refresh reconciles */
        }
      })();
    },
    [persist],
  );

  const removeEntry = useCallback(
    (id: string) => {
      const k = todayKey();
      const current = stateRef.current.logs[k];
      if (!current) return;
      persist({
        ...stateRef.current,
        logs: {
          ...stateRef.current.logs,
          [k]: { ...current, entries: current.entries.filter((e) => e.id !== id) },
        },
      });
      void (async () => {
        const { data } = await supabase.auth.getSession();
        if (!data.session) return;
        try {
          await deleteDiaryEntry({ data: { id } });
        } catch {
          /* the row may be local-only */
        }
      })();
    },
    [persist],
  );

  const addWater = useCallback(
    (ml: number) => {
      const k = todayKey();
      const current = stateRef.current.logs[k] ?? { date: k, entries: [], waterMl: 0 };
      persist({
        ...stateRef.current,
        logs: {
          ...stateRef.current.logs,
          [k]: { ...current, waterMl: Math.max(0, current.waterMl + ml) },
        },
      });
      void (async () => {
        const { data } = await supabase.auth.getSession();
        if (!data.session) return;
        try {
          await saveWaterLog({ data: { date: k, ml } });
        } catch {
          /* keeps the local value */
        }
      })();
    },
    [persist],
  );

  const resetAll = useCallback(() => {
    persist(emptyState);
  }, [persist]);

  const consumed = useMemo<MacroTotals>(
    () =>
      todayLog.entries.reduce(
        (acc, e) => ({
          calories: acc.calories + e.calories,
          protein: acc.protein + e.protein,
          carbs: acc.carbs + e.carbs,
          fat: acc.fat + e.fat,
        }),
        { calories: 0, protein: 0, carbs: 0, fat: 0 },
      ),
    [todayLog],
  );

  const value = useMemo<WellcareContextValue>(
    () => ({
      hydrated,
      signedIn,
      profile: state.profile,
      logs: state.logs,
      todayLog,
      consumed,
      updateProfile,
      completeOnboarding,
      addEntry,
      removeEntry,
      addWater,
      refreshDiary,
      resetAll,
    }),
    [
      hydrated,
      signedIn,
      state.profile,
      state.logs,
      todayLog,
      consumed,
      updateProfile,
      completeOnboarding,
      addEntry,
      removeEntry,
      addWater,
      refreshDiary,
      resetAll,
    ],
  );

  return <WellcareContext.Provider value={value}>{children}</WellcareContext.Provider>;
}

export function useWellcare(): WellcareContextValue {
  const ctx = useContext(WellcareContext);
  if (!ctx) throw new Error("useWellcare must be used inside <WellcareProvider>");
  return ctx;
}
