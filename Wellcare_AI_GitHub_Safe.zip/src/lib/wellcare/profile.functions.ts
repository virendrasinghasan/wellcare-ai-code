import { createServerFn } from "@tanstack/react-start";
import { requireSupabaseAuth } from "@/integrations/supabase/auth-middleware";
import { profileFromRow, profileToRow, type ProfileRow } from "./profile-mapping";
import type { WellcareProfile } from "./types";

/** Load the signed-in user's Wellcare profile (null when never onboarded). */
export const loadProfile = createServerFn({ method: "GET" })
  .middleware([requireSupabaseAuth])
  .handler(async ({ context }): Promise<WellcareProfile | null> => {
    const { data, error } = await context.supabase
      .from("profiles")
      .select("*")
      .eq("id", context.userId)
      .maybeSingle();

    if (error) throw new Error(error.message);
    if (!data) return null;
    return profileFromRow(data as unknown as ProfileRow);
  });

/** Persist onboarding answers + calculated targets for the signed-in user. */
export const saveProfile = createServerFn({ method: "POST" })
  .middleware([requireSupabaseAuth])
  .inputValidator((input: WellcareProfile) => input)
  .handler(async ({ data, context }) => {
    const row = profileToRow(data, context.userId);
    const { error } = await context.supabase
      .from("profiles")
      .upsert(row as never, { onConflict: "id" });
    if (error) throw new Error(error.message);
    return { ok: true };
  });
