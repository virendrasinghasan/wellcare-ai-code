import type { WellcareProfile } from "../types";
import { PLANS } from "./plans";
import type { Gear, WorkoutPlan } from "./types";

/** Maps the onboarding equipment answers onto library equipment tags. */
export function availableGear(profile: WellcareProfile): Gear[] {
  const set = new Set<Gear>(["bodyweight", "none"]);
  for (const eq of profile.equipment) {
    if (eq === "full_gym") {
      ["barbell", "dumbbell", "kettlebell", "cable", "machine", "band", "pullup_bar", "bench"].forEach((g) =>
        set.add(g as Gear),
      );
    }
    if (eq === "home_gym") ["dumbbell", "barbell", "bench", "band", "pullup_bar"].forEach((g) => set.add(g as Gear));
    if (eq === "dumbbells") ["dumbbell", "bench"].forEach((g) => set.add(g as Gear));
    if (eq === "bands") set.add("band");
  }
  return [...set];
}

function equipmentFit(plan: WorkoutPlan, gear: Gear[]): number {
  const missing = plan.equipment.filter((g) => !gear.includes(g));
  return missing.length;
}

export interface PlanSuggestion {
  plan: WorkoutPlan;
  reason: string;
}

/**
 * Ranks the library plans against the user's real profile: experience, weekly
 * days, equipment and goal. Never recommends a plan that needs gear they said
 * they don't have.
 */
export function recommendPlans(profile: WellcareProfile, limit = 3): PlanSuggestion[] {
  const gear = availableGear(profile);
  const level = profile.experience ?? "beginner";
  const days = profile.daysPerWeek ?? 3;
  const goal = profile.goal;

  const scored = PLANS.map((plan) => {
    let score = 0;
    const reasons: string[] = [];

    if (plan.level === level) {
      score += 40;
      reasons.push(`matches your ${level} experience`);
    } else if (
      (level === "intermediate" && plan.level === "beginner") ||
      (level === "advanced" && plan.level === "intermediate")
    ) {
      score += 15;
    } else {
      score -= 25;
    }

    const dayGap = Math.abs(plan.daysPerWeek - days);
    score += Math.max(0, 30 - dayGap * 12);
    if (dayGap === 0) reasons.push(`fits ${days} days a week`);

    const missing = equipmentFit(plan, gear);
    score -= missing * 30;
    if (missing === 0) reasons.push("works with your equipment");

    if (goal === "lose_weight" && plan.id.includes("fatloss")) {
      score += 25;
      reasons.push("pairs lifting with conditioning for a deficit");
    }
    if ((goal === "gain_muscle" || goal === "build_strength") && plan.split.toLowerCase().includes("upper")) {
      score += 8;
    }
    if (goal === "improve_fitness" && plan.id.includes("athletic")) score += 15;

    return { plan, score, reason: reasons.slice(0, 2).join(" · ") || "a solid general option" };
  })
    .filter((s) => equipmentFit(s.plan, gear) === 0)
    .sort((a, b) => b.score - a.score);

  const fallback = PLANS.filter((p) => p.equipment.every((g) => ["bodyweight", "none"].includes(g)));
  const top = scored.slice(0, limit);
  if (top.length === 0 && fallback[0]) {
    return [{ plan: fallback[0], reason: "no equipment needed" }];
  }
  return top.map(({ plan, reason }) => ({ plan, reason }));
}
