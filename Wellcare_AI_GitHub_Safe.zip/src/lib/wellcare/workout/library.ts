import { UPPER_BODY } from "./data/upper";
import { LOWER_BODY } from "./data/lower";
import { CORE } from "./data/core";
import { FULL_BODY } from "./data/fullbody";
import { ACCESSORY } from "./data/accessory";
import type { Difficulty, Exercise, Gear, Muscle, Pattern } from "./types";

export const EXERCISES: Exercise[] = [
  ...UPPER_BODY,
  ...LOWER_BODY,
  ...CORE,
  ...FULL_BODY,
  ...ACCESSORY,
];

const BY_ID = new Map(EXERCISES.map((e) => [e.id, e]));

export function getExercise(id: string): Exercise | undefined {
  return BY_ID.get(id);
}

export interface LibraryFilters {
  query?: string;
  muscle?: Muscle | null;
  gear?: Gear | null;
  difficulty?: Difficulty | null;
  pattern?: Pattern | null;
  cameraOnly?: boolean;
}

export function filterExercises(filters: LibraryFilters): Exercise[] {
  const q = filters.query?.trim().toLowerCase() ?? "";
  return EXERCISES.filter((e) => {
    if (q && !e.name.toLowerCase().includes(q) && !e.description.toLowerCase().includes(q)) {
      return false;
    }
    if (filters.muscle && !e.primary.includes(filters.muscle) && !e.secondary.includes(filters.muscle)) {
      return false;
    }
    if (filters.gear && !e.equipment.includes(filters.gear)) return false;
    if (filters.difficulty && e.difficulty !== filters.difficulty) return false;
    if (filters.pattern && !e.patterns.includes(filters.pattern)) return false;
    if (filters.cameraOnly && !e.analyzer) return false;
    return true;
  });
}

export const CAMERA_EXERCISES = EXERCISES.filter((e) => e.analyzer);
