/** Workout library domain types. Mirrors public.exercises loosely but is local-first. */

export type Muscle =
  | "chest"
  | "back"
  | "shoulders"
  | "biceps"
  | "triceps"
  | "forearms"
  | "core"
  | "quadriceps"
  | "hamstrings"
  | "glutes"
  | "calves"
  | "full_body";

export const MUSCLE_LABEL: Record<Muscle, string> = {
  chest: "Chest",
  back: "Back",
  shoulders: "Shoulders",
  biceps: "Biceps",
  triceps: "Triceps",
  forearms: "Forearms",
  core: "Core",
  quadriceps: "Quadriceps",
  hamstrings: "Hamstrings",
  glutes: "Glutes",
  calves: "Calves",
  full_body: "Full body",
};

export type Gear =
  | "barbell"
  | "dumbbell"
  | "kettlebell"
  | "cable"
  | "machine"
  | "band"
  | "pullup_bar"
  | "bench"
  | "bodyweight"
  | "none";

export const GEAR_LABEL: Record<Gear, string> = {
  barbell: "Barbell",
  dumbbell: "Dumbbell",
  kettlebell: "Kettlebell",
  cable: "Cable",
  machine: "Machine",
  band: "Resistance band",
  pullup_bar: "Pull-up bar",
  bench: "Bench",
  bodyweight: "Bodyweight",
  none: "No equipment",
};

export type Difficulty = "beginner" | "intermediate" | "advanced";

export type Pattern =
  | "push"
  | "pull"
  | "squat"
  | "hinge"
  | "lunge"
  | "carry"
  | "core"
  | "isolation"
  | "compound"
  | "cardio";

export const PATTERN_LABEL: Record<Pattern, string> = {
  push: "Push",
  pull: "Pull",
  squat: "Squat",
  hinge: "Hinge",
  lunge: "Lunge",
  carry: "Carry",
  core: "Core",
  isolation: "Isolation",
  compound: "Compound",
  cardio: "Cardio",
};

/** Which local form analyzer (if any) can score this movement from the camera. */
export type AnalyzerId =
  | "squat"
  | "pushup"
  | "curl"
  | "lateral_raise"
  | "overhead_press"
  | "lunge"
  | "hinge"
  | "plank";

export interface Exercise {
  id: string;
  name: string;
  primary: Muscle[];
  secondary: Muscle[];
  equipment: Gear[];
  difficulty: Difficulty;
  patterns: Pattern[];
  description: string;
  steps: string[];
  cues: string[];
  mistakes: string[];
  sets: string;
  reps: string;
  restSec: number;
  tempo?: string;
  /** Camera form analysis. Undefined means "not supported yet" - never faked. */
  analyzer?: AnalyzerId;
  /** Automatic rep counting from the camera. */
  repCounting?: boolean;
}

export interface PlanExercise {
  exerciseId: string;
  sets: number;
  reps: string;
  restSec: number;
  note?: string;
}

export interface PlanDay {
  label: string;
  focus: string;
  exercises: PlanExercise[];
}

export interface WorkoutPlan {
  id: string;
  name: string;
  level: Difficulty;
  split: string;
  daysPerWeek: number;
  summary: string;
  equipment: Gear[];
  minutesPerSession: number;
  days: PlanDay[];
}

/* ---------- session + history ---------- */

export interface LoggedSet {
  exerciseId: string;
  exerciseName: string;
  setNumber: number;
  reps: number;
  weightKg: number | null;
  formScore: number | null;
  note?: string;
}

export interface WorkoutSessionRecord {
  id: string;
  /** YYYY-MM-DD */
  date: string;
  planId: string | null;
  title: string;
  startedAt: number;
  endedAt: number;
  durationSec: number;
  sets: LoggedSet[];
  totalReps: number;
  volumeKg: number;
  avgFormScore: number | null;
  completed: boolean;
}
