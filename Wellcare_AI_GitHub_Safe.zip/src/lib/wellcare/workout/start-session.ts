import { getExercise } from "./library";
import {
  startSession,
  trainingState,
  updateActive,
  type ActiveExercise,
  type ActiveSession,
} from "./training-store";

import type { Exercise, WorkoutPlan } from "./types";

function id() {
  return `s_${Date.now().toString(36)}_${Math.random().toString(36).slice(2, 7)}`;
}

function blankSets(count: number, reps: string): ActiveExercise["sets"] {
  const target = Number(reps.match(/(\d+)/)?.[1] ?? 10);
  return Array.from({ length: count }, () => ({
    done: false,
    reps: Number.isFinite(target) ? target : 10,
    weightKg: null,
    formScore: null,
  }));
}

export function startPlanDay(plan: WorkoutPlan, dayIndex: number): ActiveSession {
  const day = plan.days[dayIndex % plan.days.length]!;
  const session: ActiveSession = {
    id: id(),
    planId: plan.id,
    dayIndex,
    title: `${plan.name} · ${day.label}`,
    startedAt: Date.now(),
    cursor: { exercise: 0, set: 0 },
    exercises: day.exercises.map((pe) => {
      const ex = getExercise(pe.exerciseId);
      return {
        exerciseId: pe.exerciseId,
        name: ex?.name ?? pe.exerciseId,
        targetReps: pe.reps,
        restSec: pe.restSec,
        sets: blankSets(pe.sets, pe.reps),
      };
    }),
  };
  startSession(session);
  return session;
}

/** Quick single-exercise session, used when starting straight from the library. */
export function startSingleExercise(exercise: Exercise): ActiveSession {
  const sets = Number(exercise.sets.match(/(\d+)/)?.[1] ?? 3);
  const session: ActiveSession = {
    id: id(),
    planId: null,
    dayIndex: 0,
    title: exercise.name,
    startedAt: Date.now(),
    cursor: { exercise: 0, set: 0 },
    exercises: [
      {
        exerciseId: exercise.id,
        name: exercise.name,
        targetReps: exercise.reps,
        restSec: exercise.restSec,
        sets: blankSets(Number.isFinite(sets) ? sets : 3, exercise.reps),
      },
    ],
  };
  startSession(session);
  return session;
}

/**
 * Append an exercise to the session in progress. Falls back to starting a
 * fresh single-exercise session when nothing is running.
 */
export function addExerciseToSession(exercise: Exercise): "added" | "started" {
  const state = trainingState();
  if (!state.active) {
    startSingleExercise(exercise);
    return "started";
  }
  const sets = Number(exercise.sets.match(/(\d+)/)?.[1] ?? 3);
  updateActive((a) => ({
    ...a,
    exercises: [
      ...a.exercises,
      {
        exerciseId: exercise.id,
        name: exercise.name,
        targetReps: exercise.reps,
        restSec: exercise.restSec,
        sets: blankSets(Number.isFinite(sets) ? sets : 3, exercise.reps),
      },
    ],
  }));
  return "added";
}
