import { useCallback, useSyncExternalStore } from "react";
import type { LoggedSet, WorkoutSessionRecord } from "./types";

const KEY = "wellcare:training:v1";

export interface ActiveSet {
  done: boolean;
  reps: number;
  weightKg: number | null;
  formScore: number | null;
  note?: string;
}

export interface ActiveExercise {
  exerciseId: string;
  name: string;
  targetReps: string;
  restSec: number;
  sets: ActiveSet[];
}

export interface ActiveSession {
  id: string;
  planId: string | null;
  dayIndex: number;
  title: string;
  startedAt: number;
  exercises: ActiveExercise[];
  cursor: { exercise: number; set: number };
}

export interface TrainingState {
  activePlanId: string | null;
  /** Which day of the plan comes next. */
  planCursor: Record<string, number>;
  favorites: string[];
  history: WorkoutSessionRecord[];
  active: ActiveSession | null;
}

const empty: TrainingState = {
  activePlanId: null,
  planCursor: {},
  favorites: [],
  history: [],
  active: null,
};

let state: TrainingState = empty;
let loaded = false;
const listeners = new Set<() => void>();

function load(): TrainingState {
  if (typeof window === "undefined") return empty;
  try {
    const raw = window.localStorage.getItem(KEY);
    if (!raw) return empty;
    return { ...empty, ...(JSON.parse(raw) as Partial<TrainingState>) };
  } catch {
    return empty;
  }
}

function ensureLoaded() {
  if (!loaded && typeof window !== "undefined") {
    state = load();
    loaded = true;
  }
}

function emit() {
  if (typeof window !== "undefined") {
    try {
      window.localStorage.setItem(KEY, JSON.stringify(state));
    } catch {
      /* storage blocked - training still works for this session */
    }
  }
  listeners.forEach((l) => l());
}

export function setTraining(patch: Partial<TrainingState> | ((s: TrainingState) => Partial<TrainingState>)) {
  ensureLoaded();
  const next = typeof patch === "function" ? patch(state) : patch;
  state = { ...state, ...next };
  emit();
}

/** Current training state outside React. */
export function trainingState(): TrainingState {
  ensureLoaded();
  return state;
}

function subscribe(listener: () => void) {

  ensureLoaded();
  listeners.add(listener);
  return () => listeners.delete(listener);
}

export function useTraining(): TrainingState {
  return useSyncExternalStore(
    subscribe,
    () => {
      ensureLoaded();
      return state;
    },
    () => empty,
  );
}

export function useToggleFavorite() {
  return useCallback((exerciseId: string) => {
    setTraining((s) => ({
      favorites: s.favorites.includes(exerciseId)
        ? s.favorites.filter((f) => f !== exerciseId)
        : [...s.favorites, exerciseId],
    }));
  }, []);
}

/* --------------------------- session lifecycle --------------------------- */

export function startSession(session: ActiveSession) {
  setTraining({ active: session });
}

export function updateActive(fn: (a: ActiveSession) => ActiveSession) {
  setTraining((s) => (s.active ? { active: fn(s.active) } : {}));
}

export function cancelSession() {
  setTraining({ active: null });
}

function dayKey(d = new Date()) {
  return `${d.getFullYear()}-${String(d.getMonth() + 1).padStart(2, "0")}-${String(d.getDate()).padStart(2, "0")}`;
}

export function finishSession(): WorkoutSessionRecord | null {
  ensureLoaded();
  const a = state.active;
  if (!a) return null;

  const sets: LoggedSet[] = [];
  a.exercises.forEach((ex) => {
    ex.sets.forEach((s, i) => {
      if (!s.done) return;
      sets.push({
        exerciseId: ex.exerciseId,
        exerciseName: ex.name,
        setNumber: i + 1,
        reps: s.reps,
        weightKg: s.weightKg,
        formScore: s.formScore,
        ...(s.note ? { note: s.note } : {}),
      });
    });
  });

  const scores = sets.map((s) => s.formScore).filter((n): n is number => typeof n === "number");
  const endedAt = Date.now();
  const record: WorkoutSessionRecord = {
    id: a.id,
    date: dayKey(),
    planId: a.planId,
    title: a.title,
    startedAt: a.startedAt,
    endedAt,
    durationSec: Math.round((endedAt - a.startedAt) / 1000),
    sets,
    totalReps: sets.reduce((n, s) => n + s.reps, 0),
    volumeKg: Math.round(sets.reduce((n, s) => n + s.reps * (s.weightKg ?? 0), 0)),
    avgFormScore: scores.length ? Math.round(scores.reduce((n, s) => n + s, 0) / scores.length) : null,
    completed: sets.length > 0,
  };

  const planCursor = { ...state.planCursor };
  if (a.planId) planCursor[a.planId] = a.dayIndex + 1;

  setTraining({ active: null, history: [record, ...state.history].slice(0, 200), planCursor });
  return record;
}

/* ------------------------------ statistics ------------------------------ */

export interface Consistency {
  /** Sessions completed in the trailing 28 days. */
  completed: number;
  planned: number;
  percent: number;
  streak: number;
}

export function consistency(history: WorkoutSessionRecord[], daysPerWeek: number | null): Consistency {
  const now = Date.now();
  const windowMs = 28 * 24 * 3600 * 1000;
  const recent = history.filter((h) => now - h.endedAt <= windowMs && h.completed);
  const planned = Math.max(1, Math.round((daysPerWeek ?? 3) * 4));
  const completed = recent.length;

  // Streak = consecutive completed sessions, broken by a gap of more than 4 days.
  let streak = 0;
  let cursor = now;
  for (const h of history.filter((x) => x.completed)) {
    if (cursor - h.endedAt <= 4 * 24 * 3600 * 1000) {
      streak += 1;
      cursor = h.endedAt;
    } else break;
  }

  return {
    completed,
    planned,
    percent: Math.min(100, Math.round((completed / planned) * 100)),
    streak,
  };
}

/** Best previous set (by estimated load) for an exercise. */
export function personalBest(history: WorkoutSessionRecord[], exerciseId: string) {
  let best: { weightKg: number; reps: number } | null = null;
  for (const s of history.flatMap((h) => h.sets)) {
    if (s.exerciseId !== exerciseId || s.weightKg == null) continue;
    if (!best || s.weightKg > best.weightKg || (s.weightKg === best.weightKg && s.reps > best.reps)) {
      best = { weightKg: s.weightKg, reps: s.reps };
    }
  }
  return best;
}

/**
 * Progressive-overload hint. Suggests (never applies) a load increase when the
 * last two sessions both hit the top of the prescribed rep range.
 */
export function overloadHint(
  history: WorkoutSessionRecord[],
  exerciseId: string,
  targetReps: string,
): string | null {
  const top = Number(targetReps.match(/(\d+)\s*$/)?.[1] ?? targetReps.match(/(\d+)/)?.[1]);
  if (!Number.isFinite(top)) return null;
  const recent = history
    .filter((h) => h.sets.some((s) => s.exerciseId === exerciseId))
    .slice(0, 2)
    .flatMap((h) => h.sets.filter((s) => s.exerciseId === exerciseId));
  if (recent.length < 3) return null;
  const allTop = recent.every((s) => s.reps >= top && (s.weightKg ?? 0) > 0);
  if (!allTop) return null;
  return `You're consistently hitting ${top} reps here. Consider a small weight increase next session.`;
}
