/**
 * Demo account provisioning + seeding.
 *
 * Server-only: uses the service-role client to create the demo auth user and
 * write 30 days of realistic sample data into the very same tables real users
 * use, so the Assistant tools operate on it unchanged.
 */
import { DEMO_EMAIL } from "./constants";

type Admin = Awaited<
  typeof import("@/integrations/supabase/client.server")
>["supabaseAdmin"];

async function admin(): Promise<Admin> {
  const { supabaseAdmin } = await import("@/integrations/supabase/client.server");
  return supabaseAdmin;
}

/**
 * The seeder writes many heterogeneous tables from generic row objects; the
 * generated per-table Row types add no safety here, so go through a small
 * loosely typed view of the admin client instead of casting at every call.
 */
interface LooseTable {
  insert: (rows: unknown) => PromiseLike<{ error: { message: string } | null }> & {
    select: (columns: string) => PromiseLike<{
      data: Array<{ id: string }> | null;
      error: { message: string } | null;
    }>;
  };
  upsert: (
    rows: unknown,
    options?: { onConflict?: string },
  ) => PromiseLike<{ error: { message: string } | null }>;
  delete: () => {
    eq: (column: string, value: string) => PromiseLike<{ error: { message: string } | null }>;
  };
  select: (
    columns: string,
    options?: { count?: "exact"; head?: boolean },
  ) => {
    eq: (
      column: string,
      value: string,
    ) => PromiseLike<{ count: number | null; error: { message: string } | null }>;
  };
}

function table(db: Admin, name: string): LooseTable {
  return (db.from as unknown as (n: string) => LooseTable)(name);
}

export function demoPassword(): string {
  const pw = process.env["DEMO_ACCOUNT_PASSWORD"];
  if (!pw) throw new Error("Demo account is not configured on the server.");
  return pw;
}

/** Creates the demo auth user if missing and returns its id. */
export async function ensureDemoUser(): Promise<string> {
  const db = await admin();
  const password = demoPassword();

  const existing = await db.auth.admin.listUsers({ page: 1, perPage: 200 });
  if (existing.error) throw new Error(existing.error.message);
  const found = existing.data.users.find(
    (u) => u.email?.toLowerCase() === DEMO_EMAIL,
  );
  if (found) {
    // Keep the password in sync with the current server secret.
    await db.auth.admin.updateUserById(found.id, { password });
    return found.id;
  }

  const created = await db.auth.admin.createUser({
    email: DEMO_EMAIL,
    password,
    email_confirm: true,
    user_metadata: { display_name: "Demo", full_name: "Demo Account", demo: true },
  });
  if (created.error || !created.data.user) {
    throw new Error(created.error?.message ?? "Could not create the demo account.");
  }
  return created.data.user.id;
}

/* ------------------------------------------------------------------ */
/* helpers                                                             */
/* ------------------------------------------------------------------ */

/** Deterministic PRNG so the demo data looks the same on every reset. */
function rng(seed: number) {
  let s = seed >>> 0;
  return () => {
    s = (s * 1664525 + 1013904223) >>> 0;
    return s / 0xffffffff;
  };
}

function dayKey(offset: number) {
  const d = new Date();
  d.setUTCHours(12, 0, 0, 0);
  d.setUTCDate(d.getUTCDate() - offset);
  return d.toISOString().slice(0, 10);
}

function atTime(dateKey: string, hour: number, minute = 0) {
  return new Date(`${dateKey}T${String(hour).padStart(2, "0")}:${String(minute).padStart(2, "0")}:00Z`).toISOString();
}

const BREAKFAST = [
  { name: "Greek yogurt with berries & honey", calories: 320, protein_g: 24, carbs_g: 38, fat_g: 7 },
  { name: "Oats with banana and peanut butter", calories: 430, protein_g: 15, carbs_g: 58, fat_g: 15 },
  { name: "Three-egg omelette with spinach", calories: 350, protein_g: 26, carbs_g: 6, fat_g: 24 },
  { name: "Protein shake and a bagel", calories: 470, protein_g: 34, carbs_g: 62, fat_g: 8 },
];
const LUNCH = [
  { name: "Grilled chicken rice bowl", calories: 620, protein_g: 48, carbs_g: 68, fat_g: 16 },
  { name: "Tuna sandwich and side salad", calories: 540, protein_g: 38, carbs_g: 52, fat_g: 18 },
  { name: "Beef burrito bowl", calories: 700, protein_g: 44, carbs_g: 72, fat_g: 24 },
  { name: "Lentil soup with sourdough", calories: 480, protein_g: 22, carbs_g: 66, fat_g: 12 },
];
const DINNER = [
  { name: "Salmon, potatoes and broccoli", calories: 660, protein_g: 45, carbs_g: 52, fat_g: 28 },
  { name: "Chicken pasta with tomato sauce", calories: 720, protein_g: 46, carbs_g: 86, fat_g: 18 },
  { name: "Steak with sweet potato mash", calories: 750, protein_g: 52, carbs_g: 54, fat_g: 32 },
  { name: "Tofu stir fry with jasmine rice", calories: 590, protein_g: 28, carbs_g: 78, fat_g: 17 },
];
const SNACK = [
  { name: "Apple and almonds", calories: 210, protein_g: 5, carbs_g: 24, fat_g: 11 },
  { name: "Protein bar", calories: 230, protein_g: 20, carbs_g: 22, fat_g: 7 },
  { name: "Cottage cheese with pineapple", calories: 180, protein_g: 19, carbs_g: 16, fat_g: 3 },
  { name: "Dark chocolate squares", calories: 160, protein_g: 2, carbs_g: 15, fat_g: 10 },
];

const SPLIT: { label: string; exercises: { name: string; sets: number; reps: string; weight: number }[] }[] = [
  {
    label: "Upper push",
    exercises: [
      { name: "Barbell bench press", sets: 4, reps: "6-8", weight: 70 },
      { name: "Overhead press", sets: 3, reps: "8-10", weight: 40 },
      { name: "Incline dumbbell press", sets: 3, reps: "10", weight: 24 },
      { name: "Cable triceps pushdown", sets: 3, reps: "12", weight: 30 },
    ],
  },
  {
    label: "Lower body",
    exercises: [
      { name: "Back squat", sets: 4, reps: "5-6", weight: 95 },
      { name: "Romanian deadlift", sets: 3, reps: "8", weight: 80 },
      { name: "Walking lunge", sets: 3, reps: "12", weight: 20 },
      { name: "Standing calf raise", sets: 3, reps: "15", weight: 45 },
    ],
  },
  {
    label: "Upper pull",
    exercises: [
      { name: "Deadlift", sets: 3, reps: "5", weight: 120 },
      { name: "Pull-up", sets: 4, reps: "6-8", weight: 0 },
      { name: "Barbell row", sets: 3, reps: "8-10", weight: 60 },
      { name: "Face pull", sets: 3, reps: "15", weight: 25 },
    ],
  },
  {
    label: "Full body & conditioning",
    exercises: [
      { name: "Front squat", sets: 3, reps: "8", weight: 60 },
      { name: "Dumbbell bench press", sets: 3, reps: "10", weight: 28 },
      { name: "Seated cable row", sets: 3, reps: "12", weight: 55 },
      { name: "Plank", sets: 3, reps: "60s", weight: 0 },
    ],
  },
];

const DEMO_TABLES = [
  "meal_items",
  "meals",
  "water_logs",
  "step_entries",
  "sleep_entries",
  "heart_rate_entries",
  "respiratory_rate_entries",
  "blood_glucose_entries",
  "progress_entries",
  "workout_set_logs",
  "workout_sessions",
  "program_exercises",
  "workout_programs",
  "medicine_logs",
  "medicines",
  "reminders",
  "user_goals",
  "tracker_goals",
  "tracker_prefs",
  "assistant_actions",
  "ai_interactions",
] as const;

/** Removes every row owned by the demo user (children first). */
export async function clearDemoData(userId: string): Promise<void> {
  const db = await admin();
  for (const name of DEMO_TABLES) {
    const { error } = await table(db, name).delete().eq("user_id", userId);
    if (error) throw new Error(`${name}: ${error.message}`);
  }
}

/** True when the demo account already has data (so login doesn't reseed). */
export async function demoHasData(userId: string): Promise<boolean> {
  const db = await admin();
  const { count, error } = await table(db, "meals")
    .select("id", { count: "exact", head: true })
    .eq("user_id", userId);
  if (error) throw new Error(error.message);
  return (count ?? 0) > 0;
}

/** Wipes and rewrites 30 days of realistic demo activity. */
export async function seedDemoData(userId: string): Promise<void> {
  const db = await admin();
  await clearDemoData(userId);
  const rand = rng(20260901);

  /* profile ------------------------------------------------------- */
  const profileRow = {
    id: userId,
    first_name: "Demo",
    display_name: "Demo",
    sex: "male",
    birth_date: "1994-04-12",
    height_cm: 178,
    weight_kg: 79.4,
    body_fat_pct: 17.5,
    weight_unit: "kg",
    height_unit: "cm",
    goal: "recomp",
    secondary_goals: ["improve_fitness"],
    activity_level: "moderate",
    training_experience: "intermediate",
    training_days_per_week: 4,
    equipment: ["full_gym"],
    diet_type: "omnivore",
    allergies: [],
    avoided_foods: [],
    tdee_estimate: 2680,
    tdee_method: "mifflin_st_jeor",
    daily_calorie_target: 2450,
    daily_protein_target_g: 165,
    daily_carbs_target_g: 260,
    daily_fat_target_g: 78,
    daily_water_target_ml: 3000,
    onboarding_completed: true,
    health_connected: false,
    health_metrics: [],
  };
  {
    const { error } = await table(db, "profiles").upsert(profileRow, { onConflict: "id" });
    if (error) throw new Error(`profiles: ${error.message}`);
  }

  /* workout program ----------------------------------------------- */
  const program = await table(db, "workout_programs")
    .insert({
      user_id: userId,
      name: "4-Day Recomp Split",
      description: "Push, lower, pull and a full-body conditioning day.",
      goal: "recomp",
      days_per_week: 4,
      weeks: 8,
      is_active: true,
      generated_by_ai: true,
    })
    .select("id");
  if (program.error || !program.data?.[0]) {
    throw new Error(`workout_programs: ${program.error?.message ?? "insert failed"}`);
  }
  const programId = program.data[0].id;

  const programExercises = SPLIT.flatMap((day, dayIndex) =>
    day.exercises.map((ex, position) => ({
      program_id: programId,
      user_id: userId,
      day_index: dayIndex,
      day_label: day.label,
      position,
      target_sets: ex.sets,
      target_reps: ex.reps,
      rest_seconds: 90,
      notes: null as string | null,
    })),
  );
  {
    const { error } = await table(db, "program_exercises").insert(programExercises);
    if (error) throw new Error(`program_exercises: ${error.message}`);
  }

  /* daily logs ----------------------------------------------------- */
  const meals: Record<string, unknown>[] = [];
  const water: Record<string, unknown>[] = [];
  const steps: Record<string, unknown>[] = [];
  const sleep: Record<string, unknown>[] = [];
  const heart: Record<string, unknown>[] = [];
  const progress: Record<string, unknown>[] = [];
  const sessions: Record<string, unknown>[] = [];

  const mealPlan: { key: string; type: string; hour: number; item: (typeof BREAKFAST)[number] }[] = [];

  for (let offset = 29; offset >= 0; offset--) {
    const key = dayKey(offset);
    const pick = <T,>(arr: T[]) => arr[Math.floor(rand() * arr.length)]!;

    mealPlan.push({ key, type: "breakfast", hour: 8, item: pick(BREAKFAST) });
    mealPlan.push({ key, type: "lunch", hour: 13, item: pick(LUNCH) });
    mealPlan.push({ key, type: "dinner", hour: 20, item: pick(DINNER) });
    if (rand() > 0.35) mealPlan.push({ key, type: "snack", hour: 16, item: pick(SNACK) });

    water.push({ user_id: userId, logged_on: key, amount_ml: 500 });
    water.push({ user_id: userId, logged_on: key, amount_ml: 750 });
    water.push({ user_id: userId, logged_on: key, amount_ml: Math.round(600 + rand() * 900) });

    steps.push({
      user_id: userId,
      logged_on: key,
      steps: Math.round(5200 + rand() * 7200),
      source: "device",
    });

    const minutes = Math.round(360 + rand() * 120);
    sleep.push({
      user_id: userId,
      logged_on: key,
      minutes,
      quality: 2 + Math.round(rand() * 2),
      bedtime: atTime(key, 23),
      wake_time: atTime(key, 7),
      source: "device",
    });

    heart.push({
      user_id: userId,
      bpm: Math.round(54 + rand() * 8),
      is_resting: true,
      context: "morning",
      measured_at: atTime(key, 7, 15),
      source: "device",
    });

    // Weight trends slowly down with day-to-day noise.
    if (offset % 2 === 0) {
      progress.push({
        user_id: userId,
        recorded_on: key,
        weight_kg: Number((81.2 - (29 - offset) * 0.06 + (rand() - 0.5) * 0.5).toFixed(1)),
        body_fat_pct: Number((19 - (29 - offset) * 0.05).toFixed(1)),
        waist_cm: Number((86 - (29 - offset) * 0.05).toFixed(1)),
      });
    }

    // Train Mon/Tue/Thu/Sat-ish: 4 sessions a week.
    const weekday = new Date(`${key}T12:00:00Z`).getUTCDay();
    const trainingDay = [1, 2, 4, 6].indexOf(weekday);
    if (trainingDay >= 0) {
      const day = SPLIT[trainingDay]!;
      sessions.push({
        user_id: userId,
        program_id: programId,
        title: day.label,
        performed_on: key,
        started_at: atTime(key, 18),
        completed_at: atTime(key, 19, 5),
        duration_seconds: Math.round(3000 + rand() * 1500),
        calories_burned: Math.round(320 + rand() * 180),
        perceived_effort: 6 + Math.round(rand() * 3),
        notes: null,
        __day: trainingDay,
      });
    }
  }

  const insertChunks = async (name: string, rows: Record<string, unknown>[]) => {
    for (let i = 0; i < rows.length; i += 400) {
      const { error } = await table(db, name).insert(rows.slice(i, i + 400));
      if (error) throw new Error(`${name}: ${error.message}`);
    }
  };

  /* meals + items --------------------------------------------------- */
  const mealRows = mealPlan.map((m) => ({
    user_id: userId,
    logged_on: m.key,
    meal_type: m.type,
    title: m.item.name,
  }));
  const insertedMeals = await table(db, "meals").insert(mealRows).select("id");
  if (insertedMeals.error || !insertedMeals.data) {
    throw new Error(`meals: ${insertedMeals.error?.message ?? "insert failed"}`);
  }
  const mealItems = insertedMeals.data.map((row, index) => {
    const plan = mealPlan[index]!;
    return {
      meal_id: row.id,
      user_id: userId,
      name: plan.item.name,
      quantity: 1,
      unit: "serving",
      calories: plan.item.calories,
      protein_g: plan.item.protein_g,
      carbs_g: plan.item.carbs_g,
      fat_g: plan.item.fat_g,
      created_at: atTime(plan.key, plan.hour),
    };
  });
  await insertChunks("meal_items", mealItems);

  await insertChunks("water_logs", water);
  await insertChunks("step_entries", steps);
  await insertChunks("sleep_entries", sleep);
  await insertChunks("heart_rate_entries", heart);
  await insertChunks("progress_entries", progress);

  /* sessions + set logs --------------------------------------------- */
  const sessionRows = sessions.map(({ __day: _drop, ...rest }) => rest);
  const insertedSessions = await table(db, "workout_sessions").insert(sessionRows).select("id");
  if (insertedSessions.error || !insertedSessions.data) {
    throw new Error(`workout_sessions: ${insertedSessions.error?.message ?? "insert failed"}`);
  }

  const setLogs: Record<string, unknown>[] = [];
  insertedSessions.data.forEach((row, index) => {
    const dayIndex = sessions[index]!["__day"] as number;
    const day = SPLIT[dayIndex]!;
    day.exercises.forEach((ex) => {
      for (let setNumber = 1; setNumber <= ex.sets; setNumber++) {
        setLogs.push({
          session_id: row.id,
          user_id: userId,
          exercise_name: ex.name,
          set_number: setNumber,
          reps: ex.reps.endsWith("s") ? null : 6 + Math.round(rand() * 6),
          weight_kg: ex.weight || null,
          duration_seconds: ex.reps.endsWith("s") ? 60 : null,
          is_warmup: setNumber === 1,
        });
      }
    });
  });
  await insertChunks("workout_set_logs", setLogs);

  /* trackers, goals, reminders -------------------------------------- */
  const trackerKeys = ["water", "steps", "weight", "sleep", "heart_rate"];
  await insertChunks(
    "tracker_prefs",
    trackerKeys.map((tracker_key, position) => ({
      user_id: userId,
      tracker_key,
      enabled: true,
      pinned_home: position < 3,
      position,
    })),
  );
  await insertChunks("tracker_goals", [
    { user_id: userId, tracker_key: "water", target: 3000, unit: "ml", period: "day" },
    { user_id: userId, tracker_key: "steps", target: 10000, unit: "steps", period: "day" },
    { user_id: userId, tracker_key: "sleep", target: 480, unit: "min", period: "day" },
    { user_id: userId, tracker_key: "weight", target: 77, unit: "kg", period: "month" },
  ]);
  await insertChunks("user_goals", [
    {
      user_id: userId,
      title: "Get to 77 kg without losing strength",
      metric: "weight",
      target_value: 77,
      current_value: 79.4,
      unit: "kg",
      status: "active",
    },
    {
      user_id: userId,
      title: "Bench press 80 kg for 5",
      metric: "strength",
      target_value: 80,
      current_value: 70,
      unit: "kg",
      status: "active",
    },
  ]);
  await insertChunks("reminders", [
    {
      user_id: userId,
      title: "Log breakfast",
      category: "nutrition",
      time_of_day: "08:30",
      days_of_week: [1, 2, 3, 4, 5],
      enabled: true,
    },
    {
      user_id: userId,
      title: "Evening training",
      category: "workout",
      time_of_day: "18:00",
      days_of_week: [1, 2, 4, 6],
      enabled: true,
    },
  ]);
}
