/** Public, non-sensitive identifier for the shared demo/testing account. */
export const DEMO_EMAIL = "demo@wellcare.ai";
