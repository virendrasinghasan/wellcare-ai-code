import { createServerFn } from "@tanstack/react-start";
import { requireSupabaseAuth } from "@/integrations/supabase/auth-middleware";
import { DEMO_EMAIL } from "./constants";

export interface DemoSession {
  access_token: string;
  refresh_token: string;
}

/**
 * Signs the tester into the shared demo account.
 *
 * The password lives only in a server secret: the browser never sees it, only
 * the resulting Supabase session. Data is seeded on first use into the real
 * tables, scoped to the demo user by the same RLS policies as everyone else.
 */
export const demoLogin = createServerFn({ method: "POST" }).handler(
  async (): Promise<DemoSession> => {
    const { ensureDemoUser, seedDemoData, demoHasData, demoPassword } = await import(
      "./seed.server"
    );
    const { createClient } = await import("@supabase/supabase-js");

    const userId = await ensureDemoUser();
    if (!(await demoHasData(userId))) await seedDemoData(userId);

    const url = process.env["SUPABASE_URL"];
    const key = process.env["SUPABASE_PUBLISHABLE_KEY"];
    if (!url || !key) throw new Error("Supabase is not configured on the server.");

    const client = createClient(url, key, {
      auth: { storage: undefined, persistSession: false, autoRefreshToken: false },
    });
    const { data, error } = await client.auth.signInWithPassword({
      email: DEMO_EMAIL,
      password: demoPassword(),
    });
    if (error || !data.session) {
      throw new Error(error?.message ?? "Could not start the demo session.");
    }
    return {
      access_token: data.session.access_token,
      refresh_token: data.session.refresh_token,
    };
  },
);

/** Wipes and rebuilds the demo account's 30 days of sample data. */
export const resetDemoData = createServerFn({ method: "POST" })
  .middleware([requireSupabaseAuth])
  .handler(async ({ context }): Promise<{ ok: true }> => {
    const email = String(context.claims["email"] ?? "").toLowerCase();
    if (email !== DEMO_EMAIL) {
      throw new Error("Only the demo account can be reset.");
    }
    const { seedDemoData } = await import("./seed.server");
    await seedDemoData(context.userId);
    return { ok: true };
  });
