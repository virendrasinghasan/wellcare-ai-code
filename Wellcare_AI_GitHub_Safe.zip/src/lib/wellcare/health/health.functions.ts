import { createServerFn } from "@tanstack/react-start";
import { z } from "zod";
import { requireSupabaseAuth } from "@/integrations/supabase/auth-middleware";
import type { HealthMetricKey, HealthProviderId } from "./integrations";

export interface HealthConnectionRow {
  provider: HealthProviderId;
  status: "connected" | "disconnected" | "error";
  grantedMetrics: HealthMetricKey[];
  lastSyncedAt: string | null;
  lastError: string | null;
  externalAccountId: string | null;
}

export interface SyncOutcome {
  imported: number;
  skipped: number;
  lastSyncedAt: string;
  unavailable: HealthMetricKey[];
}

const PROVIDERS = ["google_health", "apple_health", "fitbit", "garmin", "samsung_health"] as const;
const METRICS = ["steps", "distance", "activity", "heart_rate", "weight", "sleep", "workout"] as const;

const SampleSchema = z.object({
  metric: z.enum(METRICS),
  at: z.string().min(4),
  value: z.number().finite(),
  externalId: z.string().max(200).optional(),
});

/** Every connection the signed-in user has ever set up. */
export const listHealthConnections = createServerFn({ method: "POST" })
  .middleware([requireSupabaseAuth])
  .handler(async ({ context }): Promise<HealthConnectionRow[]> => {
    // eslint-disable-next-line @typescript-eslint/no-explicit-any
    const sb = context.supabase as any;
    const { data, error } = await sb
      .from("health_connections")
      .select("provider, status, granted_metrics, last_synced_at, last_error, external_account_id")
      .eq("user_id", context.userId);
    if (error) throw new Error(error.message);
    // eslint-disable-next-line @typescript-eslint/no-explicit-any
    return (data ?? []).map((row: any) => ({
      provider: row.provider,
      status: row.status,
      grantedMetrics: (row.granted_metrics ?? []) as HealthMetricKey[],
      lastSyncedAt: row.last_synced_at ?? null,
      lastError: row.last_error ?? null,
      externalAccountId: row.external_account_id ?? null,
    }));
  });

/**
 * Recorded only after a real native bridge returned real grants. The client
 * cannot mark a provider connected with an empty permission set.
 */
export const saveHealthConnection = createServerFn({ method: "POST" })
  .middleware([requireSupabaseAuth])
  .inputValidator((input: unknown) =>
    z
      .object({
        provider: z.enum(PROVIDERS),
        grantedMetrics: z.array(z.enum(METRICS)).min(1),
        externalAccountId: z.string().max(200).nullable().default(null),
      })
      .parse(input),
  )
  .handler(async ({ data, context }): Promise<HealthConnectionRow> => {
    // eslint-disable-next-line @typescript-eslint/no-explicit-any
    const sb = context.supabase as any;
    const { error } = await sb.from("health_connections").upsert(
      {
        user_id: context.userId,
        provider: data.provider,
        status: "connected",
        granted_metrics: data.grantedMetrics,
        external_account_id: data.externalAccountId,
        last_error: null,
        updated_at: new Date().toISOString(),
      },
      { onConflict: "user_id,provider" },
    );
    if (error) throw new Error(error.message);
    return {
      provider: data.provider,
      status: "connected",
      grantedMetrics: data.grantedMetrics,
      lastSyncedAt: null,
      lastError: null,
      externalAccountId: data.externalAccountId,
    };
  });

/** Keeps imported records; only stops future imports. */
export const disconnectHealthProvider = createServerFn({ method: "POST" })
  .middleware([requireSupabaseAuth])
  .inputValidator((input: unknown) => z.object({ provider: z.enum(PROVIDERS) }).parse(input))
  .handler(async ({ data, context }) => {
    // eslint-disable-next-line @typescript-eslint/no-explicit-any
    const sb = context.supabase as any;
    const { error } = await sb
      .from("health_connections")
      .update({ status: "disconnected", granted_metrics: [], updated_at: new Date().toISOString() })
      .eq("user_id", context.userId)
      .eq("provider", data.provider);
    if (error) throw new Error(error.message);
    return { ok: true };
  });

/** Marks a failed sync without dropping the connection. */
export const recordSyncFailure = createServerFn({ method: "POST" })
  .middleware([requireSupabaseAuth])
  .inputValidator((input: unknown) =>
    z.object({ provider: z.enum(PROVIDERS), message: z.string().max(300) }).parse(input),
  )
  .handler(async ({ data, context }) => {
    // eslint-disable-next-line @typescript-eslint/no-explicit-any
    const sb = context.supabase as any;
    await sb
      .from("health_connections")
      .update({ status: "error", last_error: data.message, updated_at: new Date().toISOString() })
      .eq("user_id", context.userId)
      .eq("provider", data.provider);
    return { ok: true };
  });

/**
 * Ingests samples the native bridge actually read. Daily metrics upsert one row
 * per day and never overwrite a newer manual entry; instants dedupe on their
 * timestamp, so re-syncing the same window imports nothing twice.
 */
export const ingestHealthSamples = createServerFn({ method: "POST" })
  .middleware([requireSupabaseAuth])
  .inputValidator((input: unknown) =>
    z
      .object({
        provider: z.enum(PROVIDERS),
        samples: z.array(SampleSchema).max(2000),
        unavailable: z.array(z.enum(METRICS)).default([]),
      })
      .parse(input),
  )
  .handler(async ({ data, context }): Promise<SyncOutcome> => {
    // eslint-disable-next-line @typescript-eslint/no-explicit-any
    const sb = context.supabase as any;
    const userId = context.userId;
    let imported = 0;
    let skipped = 0;

    const day = (iso: string) => new Date(iso).toISOString().slice(0, 10);

    for (const sample of data.samples) {
      try {
        if (sample.metric === "steps" || sample.metric === "sleep") {
          const table = sample.metric === "steps" ? "step_entries" : "sleep_entries";
          const column = sample.metric === "steps" ? "steps" : "minutes";
          const loggedOn = day(sample.at);
          const { data: existing } = await sb
            .from(table)
            .select(`id, source, ${column}`)
            .eq("user_id", userId)
            .eq("logged_on", loggedOn)
            .maybeSingle();
          // A manual entry for that day wins - synced data never overwrites it.
          if (existing && existing.source === "manual") {
            skipped += 1;
            continue;
          }
          const { error } = await sb.from(table).upsert(
            {
              user_id: userId,
              logged_on: loggedOn,
              [column]: Math.round(sample.value),
              source: "device",
              updated_at: new Date().toISOString(),
            },
            { onConflict: "user_id,logged_on" },
          );
          if (error) throw new Error(error.message);
          imported += 1;
        } else if (sample.metric === "heart_rate") {
          const { error } = await sb.from("heart_rate_entries").upsert(
            {
              user_id: userId,
              measured_at: new Date(sample.at).toISOString(),
              bpm: Math.round(sample.value),
              source: "device",
            },
            { onConflict: "user_id,measured_at", ignoreDuplicates: true },
          );
          if (error) throw new Error(error.message);
          imported += 1;
        } else if (sample.metric === "weight") {
          const recordedOn = day(sample.at);
          const { data: existing } = await sb
            .from("progress_entries")
            .select("id, weight_kg")
            .eq("user_id", userId)
            .eq("recorded_on", recordedOn)
            .maybeSingle();
          if (existing) {
            skipped += 1;
            continue;
          }
          const { error } = await sb
            .from("progress_entries")
            .insert({ user_id: userId, recorded_on: recordedOn, weight_kg: sample.value });
          if (error) throw new Error(error.message);
          imported += 1;
        } else {
          // distance / activity / workout have no dedicated store yet.
          skipped += 1;
        }
      } catch {
        skipped += 1;
      }
    }

    const lastSyncedAt = new Date().toISOString();
    await sb
      .from("health_connections")
      .update({ status: "connected", last_error: null, last_synced_at: lastSyncedAt, updated_at: lastSyncedAt })
      .eq("user_id", userId)
      .eq("provider", data.provider);

    return { imported, skipped, lastSyncedAt, unavailable: data.unavailable };
  });

/** Today's synced numbers plus their source, for the dashboard and the coach. */
export const getHealthSummary = createServerFn({ method: "POST" })
  .middleware([requireSupabaseAuth])
  .handler(async ({ context }) => {
    // eslint-disable-next-line @typescript-eslint/no-explicit-any
    const sb = context.supabase as any;
    const today = new Date().toISOString().slice(0, 10);
    const weekAgo = new Date(Date.now() - 7 * 86_400_000).toISOString().slice(0, 10);

    const [steps, sleep, hr, weight] = await Promise.all([
      sb.from("step_entries").select("steps, source, updated_at").eq("user_id", context.userId).eq("logged_on", today).maybeSingle(),
      sb.from("sleep_entries").select("minutes, source, logged_on").eq("user_id", context.userId).gte("logged_on", weekAgo).order("logged_on", { ascending: false }),
      sb.from("heart_rate_entries").select("bpm, source, measured_at").eq("user_id", context.userId).order("measured_at", { ascending: false }).limit(1),
      sb.from("progress_entries").select("weight_kg, recorded_on").eq("user_id", context.userId).not("weight_kg", "is", null).order("recorded_on", { ascending: false }).limit(1),
    ]);

    // eslint-disable-next-line @typescript-eslint/no-explicit-any
    const sleepRows = (sleep.data ?? []) as any[];
    return {
      steps: steps.data ? { value: steps.data.steps as number, source: steps.data.source as string } : null,
      sleepLastNight: sleepRows[0]
        ? { minutes: sleepRows[0].minutes as number, source: sleepRows[0].source as string }
        : null,
      sleepWeekAvgMinutes: sleepRows.length
        ? Math.round(sleepRows.reduce((sum, r) => sum + Number(r.minutes ?? 0), 0) / sleepRows.length)
        : null,
      heartRate: hr.data?.[0]
        ? { bpm: hr.data[0].bpm as number, source: hr.data[0].source as string, at: hr.data[0].measured_at as string }
        : null,
      weightKg: weight.data?.[0] ? (weight.data[0].weight_kg as number) : null,
    };
  });
