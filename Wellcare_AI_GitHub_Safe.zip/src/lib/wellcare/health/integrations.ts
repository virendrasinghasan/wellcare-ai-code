/**
 * Client-safe registry of health-data integrations.
 *
 * Reality check that drives this file: no browser can read Google Health
 * Connect (Android-native only) or Apple Health. The Google Fit REST API that
 * used to make web sync possible is retired. So the web build never shows a
 * Connect button that cannot work - it reports the integration as requiring a
 * supported environment. A native shell registers a real bridge on
 * `window.wellcareHealth` and the exact same screens light up.
 */

export type HealthProviderId =
  | "google_health"
  | "apple_health"
  | "fitbit"
  | "garmin"
  | "samsung_health";

export type HealthMetricKey =
  | "steps"
  | "distance"
  | "activity"
  | "heart_rate"
  | "weight"
  | "sleep"
  | "workout";

export interface HealthMetricMeta {
  key: HealthMetricKey;
  label: string;
  /** Shown on the consent explainer - why Wellcare asks for it. */
  why: string;
}

export const HEALTH_METRICS: HealthMetricMeta[] = [
  { key: "steps", label: "Steps", why: "Daily movement feeds your activity ring and calorie burn." },
  { key: "distance", label: "Distance", why: "Turns steps into real distance for your weekly trend." },
  { key: "activity", label: "Active calories", why: "Keeps your energy balance honest instead of estimated." },
  { key: "heart_rate", label: "Heart rate", why: "Resting heart rate is the clearest recovery signal you have." },
  { key: "weight", label: "Weight", why: "Auto-updates your targets when your weight changes." },
  { key: "sleep", label: "Sleep", why: "Sleep debt explains most bad training days." },
  { key: "workout", label: "Workouts", why: "Avoids double-logging sessions you already recorded elsewhere." },
];

export const METRIC_LABEL: Record<HealthMetricKey, string> = Object.fromEntries(
  HEALTH_METRICS.map((m) => [m.key, m.label]),
) as Record<HealthMetricKey, string>;

export interface HealthIntegrationMeta {
  id: HealthProviderId;
  label: string;
  blurb: string;
  metrics: HealthMetricKey[];
  /** Which platform the native bridge lives on. */
  platform: "android" | "ios" | "cloud";
}

export const HEALTH_INTEGRATIONS: HealthIntegrationMeta[] = [
  {
    id: "google_health",
    label: "Google Health",
    blurb: "Health Connect on Android - steps, sleep, heart rate, weight and workouts.",
    metrics: ["steps", "distance", "activity", "heart_rate", "weight", "sleep", "workout"],
    platform: "android",
  },
  {
    id: "apple_health",
    label: "Apple Health",
    blurb: "HealthKit on iPhone and Apple Watch.",
    metrics: ["steps", "distance", "activity", "heart_rate", "weight", "sleep", "workout"],
    platform: "ios",
  },
  { id: "fitbit", label: "Fitbit", blurb: "Fitbit trackers and Sense watches.", metrics: ["steps", "heart_rate", "sleep", "workout"], platform: "cloud" },
  { id: "garmin", label: "Garmin", blurb: "Garmin Connect activities and daily stats.", metrics: ["steps", "distance", "heart_rate", "sleep", "workout"], platform: "cloud" },
  { id: "samsung_health", label: "Samsung Health", blurb: "Samsung Health on Galaxy devices.", metrics: ["steps", "heart_rate", "sleep", "workout"], platform: "android" },
];

export const INTEGRATION_MAP: Record<string, HealthIntegrationMeta> = Object.fromEntries(
  HEALTH_INTEGRATIONS.map((i) => [i.id, i]),
);

/** One imported sample handed over by a native bridge. Never generated here. */
export interface HealthSample {
  metric: HealthMetricKey;
  /** ISO instant the sample belongs to. */
  at: string;
  value: number;
  /** Stable id from the platform so re-syncing cannot duplicate rows. */
  externalId?: string;
}

export interface HealthBridge {
  id: HealthProviderId;
  isAvailable(): boolean;
  requestPermissions(metrics: HealthMetricKey[]): Promise<HealthMetricKey[]>;
  readSamples(metrics: HealthMetricKey[], sinceIso: string): Promise<HealthSample[]>;
  accountId?(): Promise<string | null>;
}

declare global {
  interface Window {
    wellcareHealth?: HealthBridge;
  }
}

/** The native bridge, if this build is running inside a supported shell. */
export function getBridge(): HealthBridge | null {
  if (typeof window === "undefined") return null;
  const bridge = window.wellcareHealth;
  return bridge && bridge.isAvailable() ? bridge : null;
}

export function isSupportedHere(id: HealthProviderId): boolean {
  return getBridge()?.id === id;
}

export function unsupportedReason(meta: HealthIntegrationMeta): string {
  if (meta.platform === "android")
    return "Needs the Wellcare AI Android app - browsers can't read Health Connect.";
  if (meta.platform === "ios") return "Needs the Wellcare AI iOS app - browsers can't read Apple Health.";
  return "Not available yet.";
}

export function formatSyncedAt(iso: string | null | undefined): string {
  if (!iso) return "Never synced";
  const then = new Date(iso).getTime();
  const mins = Math.round((Date.now() - then) / 60_000);
  if (mins < 1) return "Synced just now";
  if (mins < 60) return `Synced ${mins} min ago`;
  const sameDay = new Date(iso).toDateString() === new Date().toDateString();
  const time = new Date(iso).toLocaleTimeString([], { hour: "2-digit", minute: "2-digit" });
  if (sameDay) return `Synced today at ${time}`;
  return `Synced ${new Date(iso).toLocaleDateString([], { day: "numeric", month: "short" })} at ${time}`;
}
