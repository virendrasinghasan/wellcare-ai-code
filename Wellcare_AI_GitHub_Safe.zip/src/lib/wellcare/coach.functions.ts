import { createServerFn } from "@tanstack/react-start";
import { z } from "zod";
import { requireSupabaseAuth } from "@/integrations/supabase/auth-middleware";
import type { AgentReply, AgentValue } from "./agent/types";

const FieldMap = z.record(z.string(), z.union([z.string(), z.number(), z.null()])).optional();
const AgentValueSchema: z.ZodType<AgentValue> = z.lazy(() =>
  z.union([z.string(), z.number(), z.boolean(), z.null(), z.array(AgentValueSchema), z.record(z.string(), AgentValueSchema)]),
);

const AskCoachInput = z.object({
  question: z.string().min(1).max(1000),
  snapshot: z
    .object({
      profile: FieldMap,
      nutrition: FieldMap,
      training: FieldMap,
      activity: FieldMap,
      notes: z.array(z.string().max(300)).max(8).optional(),
      local_date: z.string().max(20).optional(),
    })
    .default({}),
  history: z
    .array(z.object({ role: z.enum(["you", "coach"]), text: z.string().max(2000) }))
    .max(12)
    .default([]),
});

export type { AgentReply };

/** Wellcare AI chat entry point. Works signed-out (chat only) and signed-in (agent actions). */
export const askCoach = createServerFn({ method: "POST" })
  .inputValidator((input: unknown) => AskCoachInput.parse(input))
  .handler(async ({ data }): Promise<AgentReply> => {
    const { resolveOptionalAuth } = await import("./agent/optional-auth.server");
    const { auth, reason } = await resolveOptionalAuth();

    if (!auth) {
      const { WellcareAIService } = await import("./ai/service.server");
      const result = await WellcareAIService.ask(
        { question: data.question, history: data.history, snapshot: data.snapshot },
        "anonymous",
      );
      const note =
        reason === "no-session"
          ? "\n\n(Heads up: you're not signed in, so I can't save anything to your diary. Sign in and I'll log it for real.)"
          : "\n\n(Heads up: your session couldn't be verified, so I can't change your data right now. Sign in again and I'll log it for real.)";
      return {
        ok: result.ok,
        reply: result.ok ? `${result.reply}${note}` : result.message,
        actions: [],
        clientOps: [],
        performed: [],
        undoable: false,
      };
    }

    const { runAgent } = await import("./agent/service.server");
    try {
      return await runAgent({ question: data.question, history: data.history, snapshot: data.snapshot }, auth);
    } catch (error) {
      console.error("[askCoach] agent failed", error);
      return {
        ok: false,
        reply: "I hit a snag on my side and nothing was saved. Try that again in a moment.",
        actions: [],
        clientOps: [],
        performed: [],
        undoable: false,
      };
    }
  });

export const confirmCoachAction = createServerFn({ method: "POST" })
  .middleware([requireSupabaseAuth])
  .inputValidator((input: unknown) => z.object({ name: z.string().min(1), args: z.record(z.string(), AgentValueSchema), originalRequest: z.string().min(1).max(1000) }).parse(input))
  .handler(async ({ data, context }) => {
    const { confirmAgentTool } = await import("./agent/service.server");
    return confirmAgentTool(data, context);
  });
