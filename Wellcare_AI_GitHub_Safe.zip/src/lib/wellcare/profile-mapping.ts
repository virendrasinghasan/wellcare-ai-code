import { emptyProfile } from "./types";
import type {
  ActivityLevel,
  DietType,
  Equipment,
  Experience,
  HeightUnit,
  PrimaryGoal,
  Sex,
  WeightUnit,
  WellcareProfile,
} from "./types";

/** Maps our richer onboarding goals onto the DB `fitness_goal` enum. */
const GOAL_TO_ENUM: Record<PrimaryGoal, string> = {
  lose_weight: "lose_fat",
  gain_muscle: "build_muscle",
  maintain_weight: "maintain",
  build_strength: "performance",
  improve_fitness: "performance",
  improve_health: "maintain",
};

export interface ProfileRow {
  [key: string]: unknown;
}

export function profileToRow(p: WellcareProfile, userId: string): ProfileRow {
  return {
    id: userId,
    first_name: p.firstName || null,
    display_name: p.firstName || null,
    avatar_url: p.avatarPath,
    sex: p.sex,
    birth_date: null,
    height_cm: p.heightCm,
    weight_kg: p.weightKg,
    body_fat_pct: p.bodyFatPct,
    weight_unit: p.weightUnit,
    height_unit: p.heightUnit,
    goal: p.goal ? GOAL_TO_ENUM[p.goal] : "maintain",
    secondary_goals: p.secondaryGoals,
    activity_level: p.activityLevel ?? "moderate",
    training_experience: p.experience,
    training_days_per_week: p.daysPerWeek,
    equipment: p.equipment,
    diet_type: p.dietType,
    allergies: p.allergies,
    avoided_foods: p.avoidedFoods,
    tdee_estimate: p.tdeeEstimate,
    tdee_method: p.tdeeMethod,
    tdee_inputs: {
      primary_goal: p.goal,
      secondary_goals: p.secondaryGoals,
      sex: p.sex,
      age_mode: p.ageMode,
      age_years: p.ageYears,
      birth_year: p.birthYear,
      height_cm: p.heightCm,
      weight_kg: p.weightKg,
      body_fat_pct: p.bodyFatPct,
      activity_level: p.activityLevel,
    },
    daily_calorie_target: p.targets?.calories ?? 2200,
    daily_protein_target_g: p.targets?.protein ?? 150,
    daily_carbs_target_g: p.targets?.carbs ?? 240,
    daily_fat_target_g: p.targets?.fat ?? 70,
    daily_water_target_ml: p.waterTargetMl,
    health_provider: p.health.provider,
    health_connected: p.health.connected,
    health_metrics: p.health.metrics,
    onboarding_completed: p.onboardingCompleted,
  };
}

function str<T extends string>(v: unknown): T | null {
  return typeof v === "string" && v.length > 0 ? (v as T) : null;
}

function arr<T extends string>(v: unknown): T[] {
  return Array.isArray(v) ? (v.filter((x) => typeof x === "string") as T[]) : [];
}

function num(v: unknown): number | null {
  return v == null ? null : Number(v);
}

export function profileFromRow(row: ProfileRow): WellcareProfile {
  const inputs = (row["tdee_inputs"] ?? {}) as Record<string, unknown>;
  return {
    ...emptyProfile,
    firstName: (str<string>(row["first_name"]) ?? str<string>(row["display_name"]) ?? "") as string,
    avatarPath: str<string>(row["avatar_url"]),
    sex: str<Sex>(row["sex"]),
    ageMode: (inputs["age_mode"] === "birth_year" ? "birth_year" : "age"),
    ageYears: num(inputs["age_years"]),
    birthYear: num(inputs["birth_year"]),
    heightCm: num(row["height_cm"]),
    weightKg: num(row["weight_kg"]),
    bodyFatPct: num(row["body_fat_pct"]),
    weightUnit: (str<WeightUnit>(row["weight_unit"]) ?? "kg") as WeightUnit,
    heightUnit: (str<HeightUnit>(row["height_unit"]) ?? "cm") as HeightUnit,
    goal: str<PrimaryGoal>(inputs["primary_goal"]),
    secondaryGoals: arr<PrimaryGoal>(row["secondary_goals"]),
    activityLevel: str<ActivityLevel>(row["activity_level"]),
    experience: str<Experience>(row["training_experience"]),
    daysPerWeek: num(row["training_days_per_week"]),
    equipment: arr<Equipment>(row["equipment"]),
    dietType: str<DietType>(row["diet_type"]),
    allergies: arr<string>(row["allergies"]),
    avoidedFoods: arr<string>(row["avoided_foods"]),
    tdeeEstimate: num(row["tdee_estimate"]),
    tdeeMethod: str<string>(row["tdee_method"]),
    targets: {
      calories: Number(row["daily_calorie_target"] ?? 2200),
      protein: Number(row["daily_protein_target_g"] ?? 150),
      carbs: Number(row["daily_carbs_target_g"] ?? 240),
      fat: Number(row["daily_fat_target_g"] ?? 70),
    },
    waterTargetMl: Number(row["daily_water_target_ml"] ?? 2500),
    health: {
      connected: Boolean(row["health_connected"]),
      provider: (str<"apple_health" | "google_fit">(row["health_provider"]) ?? null),
      metrics: arr<"steps" | "activity" | "sleep">(row["health_metrics"]),
    },
    onboardingCompleted: Boolean(row["onboarding_completed"]),
  };
}
