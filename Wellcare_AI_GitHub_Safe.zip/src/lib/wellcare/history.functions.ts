import { createServerFn } from "@tanstack/react-start";
import { z } from "zod";
import { requireSupabaseAuth } from "@/integrations/supabase/auth-middleware";

const isoDate = z.string().regex(/^\d{4}-\d{2}-\d{2}$/);

const HistoryInput = z.object({
  start: isoDate,
  end: isoDate,
});

export interface HistoryMealItem {
  name: string;
  quantity: number;
  unit: string;
  calories: number;
  protein: number;
  carbs: number;
  fat: number;
}

export interface HistoryMeal {
  id: string;
  type: string;
  title: string | null;
  items: HistoryMealItem[];
}

export interface HistorySet {
  exercise: string;
  setNumber: number;
  reps: number | null;
  weightKg: number | null;
}

export interface HistoryWorkout {
  id: string;
  title: string | null;
  durationMinutes: number | null;
  effort: number | null;
  sets: HistorySet[];
}

export interface HistoryDay {
  date: string;
  meals: HistoryMeal[];
  totals: { calories: number; protein: number; carbs: number; fat: number };
  workouts: HistoryWorkout[];
  waterMl: number;
  steps: number | null;
  sleepMinutes: number | null;
  sleepQuality: number | null;
  weightKg: number | null;
  bodyFatPct: number | null;
  restingHeartRate: number | null;
  glucose: Array<{ value: number; unit: string; at: string }>;
}

function emptyDay(date: string): HistoryDay {
  return {
    date,
    meals: [],
    totals: { calories: 0, protein: 0, carbs: 0, fat: 0 },
    workouts: [],
    waterMl: 0,
    steps: null,
    sleepMinutes: null,
    sleepQuality: null,
    weightKg: null,
    bodyFatPct: null,
    restingHeartRate: null,
    glucose: [],
  };
}

function dateRange(start: string, end: string) {
  const days: string[] = [];
  const cursor = new Date(`${start}T00:00:00Z`);
  const last = new Date(`${end}T00:00:00Z`);
  while (cursor.getTime() <= last.getTime() && days.length < 400) {
    days.push(cursor.toISOString().slice(0, 10));
    cursor.setUTCDate(cursor.getUTCDate() + 1);
  }
  return days;
}

/** Real per-day history for the signed-in user, newest day first. */
export const getHistory = createServerFn({ method: "POST" })
  .middleware([requireSupabaseAuth])
  .inputValidator((input: unknown) => HistoryInput.parse(input))
  .handler(async ({ data, context }): Promise<{ days: HistoryDay[] }> => {
    const { supabase, userId } = context;
    const { start, end } = data;
    const startStamp = `${start}T00:00:00.000Z`;
    const endStamp = `${end}T23:59:59.999Z`;

    const [meals, sessions, water, steps, sleep, progress, heart, glucose] = await Promise.all([
      supabase
        .from("meals")
        .select("id,logged_on,meal_type,title,meal_items(name,quantity,unit,calories,protein_g,carbs_g,fat_g)")
        .eq("user_id", userId)
        .gte("logged_on", start)
        .lte("logged_on", end),
      supabase
        .from("workout_sessions")
        .select("id,performed_on,title,duration_seconds,perceived_effort,workout_set_logs(exercise_name,set_number,reps,weight_kg)")
        .eq("user_id", userId)
        .gte("performed_on", start)
        .lte("performed_on", end),
      supabase.from("water_logs").select("logged_on,amount_ml").eq("user_id", userId).gte("logged_on", start).lte("logged_on", end),
      supabase.from("step_entries").select("logged_on,steps").eq("user_id", userId).gte("logged_on", start).lte("logged_on", end),
      supabase.from("sleep_entries").select("logged_on,minutes,quality").eq("user_id", userId).gte("logged_on", start).lte("logged_on", end),
      supabase.from("progress_entries").select("recorded_on,weight_kg,body_fat_pct").eq("user_id", userId).gte("recorded_on", start).lte("recorded_on", end),
      supabase.from("heart_rate_entries").select("measured_at,bpm,is_resting").eq("user_id", userId).gte("measured_at", startStamp).lte("measured_at", endStamp),
      supabase.from("blood_glucose_entries").select("measured_at,value,unit").eq("user_id", userId).gte("measured_at", startStamp).lte("measured_at", endStamp),
    ]);

    const failure = meals.error || sessions.error || water.error || steps.error || sleep.error || progress.error || heart.error || glucose.error;
    if (failure) throw new Error(failure.message);

    const map = new Map<string, HistoryDay>();
    for (const date of dateRange(start, end)) map.set(date, emptyDay(date));
    const dayFor = (date: string) => {
      const existing = map.get(date);
      if (existing) return existing;
      const created = emptyDay(date);
      map.set(date, created);
      return created;
    };

    for (const meal of meals.data ?? []) {
      const day = dayFor(meal.logged_on);
      const items = (meal.meal_items ?? []).map((item) => ({
        name: item.name,
        quantity: Number(item.quantity),
        unit: item.unit,
        calories: Number(item.calories),
        protein: Number(item.protein_g),
        carbs: Number(item.carbs_g),
        fat: Number(item.fat_g),
      }));
      if (items.length) {
        day.meals.push({ id: meal.id, type: meal.meal_type, title: meal.title, items });
        for (const item of items) {
          day.totals.calories += item.calories;
          day.totals.protein += item.protein;
          day.totals.carbs += item.carbs;
          day.totals.fat += item.fat;
        }
      }
    }

    for (const session of sessions.data ?? []) {
      const day = dayFor(session.performed_on);
      day.workouts.push({
        id: session.id,
        title: session.title,
        durationMinutes: session.duration_seconds == null ? null : Math.round(session.duration_seconds / 60),
        effort: session.perceived_effort,
        sets: (session.workout_set_logs ?? []).map((set) => ({
          exercise: set.exercise_name,
          setNumber: set.set_number,
          reps: set.reps,
          weightKg: set.weight_kg == null ? null : Number(set.weight_kg),
        })),
      });
    }

    for (const entry of water.data ?? []) dayFor(entry.logged_on).waterMl += entry.amount_ml;
    for (const entry of steps.data ?? []) {
      const day = dayFor(entry.logged_on);
      day.steps = (day.steps ?? 0) + entry.steps;
    }
    for (const entry of sleep.data ?? []) {
      const day = dayFor(entry.logged_on);
      day.sleepMinutes = (day.sleepMinutes ?? 0) + entry.minutes;
      if (entry.quality != null) day.sleepQuality = entry.quality;
    }
    for (const entry of progress.data ?? []) {
      const day = dayFor(entry.recorded_on);
      if (entry.weight_kg != null) day.weightKg = Number(entry.weight_kg);
      if (entry.body_fat_pct != null) day.bodyFatPct = Number(entry.body_fat_pct);
    }
    for (const entry of heart.data ?? []) {
      if (!entry.is_resting) continue;
      dayFor(entry.measured_at.slice(0, 10)).restingHeartRate = entry.bpm;
    }
    for (const entry of glucose.data ?? []) {
      dayFor(entry.measured_at.slice(0, 10)).glucose.push({ value: Number(entry.value), unit: entry.unit, at: entry.measured_at });
    }

    const days = [...map.values()].sort((a, b) => (a.date < b.date ? 1 : -1));
    return { days };
  });
