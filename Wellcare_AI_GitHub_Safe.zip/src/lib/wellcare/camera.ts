/**
 * Camera helpers shared by the barcode and meal scanners.
 *
 * Phone cameras default to a focus distance that is far too long for a barcode
 * held 10 cm away, so we push continuous autofocus, expose tap-to-focus and a
 * small optical zoom where the browser supports it. Everything degrades
 * silently: unsupported capabilities are simply skipped.
 */

type AnyTrack = MediaStreamTrack & {
  getCapabilities?: () => Record<string, unknown>;
  getSettings?: () => Record<string, unknown>;
};

export interface CameraCapabilities {
  focus: boolean;
  tapToFocus: boolean;
  torch: boolean;
  zoom: { min: number; max: number; step: number } | null;
}

export async function openRearCamera(video: HTMLVideoElement): Promise<MediaStream> {
  const stream = await navigator.mediaDevices.getUserMedia({
    video: {
      facingMode: { ideal: "environment" },
      width: { ideal: 1920 },
      height: { ideal: 1080 },
      frameRate: { ideal: 30 },
    },
    audio: false,
  });
  video.srcObject = stream;
  video.setAttribute("playsinline", "true");
  await video.play().catch(() => {});
  return stream;
}

function track(stream: MediaStream | null): AnyTrack | null {
  return (stream?.getVideoTracks()[0] as AnyTrack) ?? null;
}

export function readCapabilities(stream: MediaStream | null): CameraCapabilities {
  const t = track(stream);
  const caps = (t?.getCapabilities?.() ?? {}) as Record<string, unknown>;
  const modes = (caps['focusMode'] as string[] | undefined) ?? [];
  const zoom = caps['zoom'] as { min?: number; max?: number; step?: number } | undefined;
  return {
    focus: modes.includes("continuous"),
    tapToFocus: Array.isArray(caps['pointsOfInterest'] ?? null)
      ? true
      : modes.includes("manual") || modes.includes("single-shot"),
    torch: caps['torch'] === true,
    zoom:
      zoom && typeof zoom.max === "number" && typeof zoom.min === "number" && zoom.max > zoom.min
        ? { min: zoom.min, max: zoom.max, step: zoom.step ?? 0.1 }
        : null,
  };
}

async function apply(t: AnyTrack | null, constraint: Record<string, unknown>) {
  if (!t) return false;
  try {
    await t.applyConstraints({ advanced: [constraint] } as MediaTrackConstraints);
    return true;
  } catch {
    return false;
  }
}

/** Turns on continuous autofocus and a gentle close-range zoom for small codes. */
export async function tuneForCloseUp(stream: MediaStream | null) {
  const t = track(stream);
  if (!t) return;
  const caps = readCapabilities(stream);
  if (caps.focus) await apply(t, { focusMode: "continuous" });
  if (caps.zoom) {
    const target = Math.min(caps.zoom.max, caps.zoom.min + (caps.zoom.max - caps.zoom.min) * 0.2);
    await apply(t, { zoom: target });
  }
}

/** Focuses on a normalised point (0-1) inside the video frame. */
export async function focusAt(stream: MediaStream | null, x: number, y: number) {
  const t = track(stream);
  if (!t) return;
  const ok = await apply(t, {
    pointsOfInterest: [{ x: Math.min(1, Math.max(0, x)), y: Math.min(1, Math.max(0, y)) }],
    focusMode: "single-shot",
  });
  if (!ok) await apply(t, { focusMode: "continuous" });
  // Hand control back to continuous focus once the single shot has settled.
  window.setTimeout(() => void apply(t, { focusMode: "continuous" }), 1500);
}

export async function setZoom(stream: MediaStream | null, value: number) {
  await apply(track(stream), { zoom: value });
}

export async function setTorch(stream: MediaStream | null, on: boolean) {
  return apply(track(stream), { torch: on });
}

export function stopStream(stream: MediaStream | null) {
  stream?.getTracks().forEach((t) => t.stop());
}
