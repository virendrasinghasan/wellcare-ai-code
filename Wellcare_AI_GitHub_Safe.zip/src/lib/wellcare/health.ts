/**
 * Health / activity integration abstraction.
 *
 * The browser preview cannot read Apple Health (HealthKit) or Google Fit /
 * Health Connect. Rather than fake device data, this module defines the
 * provider contract and ships a web provider that reports "unavailable".
 * A native wrapper (Capacitor plugin, native shell, etc.) registers a real
 * provider at startup via `registerHealthProvider` and everything above this
 * layer keeps working unchanged.
 */

export type HealthMetric = "steps" | "activity" | "sleep";

export interface HealthSnapshot {
  steps: number | null;
  activeMinutes: number | null;
  sleepMinutes: number | null;
  /** Where the numbers came from - never invented. */
  source: "apple_health" | "google_fit" | "none";
}

export interface HealthProvider {
  id: "apple_health" | "google_fit" | "web";
  label: string;
  isAvailable(): boolean;
  requestPermissions(metrics: HealthMetric[]): Promise<boolean>;
  getTodaySnapshot(): Promise<HealthSnapshot>;
}

const webProvider: HealthProvider = {
  id: "web",
  label: "Not available in browser",
  isAvailable: () => false,
  requestPermissions: async () => false,
  getTodaySnapshot: async () => ({
    steps: null,
    activeMinutes: null,
    sleepMinutes: null,
    source: "none",
  }),
};

let activeProvider: HealthProvider = webProvider;

export function registerHealthProvider(provider: HealthProvider) {
  activeProvider = provider;
}

export function getHealthProvider(): HealthProvider {
  return activeProvider;
}

/** What the current platform would use once running inside a native shell. */
export function detectPlatformProvider(): "apple_health" | "google_fit" {
  if (typeof navigator === "undefined") return "google_fit";
  const ua = navigator.userAgent;
  return /iPhone|iPad|iPod|Mac/i.test(ua) ? "apple_health" : "google_fit";
}

export function isHealthAvailable(): boolean {
  return activeProvider.isAvailable();
}
