import { createGeminiProvider, ProviderError } from "./gemini.server";
import { WELLCARE_SYSTEM_PROMPT, renderContextBlock } from "./persona.server";
import type {
  AIProvider,
  WellcareAskRequest,
  WellcareAskResult,
  WellcareChatMessage,
  WellcareContextSnapshot,
} from "./types";

/** Single place where the provider is chosen. */
function getProvider(): AIProvider {
  switch (process.env["WELLCARE_AI_PROVIDER"] || "gemini") {
    case "gemini":
    default:
      return createGeminiProvider();
  }
}

/* ---------------------------------- rate limit --------------------------- */

const WINDOW_MS = 60_000;
const MAX_PER_WINDOW = 15;
const buckets = new Map<string, number[]>();

function rateLimited(key: string): boolean {
  const now = Date.now();
  const hits = (buckets.get(key) ?? []).filter((t) => now - t < WINDOW_MS);
  hits.push(now);
  buckets.set(key, hits);
  if (buckets.size > 500) buckets.clear();
  return hits.length > MAX_PER_WINDOW;
}

/* ------------------------------ context picking -------------------------- */

const KEYWORDS = {
  nutrition: /(eat|food|meal|calorie|kcal|macro|protein|carb|fat|snack|dinner|lunch|breakfast|diet|hungry|water|hydrat|sugar|weight)/i,
  training: /(workout|train|gym|lift|exercise|run|cardio|leg|push|pull|rest|recover|sore|program|plan|session|reps|sets|strength|muscle)/i,
  activity: /(step|sleep|walk|active|move|tired|energy|recover)/i,
};

/** Only ships the sections that matter for the current question. */
export function selectContext(
  question: string,
  full: WellcareContextSnapshot,
): WellcareContextSnapshot {
  const wantsNutrition = KEYWORDS.nutrition.test(question);
  const wantsTraining = KEYWORDS.training.test(question);
  const wantsActivity = KEYWORDS.activity.test(question);
  const generic = !wantsNutrition && !wantsTraining && !wantsActivity;

  return {
    profile: full.profile,
    nutrition: wantsNutrition || generic ? full.nutrition : undefined,
    training: wantsTraining || generic ? full.training : undefined,
    activity: wantsActivity || generic ? full.activity : undefined,
    notes: full.notes,
  };
}

/* --------------------------------- service ------------------------------- */

const FRIENDLY_BUSY = "I'm having a little trouble connecting right now. Give me a moment and try again.";
const FRIENDLY_HARD = "I can't respond right now. Please try again shortly.";
const FRIENDLY_FAST = "You're moving faster than I can think. Give me a second.";

export const WellcareAIService = {
  async ask(req: WellcareAskRequest, rateKey: string): Promise<WellcareAskResult> {
    if (rateLimited(rateKey)) return { ok: false, message: FRIENDLY_FAST };

    const context = selectContext(req.question, req.snapshot);
    const history: WellcareChatMessage[] = req.history.slice(-8);

    const messages: WellcareChatMessage[] = [
      ...history,
      {
        role: "you",
        text: `[Wellcare context - do not repeat back verbatim]\n${renderContextBlock(context)}\n\n${req.question}`,
      },
    ];

    try {
      const provider = getProvider();
      const reply = await provider.generate({ system: WELLCARE_SYSTEM_PROMPT, messages });
      return { ok: true, reply };
    } catch (err) {
      const status = err instanceof ProviderError ? err.status : -1;
      // Technical detail stays server-side only.
      console.error("[wellcare-ai] provider failure", status, String(err).slice(0, 500));
      const transient = status === 429 || status >= 500 || status === 0;
      return { ok: false, message: transient ? FRIENDLY_BUSY : FRIENDLY_HARD };
    }
  },
};
