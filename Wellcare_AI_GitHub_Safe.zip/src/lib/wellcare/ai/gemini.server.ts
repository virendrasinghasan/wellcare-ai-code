import type { AIProvider, WellcareChatMessage } from "./types";

const DEFAULT_MODEL = "gemini-2.5-flash";

/** Thrown for provider failures. The service maps these to friendly copy. */
export class ProviderError extends Error {
  constructor(
    message: string,
    readonly status: number,
  ) {
    super(message);
    this.name = "ProviderError";
  }
}

/**
 * Gemini implementation of the Wellcare AI provider contract.
 * Swap this out (OpenAI, etc.) without touching the service or the chat UI.
 */
export function createGeminiProvider(): AIProvider {
  const apiKey = process.env["GEMINI_API_KEY"];
  const model = process.env["GEMINI_MODEL"] || DEFAULT_MODEL;

  if (!apiKey) throw new ProviderError("GEMINI_API_KEY is not configured", 0);

  return {
    name: "gemini",
    async generate({ system, messages }) {
      const contents = messages.map((m: WellcareChatMessage) => ({
        role: m.role === "you" ? "user" : "model",
        parts: [{ text: m.text }],
      }));

      let res: Response;
      try {
        res = await fetch(
          `https://generativelanguage.googleapis.com/v1beta/models/${encodeURIComponent(model)}:generateContent`,
          {
            method: "POST",
            headers: { "Content-Type": "application/json", "x-goog-api-key": apiKey },
            body: JSON.stringify({
              systemInstruction: { parts: [{ text: system }] },
              contents,
              generationConfig: { temperature: 0.8, maxOutputTokens: 700, topP: 0.95 },
            }),
          },
        );
      } catch (err) {
        throw new ProviderError(`network failure: ${String(err)}`, 0);
      }

      if (!res.ok) {
        const detail = await res.text().catch(() => "");
        throw new ProviderError(detail.slice(0, 500) || "provider error", res.status);
      }

      const payload = (await res.json()) as {
        candidates?: { content?: { parts?: { text?: string }[] } }[];
      };

      const text = (payload.candidates?.[0]?.content?.parts ?? [])
        .map((p) => p.text ?? "")
        .join("")
        .trim();

      if (!text) throw new ProviderError("empty completion", 200);
      return text;
    },
  };
}
