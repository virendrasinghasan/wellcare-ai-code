/** Provider-agnostic contract for the Wellcare AI brain. */

export interface WellcareChatMessage {
  role: "you" | "coach";
  text: string;
}

/** Compact, relevance-filtered snapshot of the user's Wellcare data. */
export interface WellcareContextSnapshot {
  profile?: Record<string, string | number | null | undefined> | undefined;
  nutrition?: Record<string, string | number | null | undefined> | undefined;
  training?: Record<string, string | number | null | undefined> | undefined;
  activity?: Record<string, string | number | null | undefined> | undefined;
  notes?: string[] | undefined;
}

export interface WellcareAskRequest {
  question: string;
  history: WellcareChatMessage[];
  snapshot: WellcareContextSnapshot;
}

/** What the chat UI receives. Never carries provider/technical detail. */
export type WellcareAskResult =
  | { ok: true; reply: string }
  | { ok: false; message: string };

export interface AIProvider {
  readonly name: string;
  /** Returns generated text, or throws. Throwing is handled by the service. */
  generate(input: { system: string; messages: WellcareChatMessage[] }): Promise<string>;
}
