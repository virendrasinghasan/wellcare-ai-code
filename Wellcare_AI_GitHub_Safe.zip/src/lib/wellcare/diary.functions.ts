import { createServerFn } from "@tanstack/react-start";
import { z } from "zod";
import { requireSupabaseAuth } from "@/integrations/supabase/auth-middleware";
import type { DayLog, MealType } from "./types";

const isoDate = z.string().regex(/^\d{4}-\d{2}-\d{2}$/);
const mealType = z.enum(["breakfast", "lunch", "dinner", "snack"]);

const EntryInput = z.object({
  date: isoDate,
  meal: mealType,
  name: z.string().trim().min(1).max(300),
  quantity: z.number().finite().positive().max(10000).default(1),
  unit: z.string().trim().max(20).default("serving"),
  calories: z.number().finite().nonnegative().max(20000),
  protein: z.number().finite().nonnegative().max(2000),
  carbs: z.number().finite().nonnegative().max(2000),
  fat: z.number().finite().nonnegative().max(2000),
});

function timeLabel(iso: string) {
  const date = new Date(iso);
  return `${String(date.getHours()).padStart(2, "0")}:${String(date.getMinutes()).padStart(2, "0")}`;
}

/** Real diary (meals + water) for the signed-in user, keyed by calendar date. */
export const loadDiary = createServerFn({ method: "POST" })
  .middleware([requireSupabaseAuth])
  .inputValidator((input: unknown) => z.object({ from: isoDate, to: isoDate }).parse(input))
  .handler(async ({ data, context }): Promise<Record<string, DayLog>> => {
    const { supabase, userId } = context;
    const [meals, water] = await Promise.all([
      supabase
        .from("meals")
        .select("id,logged_on,meal_type,meal_items(id,name,calories,protein_g,carbs_g,fat_g,created_at)")
        .eq("user_id", userId)
        .gte("logged_on", data.from)
        .lte("logged_on", data.to),
      supabase
        .from("water_logs")
        .select("logged_on,amount_ml")
        .eq("user_id", userId)
        .gte("logged_on", data.from)
        .lte("logged_on", data.to),
    ]);
    if (meals.error) throw new Error(meals.error.message);
    if (water.error) throw new Error(water.error.message);

    const logs: Record<string, DayLog> = {};
    const dayFor = (date: string) => (logs[date] ??= { date, entries: [], waterMl: 0 });

    for (const meal of meals.data ?? []) {
      const day = dayFor(meal.logged_on);
      for (const item of meal.meal_items ?? []) {
        day.entries.push({
          id: item.id,
          meal: meal.meal_type as MealType,
          name: item.name,
          time: timeLabel(item.created_at),
          calories: Number(item.calories),
          protein: Number(item.protein_g),
          carbs: Number(item.carbs_g),
          fat: Number(item.fat_g),
        });
      }
    }
    for (const entry of water.data ?? []) dayFor(entry.logged_on).waterMl += entry.amount_ml;
    for (const day of Object.values(logs)) day.entries.sort((a, b) => a.time.localeCompare(b.time));
    return logs;
  });

/** Insert a food entry and return the persisted row id. */
export const saveDiaryEntry = createServerFn({ method: "POST" })
  .middleware([requireSupabaseAuth])
  .inputValidator((input: unknown) => EntryInput.parse(input))
  .handler(async ({ data, context }): Promise<{ id: string }> => {
    const { supabase, userId } = context;
    const existing = await supabase
      .from("meals")
      .select("id")
      .eq("user_id", userId)
      .eq("logged_on", data.date)
      .eq("meal_type", data.meal)
      .limit(1)
      .maybeSingle();
    if (existing.error) throw new Error(existing.error.message);
    let mealId = existing.data?.id;
    if (!mealId) {
      const created = await supabase
        .from("meals")
        .insert({ user_id: userId, logged_on: data.date, meal_type: data.meal, title: data.meal })
        .select("id")
        .single();
      if (created.error) throw new Error(created.error.message);
      mealId = created.data.id;
    }
    const inserted = await supabase
      .from("meal_items")
      .insert({
        meal_id: mealId,
        user_id: userId,
        name: data.name,
        quantity: data.quantity,
        unit: data.unit,
        calories: data.calories,
        protein_g: data.protein,
        carbs_g: data.carbs,
        fat_g: data.fat,
      })
      .select("id")
      .single();
    if (inserted.error) throw new Error(inserted.error.message);
    return { id: inserted.data.id };
  });

export const deleteDiaryEntry = createServerFn({ method: "POST" })
  .middleware([requireSupabaseAuth])
  .inputValidator((input: unknown) => z.object({ id: z.string().uuid() }).parse(input))
  .handler(async ({ data, context }) => {
    const { error } = await context.supabase
      .from("meal_items")
      .delete()
      .eq("id", data.id)
      .eq("user_id", context.userId);
    if (error) throw new Error(error.message);
    return { ok: true };
  });

export const saveWaterLog = createServerFn({ method: "POST" })
  .middleware([requireSupabaseAuth])
  .inputValidator((input: unknown) =>
    z.object({ date: isoDate, ml: z.number().int().min(-5000).max(10000) }).parse(input),
  )
  .handler(async ({ data, context }) => {
    const { error } = await context.supabase
      .from("water_logs")
      .insert({ user_id: context.userId, logged_on: data.date, amount_ml: data.ml });
    if (error) throw new Error(error.message);
    return { ok: true };
  });
