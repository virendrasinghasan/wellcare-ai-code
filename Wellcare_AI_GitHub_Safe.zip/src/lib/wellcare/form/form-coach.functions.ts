import { createServerFn } from "@tanstack/react-start";
import { getRequestHeader } from "@tanstack/react-start/server";
import { z } from "zod";
import type { WellcareAskResult } from "../ai/types";

const SetReviewInput = z.object({
  exercise: z.string().min(1).max(80),
  reps: z.number().int().min(0).max(200),
  score: z.number().min(0).max(100),
  rangeOfMotion: z.number().min(0).max(100),
  control: z.number().min(0).max(100),
  alignment: z.number().min(0).max(100),
  consistency: z.number().min(0).max(100),
  notes: z.array(z.string().max(200)).max(4).default([]),
});

/**
 * Post-set coaching. Gemini never sees video - only the numbers the on-device
 * analyzer produced after the set finished.
 */
export const reviewSet = createServerFn({ method: "POST" })
  .inputValidator((input: unknown) => SetReviewInput.parse(input))
  .handler(async ({ data }): Promise<WellcareAskResult> => {
    const { WellcareAIService } = await import("../ai/service.server");
    const rateKey =
      getRequestHeader("cf-connecting-ip") || getRequestHeader("x-forwarded-for") || "anonymous";

    const question = [
      `I just finished a set of ${data.exercise} with the camera form coach.`,
      `Reps: ${data.reps}. Technique score: ${Math.round(data.score)}/100.`,
      `Range of motion ${Math.round(data.rangeOfMotion)}, control ${Math.round(data.control)}, alignment ${Math.round(data.alignment)}, consistency ${Math.round(data.consistency)}.`,
      data.notes.length ? `The analyzer flagged: ${data.notes.join(" ")}` : "",
      "Give me a short review: what was good, the single most important fix, and what to do on the next set. Three sentences max.",
    ]
      .filter(Boolean)
      .join(" ");

    return WellcareAIService.ask({ question, history: [], snapshot: {} }, rateKey);
  });
