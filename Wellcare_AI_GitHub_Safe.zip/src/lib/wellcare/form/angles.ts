/** JointAngleService - normalized geometry helpers over pose landmarks. */

export interface Landmark {
  x: number;
  y: number;
  z: number;
  visibility: number;
}

/** MediaPipe Pose landmark indices we care about. */
export const LM = {
  nose: 0,
  leftShoulder: 11,
  rightShoulder: 12,
  leftElbow: 13,
  rightElbow: 14,
  leftWrist: 15,
  rightWrist: 16,
  leftHip: 23,
  rightHip: 24,
  leftKnee: 25,
  rightKnee: 26,
  leftAnkle: 27,
  rightAnkle: 28,
} as const;

export const SKELETON: [number, number][] = [
  [LM.leftShoulder, LM.rightShoulder],
  [LM.leftShoulder, LM.leftElbow],
  [LM.leftElbow, LM.leftWrist],
  [LM.rightShoulder, LM.rightElbow],
  [LM.rightElbow, LM.rightWrist],
  [LM.leftShoulder, LM.leftHip],
  [LM.rightShoulder, LM.rightHip],
  [LM.leftHip, LM.rightHip],
  [LM.leftHip, LM.leftKnee],
  [LM.leftKnee, LM.leftAnkle],
  [LM.rightHip, LM.rightKnee],
  [LM.rightKnee, LM.rightAnkle],
];

export const TRACKED_POINTS = Object.values(LM);

/** Angle ABC in degrees. Scale-invariant, so camera distance doesn't matter. */
export function angleAt(a: Landmark, b: Landmark, c: Landmark): number {
  const abx = a.x - b.x;
  const aby = a.y - b.y;
  const cbx = c.x - b.x;
  const cby = c.y - b.y;
  const dot = abx * cbx + aby * cby;
  const mag = Math.hypot(abx, aby) * Math.hypot(cbx, cby);
  if (mag === 0) return 0;
  return (Math.acos(Math.max(-1, Math.min(1, dot / mag))) * 180) / Math.PI;
}

/** Angle of the segment A→B against vertical, in degrees (0 = perfectly upright). */
export function angleFromVertical(a: Landmark, b: Landmark): number {
  const dx = b.x - a.x;
  const dy = b.y - a.y;
  return (Math.atan2(Math.abs(dx), Math.abs(dy)) * 180) / Math.PI;
}

export function midpoint(a: Landmark, b: Landmark): Landmark {
  return {
    x: (a.x + b.x) / 2,
    y: (a.y + b.y) / 2,
    z: (a.z + b.z) / 2,
    visibility: Math.min(a.visibility, b.visibility),
  };
}

/** Torso length used to normalize distances across body sizes and camera distance. */
export function torsoLength(lms: Landmark[]): number {
  const sh = midpoint(lms[LM.leftShoulder]!, lms[LM.rightShoulder]!);
  const hip = midpoint(lms[LM.leftHip]!, lms[LM.rightHip]!);
  return Math.hypot(sh.x - hip.x, sh.y - hip.y) || 1;
}

/** Average of the left and right versions of a measurement, preferring the more visible side. */
export function bilateral(left: number, right: number, lv: number, rv: number): number {
  if (lv < 0.4 && rv >= 0.4) return right;
  if (rv < 0.4 && lv >= 0.4) return left;
  return (left + right) / 2;
}

export interface JointAngles {
  leftKnee: number;
  rightKnee: number;
  knee: number;
  leftElbow: number;
  rightElbow: number;
  elbow: number;
  leftHip: number;
  rightHip: number;
  hip: number;
  leftShoulderAbduction: number;
  rightShoulderAbduction: number;
  shoulderAbduction: number;
  torsoFromVertical: number;
  /** Horizontal knee-over-ankle drift, normalized by torso length. */
  kneeDrift: number;
  /** Body-line straightness for planks/push-ups: 180 = perfectly straight. */
  bodyLine: number;
}

export function computeAngles(l: Landmark[]): JointAngles {
  const g = (i: number) => l[i]!;
  const leftKnee = angleAt(g(LM.leftHip), g(LM.leftKnee), g(LM.leftAnkle));
  const rightKnee = angleAt(g(LM.rightHip), g(LM.rightKnee), g(LM.rightAnkle));
  const leftElbow = angleAt(g(LM.leftShoulder), g(LM.leftElbow), g(LM.leftWrist));
  const rightElbow = angleAt(g(LM.rightShoulder), g(LM.rightElbow), g(LM.rightWrist));
  const leftHip = angleAt(g(LM.leftShoulder), g(LM.leftHip), g(LM.leftKnee));
  const rightHip = angleAt(g(LM.rightShoulder), g(LM.rightHip), g(LM.rightKnee));
  const leftAbd = angleAt(g(LM.leftHip), g(LM.leftShoulder), g(LM.leftElbow));
  const rightAbd = angleAt(g(LM.rightHip), g(LM.rightShoulder), g(LM.rightElbow));

  const sh = midpoint(g(LM.leftShoulder), g(LM.rightShoulder));
  const hip = midpoint(g(LM.leftHip), g(LM.rightHip));
  const knee = midpoint(g(LM.leftKnee), g(LM.rightKnee));
  const ankle = midpoint(g(LM.leftAnkle), g(LM.rightAnkle));
  const t = torsoLength(l);

  return {
    leftKnee,
    rightKnee,
    knee: bilateral(leftKnee, rightKnee, g(LM.leftKnee).visibility, g(LM.rightKnee).visibility),
    leftElbow,
    rightElbow,
    elbow: bilateral(leftElbow, rightElbow, g(LM.leftElbow).visibility, g(LM.rightElbow).visibility),
    leftHip,
    rightHip,
    hip: bilateral(leftHip, rightHip, g(LM.leftHip).visibility, g(LM.rightHip).visibility),
    leftShoulderAbduction: leftAbd,
    rightShoulderAbduction: rightAbd,
    shoulderAbduction: bilateral(
      leftAbd,
      rightAbd,
      g(LM.leftShoulder).visibility,
      g(LM.rightShoulder).visibility,
    ),
    torsoFromVertical: angleFromVertical(hip, sh),
    kneeDrift: Math.abs(knee.x - ankle.x) / t,
    bodyLine: angleAt(sh, hip, knee),
  };
}

/** How much of the body the camera can actually see. */
export function framingQuality(l: Landmark[]): { ok: boolean; message: string | null } {
  if (l.length < 29) return { ok: false, message: "I lost track of your position. Hold still for a second." };
  const vis = (i: number) => (l[i]?.visibility ?? 0);
  const key = [LM.leftShoulder, LM.rightShoulder, LM.leftHip, LM.rightHip];
  const legs = [LM.leftKnee, LM.rightKnee, LM.leftAnkle, LM.rightAnkle];
  if (key.some((i) => vis(i) < 0.5)) {
    return { ok: false, message: "I can't see your upper body clearly. Move the camera back a little." };
  }
  if (legs.filter((i) => vis(i) > 0.4).length < 2) {
    return { ok: false, message: "Step back so I can see your full body." };
  }
  const inFrame = [...key, ...legs].every((i) => {
    const p = l[i];
    return p ? p.x > -0.05 && p.x < 1.05 && p.y > -0.05 && p.y < 1.05 : false;
  });
  if (!inFrame) return { ok: false, message: "Keep your full body inside the frame." };
  return { ok: true, message: null };
}
