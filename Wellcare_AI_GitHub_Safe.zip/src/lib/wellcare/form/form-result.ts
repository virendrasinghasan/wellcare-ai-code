/** Hand-off between the camera form coach and the active workout session. */

const KEY = "wellcare:last-form-result";

export interface FormResultHandoff {
  exerciseId: string;
  reps: number;
  score: number;
}

export function saveFormResult(result: FormResultHandoff) {
  if (typeof window === "undefined") return;
  try {
    window.sessionStorage.setItem(KEY, JSON.stringify(result));
  } catch {
    /* ignore */
  }
}

/** Reads and clears the pending result, so a score is only applied once. */
export function readLastFormResult(): FormResultHandoff | null {
  if (typeof window === "undefined") return null;
  try {
    const raw = window.sessionStorage.getItem(KEY);
    if (!raw) return null;
    window.sessionStorage.removeItem(KEY);
    return JSON.parse(raw) as FormResultHandoff;
  } catch {
    return null;
  }
}
