/**
 * PoseDetectionService - on-device pose landmark detection (MoveNet Thunder).
 *
 * Everything here runs locally in the browser through TensorFlow.js MoveNet
 * SinglePose.Thunder. No camera frame ever leaves the device: only derived
 * numbers (reps, angles, scores) are used elsewhere in the app.
 *
 * MoveNet returns 17 COCO keypoints. The rest of the app (angles, analyzers,
 * skeleton drawing) is indexed with MediaPipe Pose indices, so we remap the
 * COCO keypoints into a MediaPipe-shaped array and leave unmapped slots at
 * zero visibility.
 */
import { LM, type Landmark } from "./angles";

/** COCO keypoint name -> MediaPipe Pose landmark index. */
const NAME_TO_LM: Record<string, number> = {
  nose: LM.nose,
  left_shoulder: LM.leftShoulder,
  right_shoulder: LM.rightShoulder,
  left_elbow: LM.leftElbow,
  right_elbow: LM.rightElbow,
  left_wrist: LM.leftWrist,
  right_wrist: LM.rightWrist,
  left_hip: LM.leftHip,
  right_hip: LM.rightHip,
  left_knee: LM.leftKnee,
  right_knee: LM.rightKnee,
  left_ankle: LM.leftAnkle,
  right_ankle: LM.rightAnkle,
};

const LANDMARK_COUNT = 33;
/** Below this keypoint score the point is treated as unseen. */
export const MIN_KEYPOINT_SCORE = 0.3;

interface RawKeypoint {
  x: number;
  y: number;
  score?: number | null;
  name?: string;
}

export interface PoseFrame {
  landmarks: Landmark[];
  /** Mean score of the tracked keypoints, 0-1. */
  confidence: number;
}

/* ----------------------------- smoothing ----------------------------- */

/**
 * One Euro filter: low latency when the joint moves fast, heavy smoothing when
 * it is nearly still. This is what kills the jitter that used to produce
 * phantom reps.
 */
class OneEuro {
  private xPrev: number | null = null;
  private dxPrev = 0;
  private tPrev = 0;

  constructor(
    private minCutoff = 1.4,
    private beta = 0.012,
    private dCutoff = 1.0,
  ) {}

  private static alpha(cutoff: number, dt: number) {
    const tau = 1 / (2 * Math.PI * cutoff);
    return 1 / (1 + tau / dt);
  }

  reset() {
    this.xPrev = null;
    this.dxPrev = 0;
  }

  filter(x: number, tMs: number): number {
    if (this.xPrev === null) {
      this.xPrev = x;
      this.tPrev = tMs;
      return x;
    }
    const dt = Math.max(1, tMs - this.tPrev) / 1000;
    this.tPrev = tMs;

    const dx = (x - this.xPrev) / dt;
    const aD = OneEuro.alpha(this.dCutoff, dt);
    this.dxPrev = aD * dx + (1 - aD) * this.dxPrev;

    const cutoff = this.minCutoff + this.beta * Math.abs(this.dxPrev);
    const a = OneEuro.alpha(cutoff, dt);
    const xHat = a * x + (1 - a) * this.xPrev;
    this.xPrev = xHat;
    return xHat;
  }
}

class LandmarkSmoother {
  private fx = new Map<number, OneEuro>();
  private fy = new Map<number, OneEuro>();
  private last = new Map<number, Landmark>();

  reset() {
    this.fx.clear();
    this.fy.clear();
    this.last.clear();
  }

  apply(index: number, point: Landmark, tMs: number): Landmark {
    if (point.visibility < MIN_KEYPOINT_SCORE) {
      // Hold the last confident position briefly instead of snapping to 0,0.
      const held = this.last.get(index);
      if (held) return { ...held, visibility: Math.max(0, held.visibility * 0.6) };
      return point;
    }
    let fx = this.fx.get(index);
    let fy = this.fy.get(index);
    if (!fx || !fy) {
      fx = new OneEuro();
      fy = new OneEuro();
      this.fx.set(index, fx);
      this.fy.set(index, fy);
    }
    const smoothed: Landmark = {
      x: fx.filter(point.x, tMs),
      y: fy.filter(point.y, tMs),
      z: 0,
      visibility: point.visibility,
    };
    this.last.set(index, smoothed);
    return smoothed;
  }
}

/* ----------------------------- detector ------------------------------ */

export interface PoseEstimator {
  /** Returns null when no usable pose is present in the frame. */
  estimate(video: HTMLVideoElement, tMs: number): Promise<PoseFrame | null>;
  reset(): void;
  close(): void;
}

let estimatorPromise: Promise<PoseEstimator> | null = null;

export async function getPoseEstimator(): Promise<PoseEstimator> {
  if (!estimatorPromise) {
    estimatorPromise = (async () => {
      const [tf, poseDetection] = await Promise.all([
        import("@tensorflow/tfjs-core"),
        import("@tensorflow-models/pose-detection"),
      ]);
      await import("@tensorflow/tfjs-backend-webgl");
      await tf.setBackend("webgl").catch(() => undefined);
      await tf.ready();

      const detector = await poseDetection.createDetector(poseDetection.SupportedModels.MoveNet, {
        modelType: poseDetection.movenet.modelType.SINGLEPOSE_THUNDER,
        enableSmoothing: true,
        minPoseScore: 0.25,
      });

      const smoother = new LandmarkSmoother();

      return {
        reset() {
          smoother.reset();
        },
        close() {
          detector.dispose();
        },
        async estimate(video, tMs) {
          const w = video.videoWidth || 1;
          const h = video.videoHeight || 1;
          const poses = await detector.estimatePoses(video, { flipHorizontal: false }, tMs);
          const pose = poses?.[0];
          if (!pose || !pose.keypoints?.length) return null;

          const landmarks: Landmark[] = Array.from({ length: LANDMARK_COUNT }, () => ({
            x: 0,
            y: 0,
            z: 0,
            visibility: 0,
          }));

          let scoreSum = 0;
          let scoreCount = 0;

          (pose.keypoints as RawKeypoint[]).forEach((kp) => {
            const idx = kp.name ? NAME_TO_LM[kp.name] : undefined;
            if (idx === undefined) return;
            const score = kp.score ?? 0;
            const raw: Landmark = { x: kp.x / w, y: kp.y / h, z: 0, visibility: score };
            landmarks[idx] = smoother.apply(idx, raw, tMs);
            scoreSum += score;
            scoreCount += 1;
          });

          const confidence = scoreCount ? scoreSum / scoreCount : 0;
          if (confidence < 0.15) return null;
          return { landmarks, confidence };
        },
      } satisfies PoseEstimator;
    })().catch((err) => {
      estimatorPromise = null;
      throw err;
    });
  }
  return estimatorPromise;
}

export type CameraStatus = "idle" | "requesting" | "denied" | "unavailable" | "ready";

export async function openCamera(video: HTMLVideoElement): Promise<MediaStream> {
  const stream = await navigator.mediaDevices.getUserMedia({
    video: { facingMode: "user", width: { ideal: 1280 }, height: { ideal: 720 } },
    audio: false,
  });
  video.srcObject = stream;
  await video.play();
  return stream;
}

export function closeCamera(stream: MediaStream | null) {
  stream?.getTracks().forEach((t) => t.stop());
}
