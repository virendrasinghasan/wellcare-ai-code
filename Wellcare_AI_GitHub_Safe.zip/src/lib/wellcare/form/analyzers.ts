/**
 * ExerciseAnalysisService - exercise-specific movement rules.
 *
 * Each analyzer owns its own phase detection, rep logic and technique checks.
 * Nothing here is generic-by-default: an exercise without an analyzer gets no
 * score at all rather than a fake one.
 */
import { computeAngles, type JointAngles, type Landmark } from "./angles";
import type { AnalyzerId } from "../workout/types";

export type Phase = "ready" | "eccentric" | "bottom" | "concentric";

export interface FormIssue {
  /** Higher = more important. Only the top issue is shown to the user. */
  weight: number;
  message: string;
  component: "rom" | "control" | "alignment";
}

export interface RepRecord {
  peak: number;
  romScore: number;
  eccentricMs: number;
  alignmentScore: number;
  feedback: string;
}

export interface AnalyzerUpdate {
  reps: number;
  phase: Phase;
  /** Short, single, prioritised coaching line. */
  feedback: string | null;
  liveScore: number | null;
  holdSec?: number;
}

export interface FormBreakdown {
  score: number;
  rangeOfMotion: number;
  control: number;
  alignment: number;
  consistency: number;
  reps: number;
  notes: string[];
}

export interface Analyzer {
  id: AnalyzerId;
  setupHint: string;
  update(lms: Landmark[], nowMs: number): AnalyzerUpdate;
  summary(): FormBreakdown;
  reset(): void;
}

interface RepConfig {
  id: AnalyzerId;
  setupHint: string;
  /** Value that drives phase detection (usually a joint angle in degrees). */
  driver: (a: JointAngles, l: Landmark[]) => number;
  /** Driver value above which the user is at the top of the rep. */
  topThreshold: number;
  /** Driver value below which the rep counts as "deep enough" to have a bottom. */
  bottomThreshold: number;
  /** Driver value that earns full range-of-motion credit. */
  fullRomTarget: number;
  /** Driver direction: "down" means the value decreases through the rep. */
  checks: (a: JointAngles, l: Landmark[], phase: Phase) => FormIssue[];
  goodRep?: string;
}

const clamp = (n: number, lo = 0, hi = 100) => Math.max(lo, Math.min(hi, n));

/** Minimum time a rep must take before it is believed (kills jitter reps). */
const MIN_REP_MS = 550;
/** Hysteresis band, in driver degrees, applied around every threshold. */
const HYST = 6;

function makeRepAnalyzer(cfg: RepConfig): Analyzer {
  let phase: Phase = "ready";
  let reps = 0;
  let peak = 180;
  let eccentricStart = 0;
  let repStart = 0;
  let bottomReached = false;
  let smoothed: number | null = null;
  let velocity = 0;
  let lastValue = 0;
  let lastTs = 0;
  let lastFeedback: string | null = null;
  let lastIssueAt = 0;
  const records: RepRecord[] = [];
  let alignmentSamples: number[] = [];


  function scoreRom(peakValue: number): number {
    // Full credit at the target, zero at the top threshold.
    const span = cfg.topThreshold - cfg.fullRomTarget;
    if (span <= 0) return 100;
    return clamp(Math.round(((cfg.topThreshold - peakValue) / span) * 100));
  }

  return {
    id: cfg.id,
    setupHint: cfg.setupHint,
    reset() {
      phase = "ready";
      reps = 0;
      peak = 180;
      records.length = 0;
      alignmentSamples = [];
      lastFeedback = null;
      smoothed = null;
      velocity = 0;
      bottomReached = false;
      repStart = 0;
    },
    update(lms, nowMs) {
      const angles = computeAngles(lms);
      const rawValue = cfg.driver(angles, lms);

      // Light temporal smoothing on top of the model's own smoothing, plus a
      // velocity estimate used to confirm direction changes.
      smoothed = smoothed === null ? rawValue : smoothed + (rawValue - smoothed) * 0.45;
      const value = smoothed;
      const dt = lastTs ? Math.max(16, nowMs - lastTs) : 16;
      velocity = ((value - lastValue) / dt) * 1000; // degrees per second
      lastValue = value;
      lastTs = nowMs;

      const issues = cfg.checks(angles, lms, phase).sort((a, b) => b.weight - a.weight);
      const alignmentPenalty = issues
        .filter((i) => i.component === "alignment")
        .reduce((n, i) => n + i.weight, 0);
      alignmentSamples.push(clamp(100 - alignmentPenalty * 10));

      // --- movement phase state machine -------------------------------
      if (phase === "ready" || phase === "concentric") {
        // Needs a genuine downward move, not a wobble.
        if (value < cfg.topThreshold - 12 && velocity < -8) {
          phase = "eccentric";
          eccentricStart = nowMs;
          repStart = nowMs;
          bottomReached = false;
          peak = value;
        }
      } else if (phase === "eccentric") {
        peak = Math.min(peak, value);
        if (value <= cfg.bottomThreshold) {
          phase = "bottom";
          bottomReached = true;
        } else if (value > cfg.topThreshold - 8 && velocity > 8) {
          // came back up without reaching depth
          phase = "ready";
          lastFeedback = "Go a little deeper next rep.";
          lastIssueAt = nowMs;
        }
      } else if (phase === "bottom") {
        peak = Math.min(peak, value);
        if (value > cfg.bottomThreshold + HYST + 4 && velocity > 6) phase = "concentric";
      }

      const repComplete =
        phase === "concentric" &&
        bottomReached &&
        value >= cfg.topThreshold - HYST &&
        nowMs - repStart >= MIN_REP_MS;

      if (repComplete) {
        // rep completed
        reps += 1;
        bottomReached = false;
        const romScore = scoreRom(peak);
        const eccentricMs = Math.max(200, nowMs - eccentricStart);
        const alignmentScore = Math.round(
          alignmentSamples.reduce((n, s) => n + s, 0) / Math.max(1, alignmentSamples.length),
        );
        const worst = issues[0];
        const feedback =
          worst?.message ??
          (romScore >= 85 && alignmentScore >= 85 ? (cfg.goodRep ?? "Nice rep.") : "Good rep.");
        records.push({ peak, romScore, eccentricMs, alignmentScore, feedback });
        alignmentSamples = [];
        peak = 180;
        phase = "ready";
        lastFeedback = feedback;
        lastIssueAt = nowMs;
      } else if (issues.length && nowMs - lastIssueAt > 1800) {
        lastFeedback = issues[0]!.message;
        lastIssueAt = nowMs;
      }

      const live = records.length
        ? Math.round(
            records.reduce((n, r) => n + (r.romScore * 0.5 + r.alignmentScore * 0.5), 0) / records.length,
          )
        : null;

      return { reps, phase, feedback: lastFeedback, liveScore: live };
    },
    summary(): FormBreakdown {
      if (!records.length) {
        return {
          score: 0,
          rangeOfMotion: 0,
          control: 0,
          alignment: 0,
          consistency: 0,
          reps: 0,
          notes: ["No complete reps were detected, so there's nothing worth scoring."],
        };
      }
      const rom = Math.round(records.reduce((n, r) => n + r.romScore, 0) / records.length);
      const alignment = Math.round(records.reduce((n, r) => n + r.alignmentScore, 0) / records.length);

      // Control: reward a descent between 0.8s and 2.5s.
      const control = Math.round(
        records.reduce((n, r) => {
          const s = r.eccentricMs / 1000;
          if (s >= 0.8 && s <= 2.5) return n + 100;
          if (s < 0.8) return n + clamp(60 + (s / 0.8) * 40);
          return n + clamp(100 - (s - 2.5) * 20);
        }, 0) / records.length,
      );

      // Consistency: how similar the reps were in depth and speed.
      const romValues = records.map((r) => r.romScore);
      const mean = romValues.reduce((n, v) => n + v, 0) / romValues.length;
      const sd = Math.sqrt(romValues.reduce((n, v) => n + (v - mean) ** 2, 0) / romValues.length);
      const consistency = clamp(Math.round(100 - sd * 1.8));

      const score = Math.round(rom * 0.3 + control * 0.2 + alignment * 0.3 + consistency * 0.2);

      const notes: string[] = [];
      if (rom < 80) notes.push("Your depth was short on several reps - full range beats extra weight.");
      else notes.push("Your depth held up well across the set.");
      if (control < 75) notes.push("The lowering phase got quick. Take about two seconds down.");
      if (alignment < 80) {
        const common = records.map((r) => r.feedback).filter((f) => !f.toLowerCase().includes("rep"));
        if (common[0]) notes.push(common[0]);
      }
      if (consistency < 75) notes.push("Rep quality drifted late in the set. Stop a rep or two earlier.");

      return { score, rangeOfMotion: rom, control, alignment, consistency, reps: records.length, notes: notes.slice(0, 3) };
    },
  };
}

/* ------------------------------- SQUAT ------------------------------- */
const squat = () =>
  makeRepAnalyzer({
    id: "squat",
    setupHint: "Stand side-on or facing the camera with your whole body in frame.",
    driver: (a) => a.knee,
    topThreshold: 165,
    bottomThreshold: 100,
    fullRomTarget: 80,
    goodRep: "Good depth.",
    checks: (a, _l, phase) => {
      const out: FormIssue[] = [];
      if (a.torsoFromVertical > 45 && phase !== "ready")
        out.push({ weight: 3, message: "Keep your chest up - you're folding forward.", component: "alignment" });
      if (a.kneeDrift > 0.55)
        out.push({ weight: 2, message: "Keep your knees tracking over your toes.", component: "alignment" });
      if (phase === "bottom" && a.knee > 110)
        out.push({ weight: 2, message: "Go a little deeper.", component: "rom" });
      return out;
    },
  });

/* ------------------------------ PUSH-UP ------------------------------ */
const pushup = () =>
  makeRepAnalyzer({
    id: "pushup",
    setupHint: "Set the phone side-on, roughly at floor level, with your whole body visible.",
    driver: (a) => a.elbow,
    topThreshold: 160,
    bottomThreshold: 100,
    fullRomTarget: 85,
    goodRep: "Nice control.",
    checks: (a, _l, phase) => {
      const out: FormIssue[] = [];
      if (a.bodyLine < 160)
        out.push({ weight: 3, message: "Squeeze your glutes - your hips are sagging.", component: "alignment" });
      if (a.bodyLine > 195)
        out.push({ weight: 2, message: "Drop your hips - you're piking up.", component: "alignment" });
      if (phase === "bottom" && a.elbow > 110)
        out.push({ weight: 2, message: "Lower your chest a little further.", component: "rom" });
      return out;
    },
  });

/* ------------------------------- CURL ------------------------------- */
const curl = () =>
  makeRepAnalyzer({
    id: "curl",
    setupHint: "Stand facing the camera, arms fully visible at your sides.",
    driver: (a) => a.elbow,
    topThreshold: 155,
    bottomThreshold: 65,
    fullRomTarget: 45,
    goodRep: "Clean rep.",
    checks: (a, l) => {
      const out: FormIssue[] = [];
      const shoulderDrift = Math.abs(a.leftShoulderAbduction - 10) + Math.abs(a.rightShoulderAbduction - 10);
      if (shoulderDrift > 60)
        out.push({ weight: 3, message: "Keep your elbows pinned at your sides.", component: "alignment" });
      if (a.torsoFromVertical > 18)
        out.push({ weight: 2, message: "Stop swinging your torso.", component: "alignment" });
      void l;
      return out;
    },
  });

/* --------------------------- LATERAL RAISE --------------------------- */
const lateralRaise = () =>
  makeRepAnalyzer({
    id: "lateral_raise",
    setupHint: "Stand facing the camera with both arms in frame.",
    // Driver is inverted (arms go UP), so map abduction into a descending value.
    driver: (a) => 180 - a.shoulderAbduction,
    topThreshold: 170,
    bottomThreshold: 105,
    fullRomTarget: 95,
    goodRep: "Good height.",
    checks: (a) => {
      const out: FormIssue[] = [];
      if (a.shoulderAbduction > 110)
        out.push({ weight: 2, message: "Stop at shoulder height.", component: "rom" });
      if (a.torsoFromVertical > 15)
        out.push({ weight: 3, message: "Stop swinging - keep your torso still.", component: "alignment" });
      if (a.elbow < 130)
        out.push({ weight: 2, message: "Keep a slight, fixed elbow bend.", component: "alignment" });
      return out;
    },
  });

/* --------------------------- OVERHEAD PRESS --------------------------- */
const overheadPress = () =>
  makeRepAnalyzer({
    id: "overhead_press",
    setupHint: "Stand facing the camera, arms and hips visible.",
    driver: (a) => 200 - a.elbow,
    topThreshold: 130,
    bottomThreshold: 55,
    fullRomTarget: 35,
    goodRep: "Solid lockout.",
    checks: (a) => {
      const out: FormIssue[] = [];
      if (a.torsoFromVertical > 16)
        out.push({ weight: 3, message: "You're leaning back - brace and keep ribs down.", component: "alignment" });
      if (a.hip < 160)
        out.push({ weight: 2, message: "Squeeze your glutes to stop the back arching.", component: "alignment" });
      return out;
    },
  });

/* ------------------------------- LUNGE ------------------------------- */
const lunge = () =>
  makeRepAnalyzer({
    id: "lunge",
    setupHint: "Stand side-on to the camera with your whole body in frame.",
    driver: (a) => Math.min(a.leftKnee, a.rightKnee),
    topThreshold: 160,
    bottomThreshold: 105,
    fullRomTarget: 90,
    goodRep: "Good depth.",
    checks: (a) => {
      const out: FormIssue[] = [];
      if (a.torsoFromVertical > 30)
        out.push({ weight: 3, message: "Stay taller through the torso.", component: "alignment" });
      if (a.kneeDrift > 0.6)
        out.push({ weight: 2, message: "Keep the front knee over the foot.", component: "alignment" });
      return out;
    },
  });

/* ------------------------- HINGE (RDL / DEADLIFT) ------------------------- */
const hinge = () =>
  makeRepAnalyzer({
    id: "hinge",
    setupHint: "Stand side-on to the camera so your hips, back and knees are visible.",
    driver: (a) => a.hip,
    topThreshold: 160,
    bottomThreshold: 110,
    fullRomTarget: 95,
    goodRep: "Strong hinge.",
    checks: (a, _l, phase) => {
      const out: FormIssue[] = [];
      if (phase !== "ready" && a.knee < 130)
        out.push({ weight: 3, message: "That's turning into a squat - push the hips back instead.", component: "alignment" });
      if (a.bodyLine < 150 && phase === "bottom")
        out.push({ weight: 3, message: "Keep your back flat - chest proud.", component: "alignment" });
      return out;
    },
  });

/* ------------------------------- PLANK ------------------------------- */
function plankAnalyzer(): Analyzer {
  let start = 0;
  let samples: number[] = [];
  let last: string | null = null;
  let lastAt = 0;
  return {
    id: "plank",
    setupHint: "Place the phone side-on at floor level so your whole body is in frame.",
    reset() {
      start = 0;
      samples = [];
      last = null;
    },
    update(lms, nowMs) {
      const a = computeAngles(lms);
      const straight = a.bodyLine >= 160 && a.bodyLine <= 195;
      if (straight && !start) start = nowMs;
      samples.push(clamp(100 - Math.abs(177 - a.bodyLine) * 2.2));
      if (nowMs - lastAt > 2500) {
        if (a.bodyLine < 160) last = "Hips are sagging - squeeze your glutes.";
        else if (a.bodyLine > 195) last = "Drop your hips, you're piking up.";
        else last = "Nice, hold that line.";
        lastAt = nowMs;
      }
      const holdSec = start ? Math.round((nowMs - start) / 1000) : 0;
      return {
        reps: 0,
        phase: "ready",
        feedback: last,
        liveScore: samples.length
          ? Math.round(samples.slice(-60).reduce((n, s) => n + s, 0) / Math.min(60, samples.length))
          : null,
        holdSec,
      };
    },
    summary() {
      if (!samples.length) {
        return { score: 0, rangeOfMotion: 0, control: 0, alignment: 0, consistency: 0, reps: 0, notes: ["No hold was detected."] };
      }
      const alignment = Math.round(samples.reduce((n, s) => n + s, 0) / samples.length);
      const mean = alignment;
      const sd = Math.sqrt(samples.reduce((n, v) => n + (v - mean) ** 2, 0) / samples.length);
      const consistency = clamp(Math.round(100 - sd));
      const score = Math.round(alignment * 0.6 + consistency * 0.4);
      return {
        score,
        rangeOfMotion: alignment,
        control: consistency,
        alignment,
        consistency,
        reps: 0,
        notes: [
          alignment >= 85
            ? "Your body line stayed solid for most of the hold."
            : "Your hips drifted out of line - shorter, cleaner holds are worth more.",
        ],
      };
    },
  };
}

const FACTORIES: Record<AnalyzerId, () => Analyzer> = {
  squat,
  pushup,
  curl,
  lateral_raise: lateralRaise,
  overhead_press: overheadPress,
  lunge,
  hinge,
  plank: plankAnalyzer,
};

export function createAnalyzer(id: AnalyzerId): Analyzer {
  return FACTORIES[id]();
}
