import { QueryClient, QueryClientProvider } from "@tanstack/react-query";
import {
  Outlet,
  Link,
  createRootRouteWithContext,
  useRouter,
  useRouterState,
  useNavigate,
  HeadContent,
  Scripts,
} from "@tanstack/react-router";
import { useEffect, useState, type ReactNode } from "react";

import appCss from "../styles.css?url";
import { reportLovableError } from "../lib/lovable-error-reporting";
import { AppShell } from "@/components/wellcare/AppShell";
import { Splash } from "@/components/wellcare/Splash";
import { Toaster } from "@/components/ui/sonner";
import { WellcareProvider, useWellcare } from "@/lib/wellcare/store";


function NotFoundComponent() {
  return (
    <div className="flex min-h-screen items-center justify-center bg-background px-4">
      <div className="max-w-md text-center">
        <h1 className="text-7xl font-bold text-foreground">404</h1>
        <h2 className="mt-4 text-xl font-semibold text-foreground">Page not found</h2>
        <p className="mt-2 text-sm text-muted-foreground">
          The page you're looking for doesn't exist or has been moved.
        </p>
        <div className="mt-6">
          <Link
            to="/"
            className="inline-flex items-center justify-center rounded-md bg-primary px-4 py-2 text-sm font-medium text-primary-foreground transition-colors hover:bg-primary/90"
          >
            Go home
          </Link>
        </div>
      </div>
    </div>
  );
}

function ErrorComponent({ error, reset }: { error: Error; reset: () => void }) {
  console.error(error);
  const router = useRouter();
  useEffect(() => {
    reportLovableError(error, { boundary: "tanstack_root_error_component" });
  }, [error]);

  return (
    <div className="flex min-h-screen items-center justify-center bg-background px-4">
      <div className="max-w-md text-center">
        <h1 className="text-xl font-semibold tracking-tight text-foreground">
          This page didn't load
        </h1>
        <p className="mt-2 text-sm text-muted-foreground">
          Something went wrong on our end. You can try refreshing or head back home.
        </p>
        <div className="mt-6 flex flex-wrap justify-center gap-2">
          <button
            onClick={() => {
              router.invalidate();
              reset();
            }}
            className="inline-flex items-center justify-center rounded-md bg-primary px-4 py-2 text-sm font-medium text-primary-foreground transition-colors hover:bg-primary/90"
          >
            Try again
          </button>
          <a
            href="/"
            className="inline-flex items-center justify-center rounded-md border border-input bg-background px-4 py-2 text-sm font-medium text-foreground transition-colors hover:bg-accent"
          >
            Go home
          </a>
        </div>
      </div>
    </div>
  );
}

export const Route = createRootRouteWithContext<{ queryClient: QueryClient }>()({
  head: () => ({
    meta: [
      { charSet: "utf-8" },
      {
        name: "viewport",
        content: "width=device-width, initial-scale=1, viewport-fit=cover",
      },
      { title: "Wellcare AI - Your health companion" },
      {
        name: "description",
        content:
          "Wellcare AI is a mobile health companion for nutrition tracking, personalized workouts, progress and an AI coach that tells it straight.",
      },
      { name: "author", content: "Wellcare AI" },
      { property: "og:title", content: "Wellcare AI - Your health companion" },
      {
        property: "og:description",
        content:
          "Nutrition tracking, personalized workouts, progress and an AI coach that tells it straight.",
      },
      { property: "og:type", content: "website" },
      { name: "twitter:card", content: "summary_large_image" },
      { name: "twitter:site", content: "@Lovable" },
      // Follows the device appearance setting, same as the CSS palette.
      { name: "theme-color", content: "#f8f7fb", media: "(prefers-color-scheme: light)" },
      { name: "theme-color", content: "#17161f", media: "(prefers-color-scheme: dark)" },

      { name: "mobile-web-app-capable", content: "yes" },
      { name: "apple-mobile-web-app-capable", content: "yes" },
      { name: "apple-mobile-web-app-title", content: "Wellcare" },
    ],
    links: [
      {
        rel: "stylesheet",
        href: appCss,
      },
      { rel: "icon", href: "/favicon.svg", type: "image/svg+xml" },
      { rel: "manifest", href: "/manifest.webmanifest" },
      { rel: "apple-touch-icon", href: "/icon-180.png" },
      { rel: "preconnect", href: "https://fonts.googleapis.com" },
      { rel: "preconnect", href: "https://fonts.gstatic.com", crossOrigin: "anonymous" },
      {
        rel: "stylesheet",
        href: "https://fonts.googleapis.com/css2?family=Manrope:wght@400;500;600;700;800&display=swap",
      },
    ],
  }),
  shellComponent: RootShell,
  component: RootComponent,
  notFoundComponent: NotFoundComponent,
  errorComponent: ErrorComponent,
});

function RootShell({ children }: { children: ReactNode }) {
  return (
    <html lang="en">
      <head>
        <HeadContent />
      </head>
      <body>
        {children}
        <Scripts />
      </body>
    </html>
  );
}

const SPLASH_MS = 1150;

/** Splash → (welcome/onboarding when not set up) → app. */
function BootGate({ children }: { children: ReactNode }) {
  const { hydrated, profile } = useWellcare();
  const pathname = useRouterState({ select: (s) => s.location.pathname });
  const navigate = useNavigate();
  const [splashDone, setSplashDone] = useState(false);
  const [exiting, setExiting] = useState(false);

  useEffect(() => {
    if (window.sessionStorage.getItem("wellcare:splash") === "seen") {
      setSplashDone(true);
      return;
    }
    const fade = window.setTimeout(() => setExiting(true), SPLASH_MS - 250);
    const t = window.setTimeout(() => {
      window.sessionStorage.setItem("wellcare:splash", "seen");
      setSplashDone(true);
    }, SPLASH_MS);
    return () => {
      window.clearTimeout(fade);
      window.clearTimeout(t);
    };
  }, []);

  const inSetup = pathname.startsWith("/welcome") || pathname.startsWith("/onboarding");

  useEffect(() => {
    if (!hydrated || !splashDone) return;
    if (!profile.onboardingCompleted && !inSetup) {
      void navigate({ to: "/welcome", replace: true });
    }
  }, [hydrated, splashDone, profile.onboardingCompleted, inSetup, navigate]);

  if (!hydrated || !splashDone) return <Splash exiting={exiting && hydrated} />;
  return <>{children}</>;
}


function RootComponent() {
  const { queryClient } = Route.useRouteContext();

  return (
    <QueryClientProvider client={queryClient}>
      <WellcareProvider>
        <BootGate>
          {/* Required: nested routes render here. Removing <Outlet /> breaks all child routes. */}
          <AppShell>
            <Outlet />
          </AppShell>
        </BootGate>
        <Toaster position="top-center" />

      </WellcareProvider>
    </QueryClientProvider>
  );
}
