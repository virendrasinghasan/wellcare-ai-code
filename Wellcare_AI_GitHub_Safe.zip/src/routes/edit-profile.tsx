import { createFileRoute, useNavigate } from "@tanstack/react-router";
import { useState } from "react";
import { ArrowLeft } from "lucide-react";
import {
  Field,
  OptionRow,
  PrimaryButton,
  SegmentedControl,
  inputClass,
} from "@/components/wellcare/onboarding-ui";
import { SurfaceCard, SectionHeader } from "@/components/wellcare/Card";
import { useWellcare } from "@/lib/wellcare/store";
import { calculateTdee, kgToLb, lbToKg, resolveAgeYears, waterTargetMl } from "@/lib/wellcare/tdee";
import type { ActivityLevel, PrimaryGoal, Sex, WellcareProfile } from "@/lib/wellcare/types";

export const Route = createFileRoute("/edit-profile")({
  head: () => ({
    meta: [
      { title: "Edit your details - Wellcare AI" },
      {
        name: "description",
        content:
          "Update your weight, goal, activity level and training frequency - targets recalculate instantly.",
      },
      { property: "og:title", content: "Edit your details - Wellcare AI" },
      {
        property: "og:description",
        content: "Update your numbers and Wellcare recalculates your calorie and macro targets.",
      },
    ],
  }),
  component: EditProfileScreen,
});

const GOALS: { value: PrimaryGoal; label: string }[] = [
  { value: "lose_weight", label: "Lose weight" },
  { value: "gain_muscle", label: "Gain muscle" },
  { value: "maintain_weight", label: "Maintain weight" },
  { value: "build_strength", label: "Build strength" },
  { value: "improve_fitness", label: "Improve fitness" },
  { value: "improve_health", label: "Improve overall health" },
];

const ACTIVITY: { value: ActivityLevel; label: string }[] = [
  { value: "sedentary", label: "Sedentary" },
  { value: "light", label: "Lightly active" },
  { value: "moderate", label: "Moderately active" },
  { value: "active", label: "Very active" },
  { value: "very_active", label: "Extremely active" },
];

function EditProfileScreen() {
  const navigate = useNavigate();
  const { profile, completeOnboarding } = useWellcare();
  const [draft, setDraft] = useState<WellcareProfile>(profile);
  const set = (patch: Partial<WellcareProfile>) => setDraft((d) => ({ ...d, ...patch }));

  const age = resolveAgeYears(draft);
  const canSave = Boolean(age && draft.heightCm && draft.weightKg && draft.goal && draft.activityLevel);

  const preview =
    canSave && draft.goal && draft.activityLevel
      ? calculateTdee(
          {
            sex: draft.sex ?? "other",
            ageYears: age as number,
            heightCm: draft.heightCm as number,
            weightKg: draft.weightKg as number,
            bodyFatPct: draft.bodyFatPct,
            activityLevel: draft.activityLevel,
          },
          draft.goal,
        )
      : null;

  async function save() {
    if (!preview) return;
    await completeOnboarding({
      ...draft,
      tdeeEstimate: preview.estimate,
      tdeeMethod: preview.method,
      targets: preview.macros,
      waterTargetMl: draft.weightKg ? waterTargetMl(draft.weightKg) : draft.waterTargetMl,
    });
    void navigate({ to: "/profile", replace: true });
  }

  return (
    <div className="space-y-7 px-5 pb-6 pt-[max(env(safe-area-inset-top),1.25rem)]">
      <header className="pt-3">
        <button
          type="button"
          onClick={() => navigate({ to: "/profile" })}
          aria-label="Back"
          className="flex h-10 w-10 items-center justify-center rounded-full bg-muted"
        >
          <ArrowLeft className="h-5 w-5" />
        </button>
        <h1 className="mt-5 text-[26px] font-extrabold tracking-[-0.035em]">Edit your details</h1>
        <p className="mt-2 text-[14px] leading-relaxed text-muted-foreground">
          Change anything here and your calories and macros are recalculated on save.
        </p>
      </header>

      <div className="space-y-5">
        <Field label="First name">
          <input
            value={draft.firstName}
            onChange={(e) => set({ firstName: e.target.value })}
            className={inputClass}
            placeholder="Your name"
          />
        </Field>

        <Field label="Gender">
          <div className="grid grid-cols-3 gap-2">
            {(["male", "female", "other"] as Sex[]).map((s) => (
              <button
                key={s}
                type="button"
                onClick={() => set({ sex: s })}
                className={`h-13 rounded-[1.15rem] border py-3.5 text-[14px] font-bold capitalize transition-colors ${
                  draft.sex === s
                    ? "border-primary bg-primary-soft text-accent-foreground"
                    : "border-border/70 bg-card text-muted-foreground"
                }`}
              >
                {s}
              </button>
            ))}
          </div>
        </Field>

        <div>
          <div className="mb-2 flex items-center justify-between">
            <span className="text-[13px] font-bold tracking-tight">Age</span>
            <SegmentedControl
              value={draft.ageMode}
              onChange={(v) => set({ ageMode: v })}
              options={[
                { value: "age", label: "Age" },
                { value: "birth_year", label: "Birth year" },
              ]}
            />
          </div>
          {draft.ageMode === "age" ? (
            <input
              type="number"
              inputMode="numeric"
              value={draft.ageYears ?? ""}
              onChange={(e) => set({ ageYears: e.target.value ? Number(e.target.value) : null })}
              className={inputClass}
              placeholder="29"
            />
          ) : (
            <input
              type="number"
              inputMode="numeric"
              value={draft.birthYear ?? ""}
              onChange={(e) => set({ birthYear: e.target.value ? Number(e.target.value) : null })}
              className={inputClass}
              placeholder={String(new Date().getFullYear() - 29)}
            />
          )}
        </div>

        <Field label="Height (cm)">
          <input
            type="number"
            inputMode="decimal"
            value={draft.heightCm ?? ""}
            onChange={(e) => set({ heightCm: e.target.value ? Number(e.target.value) : null })}
            className={inputClass}
            placeholder="175"
          />
        </Field>

        <div>
          <div className="mb-2 flex items-center justify-between">
            <span className="text-[13px] font-bold tracking-tight">Weight</span>
            <SegmentedControl
              value={draft.weightUnit}
              onChange={(v) => set({ weightUnit: v })}
              options={[
                { value: "kg", label: "kg" },
                { value: "lb", label: "lb" },
              ]}
            />
          </div>
          <input
            type="number"
            inputMode="decimal"
            value={
              draft.weightKg == null
                ? ""
                : draft.weightUnit === "kg"
                  ? Math.round(draft.weightKg * 10) / 10
                  : Math.round(kgToLb(draft.weightKg))
            }
            onChange={(e) => {
              const v = e.target.value ? Number(e.target.value) : null;
              set({ weightKg: v == null ? null : draft.weightUnit === "kg" ? v : lbToKg(v) });
            }}
            className={inputClass}
            placeholder={draft.weightUnit === "kg" ? "72" : "160"}
          />
        </div>

        <Field label="Body fat % (optional)">
          <input
            type="number"
            inputMode="decimal"
            value={draft.bodyFatPct ?? ""}
            onChange={(e) => set({ bodyFatPct: e.target.value ? Number(e.target.value) : null })}
            className={inputClass}
            placeholder="e.g. 18"
          />
        </Field>

        <Field label="Training days per week">
          <input
            type="number"
            inputMode="numeric"
            min={0}
            max={7}
            value={draft.daysPerWeek ?? ""}
            onChange={(e) => set({ daysPerWeek: e.target.value ? Number(e.target.value) : null })}
            className={inputClass}
            placeholder="4"
          />
        </Field>
      </div>

      <div>
        <SectionHeader title="Primary goal" />
        <div className="space-y-2">
          {GOALS.map((g) => (
            <OptionRow
              key={g.value}
              label={g.label}
              selected={draft.goal === g.value}
              onClick={() => set({ goal: g.value })}
            />
          ))}
        </div>
      </div>

      <div>
        <SectionHeader title="Activity level" />
        <div className="space-y-2">
          {ACTIVITY.map((a) => (
            <OptionRow
              key={a.value}
              label={a.label}
              selected={draft.activityLevel === a.value}
              onClick={() => set({ activityLevel: a.value })}
            />
          ))}
        </div>
      </div>

      {preview && (
        <SurfaceCard>
          <p className="text-[12px] font-bold uppercase tracking-[0.08em] text-muted-foreground">
            New targets
          </p>
          <p className="mt-2 text-[28px] leading-none text-metric">
            {preview.macros.calories.toLocaleString()}
            <span className="ml-1 text-[14px] font-bold text-muted-foreground">kcal / day</span>
          </p>
          <p className="mt-2 text-[13.5px] text-muted-foreground">
            {preview.macros.protein}g protein · {preview.macros.carbs}g carbs · {preview.macros.fat}g
            fat
          </p>
        </SurfaceCard>
      )}

      <PrimaryButton disabled={!canSave} onClick={save}>
        Save and recalculate
      </PrimaryButton>
    </div>
  );
}
