import { createFileRoute, Link, useNavigate } from "@tanstack/react-router";
import { Camera, ChevronLeft, ImagePlus, Loader2, Sparkles, Trash2 } from "lucide-react";
import { useCallback, useEffect, useRef, useState } from "react";
import { SurfaceCard } from "@/components/wellcare/Card";
import { PrimaryButton } from "@/components/wellcare/onboarding-ui";
import { useWellcare } from "@/lib/wellcare/store";
import { analyseMeal, type MealVisionItem } from "@/lib/wellcare/food/meal-vision.functions";
import type { MealType } from "@/lib/wellcare/types";

export const Route = createFileRoute("/scan-meal")({
  head: () => ({
    meta: [
      { title: "Scan a meal - Wellcare AI" },
      {
        name: "description",
        content: "Point your camera at a plate and let Wellcare AI estimate the calories and macros.",
      },
      { property: "og:title", content: "Scan a meal - Wellcare AI" },
      { property: "og:description", content: "Photo-based meal logging in Wellcare AI." },
      { property: "og:type", content: "website" },
      { name: "twitter:card", content: "summary_large_image" },
    ],
  }),
  component: ScanMealScreen,
});

type Stage = "camera" | "preview" | "analysing" | "results" | "error";

const MEALS: MealType[] = ["breakfast", "lunch", "dinner", "snack"];

function defaultMeal(hour: number): MealType {
  if (hour < 11) return "breakfast";
  if (hour < 16) return "lunch";
  if (hour < 21) return "dinner";
  return "snack";
}

const r1 = (n: number) => Math.round(n * 10) / 10;

/** Downscale to keep the upload small and the model fast. */
async function toCompressedBase64(source: Blob | HTMLVideoElement): Promise<string> {
  const bitmap =
    source instanceof Blob
      ? await createImageBitmap(source)
      : await createImageBitmap(
          await new Promise<Blob>((resolve) => {
            const c = document.createElement("canvas");
            c.width = source.videoWidth;
            c.height = source.videoHeight;
            c.getContext("2d")?.drawImage(source, 0, 0);
            c.toBlob((b) => resolve(b ?? new Blob()), "image/jpeg", 0.9);
          }),
        );

  const maxSide = 1024;
  const scale = Math.min(1, maxSide / Math.max(bitmap.width, bitmap.height));
  const canvas = document.createElement("canvas");
  canvas.width = Math.round(bitmap.width * scale);
  canvas.height = Math.round(bitmap.height * scale);
  canvas.getContext("2d")?.drawImage(bitmap, 0, 0, canvas.width, canvas.height);
  bitmap.close?.();
  return canvas.toDataURL("image/jpeg", 0.82);
}

function ScanMealScreen() {
  const navigate = useNavigate();
  const { addEntry } = useWellcare();
  const videoRef = useRef<HTMLVideoElement | null>(null);
  const streamRef = useRef<MediaStream | null>(null);
  const fileRef = useRef<HTMLInputElement | null>(null);

  const [stage, setStage] = useState<Stage>("camera");
  const [cameraOn, setCameraOn] = useState(false);
  const [photo, setPhoto] = useState<string | null>(null);
  const [items, setItems] = useState<MealVisionItem[]>([]);
  const [title, setTitle] = useState("Your meal");
  const [verdict, setVerdict] = useState("");
  const [message, setMessage] = useState<string | null>(null);
  const [meal, setMeal] = useState<MealType>(defaultMeal(new Date().getHours()));

  const stopCamera = useCallback(() => {
    streamRef.current?.getTracks().forEach((t) => t.stop());
    streamRef.current = null;
    setCameraOn(false);
  }, []);

  useEffect(() => stopCamera, [stopCamera]);

  const startCamera = useCallback(async () => {
    const video = videoRef.current;
    if (!video) return;
    try {
      const { openRearCamera, tuneForCloseUp } = await import("@/lib/wellcare/camera");
      const stream = await openRearCamera(video);
      streamRef.current = stream;
      await tuneForCloseUp(stream);
      setCameraOn(true);
      setMessage(null);
    } catch {
      setMessage("I can't get to the camera. Allow access, or pick a photo from your library.");
    }
  }, []);


  const analyse = useCallback(async (dataUrl: string) => {
    setPhoto(dataUrl);
    setStage("analysing");
    const base64 = dataUrl.split(",")[1] ?? "";
    try {
      const result = await analyseMeal({ data: { imageBase64: base64, mimeType: "image/jpeg" } });
      if (!result.ok) {
        setMessage(result.message);
        setStage("error");
        return;
      }
      setTitle(result.title);
      setItems(result.items);
      setVerdict(result.verdict);
      setStage("results");
    } catch {
      setMessage("Something went wrong on my side. Try again, or log it by hand.");
      setStage("error");
    }
  }, []);

  const capture = useCallback(async () => {
    const video = videoRef.current;
    if (!video || !cameraOn) return;
    const dataUrl = await toCompressedBase64(video);
    stopCamera();
    void analyse(dataUrl);
  }, [analyse, cameraOn, stopCamera]);

  const pickFile = useCallback(
    async (file: File | undefined) => {
      if (!file) return;
      stopCamera();
      const dataUrl = await toCompressedBase64(file);
      void analyse(dataUrl);
    },
    [analyse, stopCamera],
  );

  const totals = items.reduce(
    (acc, it) => ({
      calories: acc.calories + it.calories,
      protein: acc.protein + it.protein,
      carbs: acc.carbs + it.carbs,
      fat: acc.fat + it.fat,
    }),
    { calories: 0, protein: 0, carbs: 0, fat: 0 },
  );

  function reset() {
    setStage("camera");
    setPhoto(null);
    setItems([]);
    setVerdict("");
    setMessage(null);
  }

  function logAll() {
    items.forEach((it) =>
      addEntry({
        meal,
        name: it.name,
        calories: Math.round(it.calories),
        protein: Math.round(it.protein),
        carbs: Math.round(it.carbs),
        fat: Math.round(it.fat),
      }),
    );
    void navigate({ to: "/" });
  }

  return (
    <div className="space-y-5 px-5 pt-[max(env(safe-area-inset-top),1.25rem)]">
      <button
        type="button"
        onClick={() => {
          stopCamera();
          void navigate({ to: "/" });
        }}
        className="flex h-11 w-11 items-center justify-center rounded-full bg-muted"
        aria-label="Back"
      >
        <ChevronLeft className="h-5 w-5" />
      </button>

      <header>
        <h1 className="text-[26px] font-extrabold tracking-[-0.03em]">Scan a meal</h1>
        <p className="mt-2 text-[14px] text-muted-foreground">
          Photo in, macros out. Estimates, not lab results - edit anything that looks off.
        </p>
      </header>

      <input
        ref={fileRef}
        type="file"
        accept="image/*"
        className="hidden"
        onChange={(e) => void pickFile(e.target.files?.[0])}
      />

      {stage === "results" ? (
        <SurfaceCard className="space-y-4">
          <div className="flex gap-3">
            {photo && (
              <img
                src={photo}
                alt="The meal you photographed"
                className="h-16 w-16 shrink-0 rounded-[1rem] object-cover"
              />
            )}
            <div className="min-w-0">
              <p className="text-[16px] font-bold leading-tight tracking-tight">{title}</p>
              <p className="mt-0.5 text-[12.5px] text-muted-foreground">
                {items.length} item{items.length === 1 ? "" : "s"} · {Math.round(totals.calories)} kcal
              </p>
            </div>
          </div>

          {verdict && (
            <div className="flex gap-2 rounded-[1.25rem] bg-primary-soft/70 p-3">
              <Sparkles className="mt-0.5 h-4 w-4 shrink-0 text-accent-foreground" />
              <p className="text-[13px] leading-relaxed">{verdict}</p>
            </div>
          )}

          <ul className="space-y-2">
            {items.map((it, i) => (
              <li
                key={`${it.name}-${i}`}
                className="flex items-center gap-3 rounded-[1.25rem] bg-muted/70 px-3 py-2.5"
              >
                <div className="min-w-0 flex-1">
                  <p className="truncate text-[14px] font-semibold">{it.name}</p>
                  <p className="text-[12px] text-muted-foreground">
                    {it.portion} · {Math.round(it.calories)} kcal · P {r1(it.protein)} / C{" "}
                    {r1(it.carbs)} / F {r1(it.fat)}
                  </p>
                </div>
                <button
                  type="button"
                  onClick={() => setItems((prev) => prev.filter((_, idx) => idx !== i))}
                  className="flex h-9 w-9 items-center justify-center rounded-full text-muted-foreground"
                  aria-label={`Remove ${it.name}`}
                >
                  <Trash2 className="h-4 w-4" />
                </button>
              </li>
            ))}
          </ul>

          <div className="grid grid-cols-4 gap-2 text-center">
            {[
              ["kcal", Math.round(totals.calories)],
              ["protein", `${r1(totals.protein)}g`],
              ["carbs", `${r1(totals.carbs)}g`],
              ["fat", `${r1(totals.fat)}g`],
            ].map(([label, value]) => (
              <div key={String(label)} className="rounded-[1.1rem] bg-muted/70 px-2 py-2.5">
                <p className="text-metric text-[16px]">{value}</p>
                <p className="text-[11px] text-muted-foreground">{label}</p>
              </div>
            ))}
          </div>

          <div>
            <p className="mb-2 text-[12.5px] font-semibold text-muted-foreground">Meal</p>
            <div className="flex gap-2">
              {MEALS.map((m) => (
                <button
                  key={m}
                  type="button"
                  onClick={() => setMeal(m)}
                  className={`h-10 flex-1 rounded-full text-[13px] font-semibold capitalize ${
                    meal === m ? "bg-primary text-primary-foreground" : "bg-muted"
                  }`}
                >
                  {m}
                </button>
              ))}
            </div>
          </div>

          <PrimaryButton onClick={logAll} disabled={items.length === 0}>
            Log {items.length === 1 ? "it" : "them"}
          </PrimaryButton>
          <button
            type="button"
            onClick={reset}
            className="w-full text-[13.5px] font-semibold text-muted-foreground"
          >
            Take another photo
          </button>
        </SurfaceCard>
      ) : (
        <div className="relative aspect-[4/5] w-full overflow-hidden rounded-[1.75rem] border border-border bg-muted/60">
          <video ref={videoRef} playsInline muted className="h-full w-full object-cover" />

          {photo && stage !== "camera" && (
            <img src={photo} alt="Captured meal" className="absolute inset-0 h-full w-full object-cover" />
          )}

          {stage === "analysing" && (
            <div className="absolute inset-0 flex flex-col items-center justify-center gap-3 bg-foreground/55 px-8 text-center">
              <Loader2 className="h-7 w-7 animate-spin text-background" />
              <p className="text-[13px] font-semibold text-background">Reading your plate…</p>
            </div>
          )}

          {(stage === "camera" || stage === "error") && !cameraOn && (
            <div className="absolute inset-0 flex flex-col items-center justify-center gap-3 bg-muted/85 px-8 text-center">
              <Camera className="h-10 w-10 text-muted-foreground" strokeWidth={1.5} />
              <p className="text-[13px] text-muted-foreground">
                {message ?? "Get the whole plate in frame, decent light, straight on."}
              </p>
              <div className="flex flex-wrap justify-center gap-2">
                <button
                  type="button"
                  onClick={() => void startCamera()}
                  className="h-11 rounded-full bg-primary px-6 text-[14px] font-bold text-primary-foreground"
                >
                  Open camera
                </button>
                <button
                  type="button"
                  onClick={() => fileRef.current?.click()}
                  className="flex h-11 items-center gap-2 rounded-full bg-muted px-5 text-[14px] font-bold"
                >
                  <ImagePlus className="h-4 w-4" /> Choose photo
                </button>
              </div>
            </div>
          )}

          {cameraOn && stage === "camera" && (
            <button
              type="button"
              onClick={() => void capture()}
              className="absolute bottom-5 left-1/2 h-16 w-16 -translate-x-1/2 rounded-full border-4 border-background bg-primary shadow-[var(--shadow-float)]"
              aria-label="Take photo"
            />
          )}
        </div>
      )}

      {stage !== "results" && (
        <>
          <SurfaceCard className="border-primary/25 bg-primary-soft/70">
            <div className="flex gap-3">
              <Sparkles className="mt-0.5 h-5 w-5 shrink-0 text-accent-foreground" />
              <p className="text-[13px] leading-relaxed">
                Photos are analysed and thrown away. Nothing is stored, and the numbers are estimates
                you can edit before logging.
              </p>
            </div>
          </SurfaceCard>

          <Link to="/add-food">
            <PrimaryButton>Add food manually</PrimaryButton>
          </Link>
        </>
      )}
    </div>
  );
}
