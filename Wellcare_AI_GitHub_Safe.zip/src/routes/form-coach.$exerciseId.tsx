import { createFileRoute, Link, useNavigate } from "@tanstack/react-router";
import { useCallback, useEffect, useRef, useState } from "react";
import { ChevronLeft, Play, Square, Camera, Sparkles, Loader2 } from "lucide-react";
import { getExercise } from "@/lib/wellcare/workout/library";
import { framingQuality, SKELETON, TRACKED_POINTS, type Landmark } from "@/lib/wellcare/form/angles";
import { closeCamera, getPoseEstimator, openCamera } from "@/lib/wellcare/form/pose";
import { createAnalyzer, type Analyzer, type FormBreakdown } from "@/lib/wellcare/form/analyzers";
import { saveFormResult } from "@/lib/wellcare/form/form-result";
import { reviewSet } from "@/lib/wellcare/form/form-coach.functions";

export const Route = createFileRoute("/form-coach/$exerciseId")({
  head: ({ params }) => {
    const ex = getExercise(params.exerciseId);
    const title = ex ? `${ex.name} form coach - Wellcare AI` : "AI form coach - Wellcare AI";
    return {
      meta: [
        { title },
        {
          name: "description",
          content:
            "Real-time on-device form coaching: body landmark tracking, joint angles, rep counting and a technique score.",
        },
        { property: "og:title", content: title },
        {
          property: "og:description",
          content: "On-device pose tracking with live cues and a post-set technique score.",
        },
      ],
    };
  },
  component: FormCoachScreen,
});

type Stage = "setup" | "requesting" | "denied" | "unsupported" | "live" | "result";

function FormCoachScreen() {
  const { exerciseId } = Route.useParams();
  const navigate = useNavigate();
  const exercise = getExercise(exerciseId);

  const videoRef = useRef<HTMLVideoElement | null>(null);
  const canvasRef = useRef<HTMLCanvasElement | null>(null);
  const streamRef = useRef<MediaStream | null>(null);
  const analyzerRef = useRef<Analyzer | null>(null);
  const rafRef = useRef<number | null>(null);
  const runningRef = useRef(false);

  const [stage, setStage] = useState<Stage>("setup");
  const [reps, setReps] = useState(0);
  const [feedback, setFeedback] = useState<string | null>(null);
  const [liveScore, setLiveScore] = useState<number | null>(null);
  const [holdSec, setHoldSec] = useState(0);
  const [breakdown, setBreakdown] = useState<FormBreakdown | null>(null);
  const [aiReview, setAiReview] = useState<string | null>(null);
  const [aiLoading, setAiLoading] = useState(false);

  const stopEverything = useCallback(() => {
    runningRef.current = false;
    if (rafRef.current) cancelAnimationFrame(rafRef.current);
    closeCamera(streamRef.current);
    streamRef.current = null;
  }, []);

  useEffect(() => stopEverything, [stopEverything]);

  const draw = useCallback((lms: Landmark[] | null) => {
    const canvas = canvasRef.current;
    const video = videoRef.current;
    if (!canvas || !video) return;
    const w = video.videoWidth || canvas.width;
    const h = video.videoHeight || canvas.height;
    if (canvas.width !== w || canvas.height !== h) {
      canvas.width = w;
      canvas.height = h;
    }
    const ctx = canvas.getContext("2d");
    if (!ctx) return;
    ctx.clearRect(0, 0, w, h);
    if (!lms) return;

    ctx.strokeStyle = "rgba(255,255,255,0.85)";
    ctx.lineWidth = Math.max(3, w / 260);
    ctx.lineCap = "round";
    SKELETON.forEach(([a, b]) => {
      const p1 = lms[a];
      const p2 = lms[b];
      if (!p1 || !p2 || p1.visibility < 0.4 || p2.visibility < 0.4) return;
      ctx.beginPath();
      ctx.moveTo(p1.x * w, p1.y * h);
      ctx.lineTo(p2.x * w, p2.y * h);
      ctx.stroke();
    });

    ctx.fillStyle = "#f97316";
    TRACKED_POINTS.forEach((i) => {
      const p = lms[i];
      if (!p || p.visibility < 0.4) return;
      ctx.beginPath();
      ctx.arc(p.x * w, p.y * h, Math.max(4, w / 220), 0, Math.PI * 2);
      ctx.fill();
    });
  }, []);

  const start = useCallback(async () => {
    if (!exercise?.analyzer) return;
    setStage("requesting");
    setAiReview(null);
    setBreakdown(null);
    setReps(0);
    setLiveScore(null);
    try {
      const estimator = await getPoseEstimator();
      estimator.reset();
      const video = videoRef.current;
      if (!video) return;
      streamRef.current = await openCamera(video);
      analyzerRef.current = createAnalyzer(exercise.analyzer);
      analyzerRef.current.reset();
      setStage("live");
      runningRef.current = true;

      let busy = false;
      let missedFrames = 0;
      const loop = () => {
        if (!runningRef.current || !videoRef.current) return;
        const v = videoRef.current;
        const ts = performance.now();
        if (v.readyState >= 2 && !busy) {
          busy = true;
          estimator
            .estimate(v, ts)
            .then((frame) => {
              if (!runningRef.current) return;
              if (!frame) {
                missedFrames += 1;
                draw(null);
                if (missedFrames > 8) setFeedback("I can't see you. Step into the frame.");
                return;
              }
              missedFrames = 0;
              const lms = frame.landmarks;
              draw(lms);
              const framing = framingQuality(lms);
              if (!framing.ok) {
                setFeedback(framing.message);
                return;
              }
              if (frame.confidence < 0.35) {
                setFeedback("Tracking is shaky - more light or a plainer background helps.");
                return;
              }
              const update = analyzerRef.current!.update(lms, ts);
              setReps(update.reps);
              setFeedback(update.feedback);
              setLiveScore(update.liveScore);
              if (typeof update.holdSec === "number") setHoldSec(update.holdSec);
            })
            .catch(() => {
              /* skip this frame */
            })
            .finally(() => {
              busy = false;
            });
        }
        rafRef.current = requestAnimationFrame(loop);
      };
      rafRef.current = requestAnimationFrame(loop);
    } catch (err) {
      stopEverything();
      const name = (err as { name?: string })?.name;
      setStage(name === "NotAllowedError" || name === "SecurityError" ? "denied" : "unsupported");
    }
  }, [exercise, draw, stopEverything]);

  const finish = useCallback(async () => {
    const analyzer = analyzerRef.current;
    stopEverything();
    if (!analyzer || !exercise) {
      setStage("setup");
      return;
    }
    const summary = analyzer.summary();
    setBreakdown(summary);
    setStage("result");
    if (summary.reps > 0 || summary.score > 0) {
      saveFormResult({ exerciseId: exercise.id, reps: summary.reps, score: summary.score });
    }
    if (summary.score === 0) return;

    setAiLoading(true);
    try {
      const result = await reviewSet({
        data: {
          exercise: exercise.name,
          reps: summary.reps,
          score: summary.score,
          rangeOfMotion: summary.rangeOfMotion,
          control: summary.control,
          alignment: summary.alignment,
          consistency: summary.consistency,
          notes: summary.notes,
        },
      });
      setAiReview(result.ok ? result.reply : result.message);
    } catch {
      setAiReview("I couldn't reach the coach right now. The score above still stands.");
    } finally {
      setAiLoading(false);
    }
  }, [exercise, stopEverything]);

  if (!exercise) {
    return (
      <div className="flex min-h-screen flex-col items-center justify-center gap-4 px-8 text-center">
        <p className="text-[15px] font-bold">That exercise doesn't exist.</p>
        <Link to="/exercises" className="text-[14px] text-accent-foreground">
          Back to the library
        </Link>
      </div>
    );
  }

  if (!exercise.analyzer) {
    return (
      <div className="flex min-h-screen flex-col items-center justify-center gap-4 px-8 text-center">
        <Camera className="h-8 w-8 text-muted-foreground" strokeWidth={1.6} />
        <p className="max-w-[18rem] text-[14px] leading-relaxed text-muted-foreground">
          There's no camera analyzer for {exercise.name} yet, and I'm not going to fake a score.
        </p>
        <Link
          to="/exercise/$id"
          params={{ id: exercise.id }}
          className="text-[14px] font-bold text-accent-foreground"
        >
          Back to the exercise
        </Link>
      </div>
    );
  }

  const live = stage === "live";

  return (
    <div className="relative min-h-screen bg-black text-white">
      <video
        ref={videoRef}
        playsInline
        muted
        className="absolute inset-0 h-full w-full scale-x-[-1] object-cover"
      />
      <canvas ref={canvasRef} className="absolute inset-0 h-full w-full scale-x-[-1] object-cover" />

      <div className="absolute inset-x-0 top-0 z-10 flex items-center justify-between gap-3 px-5 pt-[max(env(safe-area-inset-top),1rem)]">
        <button
          type="button"
          onClick={() => {
            stopEverything();
            navigate({ to: "/exercise/$id", params: { id: exercise.id } });
          }}
          className="flex h-10 w-10 items-center justify-center rounded-full bg-black/45 backdrop-blur"
          aria-label="Back"
        >
          <ChevronLeft className="h-5 w-5" />
        </button>
        <p className="truncate text-[14.5px] font-bold tracking-tight">{exercise.name}</p>
        <span className="h-10 w-10" />
      </div>

      {live && (
        <>
          <div className="absolute left-1/2 top-[22%] z-10 -translate-x-1/2 text-center">
            <p className="text-[64px] font-extrabold leading-none tabular-nums drop-shadow">
              {exercise.analyzer === "plank" ? `${holdSec}s` : reps}
            </p>
            <p className="mt-1 text-[12px] font-bold uppercase tracking-[0.12em] text-white/70">
              {exercise.analyzer === "plank" ? "hold" : "reps"}
              {liveScore != null ? ` · form ${liveScore}` : ""}
            </p>
          </div>
          {feedback && (
            <div className="absolute inset-x-5 bottom-[8.5rem] z-10 rounded-[1.35rem] bg-black/60 px-5 py-3.5 text-center backdrop-blur">
              <p className="text-[15px] font-bold leading-snug">{feedback}</p>
            </div>
          )}
        </>
      )}

      {stage === "setup" && (
        <div className="absolute inset-0 z-10 flex flex-col justify-end bg-gradient-to-t from-black via-black/80 to-black/40 px-6 pb-[max(env(safe-area-inset-bottom),2rem)]">
          <h1 className="text-[24px] font-extrabold tracking-[-0.03em]">Form coach</h1>
          <p className="mt-2 text-[14px] leading-relaxed text-white/75">
            {createAnalyzer(exercise.analyzer).setupHint} Everything runs on your phone - no video
            leaves the device, only the numbers.
          </p>
          <button
            type="button"
            onClick={start}
            className="mt-6 flex h-14 w-full items-center justify-center gap-2 rounded-full bg-white text-[16px] font-bold text-black active:scale-[0.98]"
          >
            <Play className="h-5 w-5" strokeWidth={2.4} /> Start camera
          </button>
        </div>
      )}

      {stage === "requesting" && (
        <div className="absolute inset-0 z-10 flex items-center justify-center bg-black/85">
          <Loader2 className="h-7 w-7 animate-spin" />
        </div>
      )}

      {(stage === "denied" || stage === "unsupported") && (
        <div className="absolute inset-0 z-10 flex flex-col items-center justify-center gap-4 bg-black px-8 text-center">
          <Camera className="h-8 w-8 text-white/70" strokeWidth={1.6} />
          <p className="max-w-[19rem] text-[14.5px] leading-relaxed text-white/80">
            {stage === "denied"
              ? "I need camera access to see your form. Allow it in your browser settings and try again."
              : "This device or browser won't run the on-device pose tracker. Try Chrome or Safari on a modern phone."}
          </p>
          <button
            type="button"
            onClick={() => setStage("setup")}
            className="h-12 rounded-full bg-white px-6 text-[15px] font-bold text-black"
          >
            Try again
          </button>
        </div>
      )}

      {live && (
        <div className="absolute inset-x-0 bottom-0 z-10 flex justify-center px-6 pb-[max(env(safe-area-inset-bottom),2rem)]">
          <button
            type="button"
            onClick={finish}
            className="flex h-16 w-16 items-center justify-center rounded-full bg-white text-black active:scale-95"
            aria-label="End set"
          >
            <Square className="h-6 w-6 fill-current" />
          </button>
        </div>
      )}

      {stage === "result" && breakdown && (
        <div className="absolute inset-0 z-20 overflow-y-auto bg-background px-5 pt-[max(env(safe-area-inset-top),1.5rem)] pb-10 text-foreground">
          <p className="text-[12px] font-bold uppercase tracking-[0.08em] text-muted-foreground">
            Set complete · {exercise.name}
          </p>
          <div className="mt-4 flex items-end gap-3">
            <p className="text-[54px] font-extrabold leading-none tracking-[-0.04em]">
              {breakdown.score}
            </p>
            <p className="pb-2 text-[14px] text-muted-foreground">
              technique score
              {breakdown.reps > 0 ? ` · ${breakdown.reps} reps` : ""}
            </p>
          </div>

          <div className="mt-6 space-y-3">
            {[
              ["Range of motion", breakdown.rangeOfMotion],
              ["Control", breakdown.control],
              ["Alignment", breakdown.alignment],
              ["Consistency", breakdown.consistency],
            ].map(([label, value]) => (
              <div key={label as string}>
                <div className="flex items-center justify-between text-[13px]">
                  <span className="font-semibold">{label}</span>
                  <span className="tabular-nums text-muted-foreground">{value as number}</span>
                </div>
                <div className="mt-1.5 h-2 w-full overflow-hidden rounded-full bg-muted">
                  <div
                    className="h-full rounded-full bg-primary"
                    style={{ width: `${value as number}%` }}
                  />
                </div>
              </div>
            ))}
          </div>

          <div className="mt-6 space-y-2">
            {breakdown.notes.map((n) => (
              <p key={n} className="text-[13.5px] leading-relaxed text-muted-foreground">
                · {n}
              </p>
            ))}
          </div>

          <div className="mt-6 rounded-[1.5rem] border border-primary/25 bg-primary-soft/70 p-5">
            <div className="flex gap-3">
              <Sparkles className="mt-0.5 h-5 w-5 shrink-0 text-accent-foreground" />
              {aiLoading ? (
                <p className="text-[13px] text-muted-foreground">Wellcare AI is looking at your numbers…</p>
              ) : (
                <p className="text-[13px] leading-relaxed">
                  {aiReview ?? "No complete reps to review. Run the set again and I'll grade it properly."}
                </p>
              )}
            </div>
          </div>

          <div className="mt-6 flex gap-2.5">
            <button
              type="button"
              onClick={start}
              className="h-12 flex-1 rounded-full border border-border text-[15px] font-bold"
            >
              Another set
            </button>
            <button
              type="button"
              onClick={() => navigate({ to: "/session" })}
              className="h-12 flex-1 rounded-full bg-primary text-[15px] font-bold text-primary-foreground"
            >
              Back to session
            </button>
          </div>
        </div>
      )}
    </div>
  );
}
