import { createFileRoute, Link, useNavigate } from "@tanstack/react-router";
import { Dumbbell, Camera, Library, Play, Flame } from "lucide-react";
import { SectionHeader, SurfaceCard } from "@/components/wellcare/Card";
import { PrimaryButton } from "@/components/wellcare/onboarding-ui";
import { useWellcare } from "@/lib/wellcare/store";
import { recommendPlans } from "@/lib/wellcare/workout/recommend";
import { getPlan } from "@/lib/wellcare/workout/plans";
import { consistency, useTraining } from "@/lib/wellcare/workout/training-store";
import { EXERCISES, CAMERA_EXERCISES, getExercise } from "@/lib/wellcare/workout/library";
import { ExerciseCollage } from "@/components/wellcare/ExerciseMedia";

import { startPlanDay } from "@/lib/wellcare/workout/start-session";

export const Route = createFileRoute("/workout")({
  head: () => ({
    meta: [
      { title: "Training - Wellcare AI" },
      {
        name: "description",
        content:
          "Your training plan, a 150+ exercise library and the on-device AI form coach, all built around your experience and equipment.",
      },
      { property: "og:title", content: "Training - Wellcare AI" },
      {
        property: "og:description",
        content: "Plans, exercise library and camera form coaching in Wellcare AI.",
      },
    ],
  }),
  component: WorkoutScreen,
});

function WorkoutScreen() {
  const { profile } = useWellcare();
  const training = useTraining();
  const navigate = useNavigate();

  const suggestions = recommendPlans(profile, 3);
  const activePlan = training.activePlanId ? getPlan(training.activePlanId) : undefined;
  const nextDayIndex = activePlan
    ? (training.planCursor[activePlan.id] ?? 0) % activePlan.days.length
    : 0;
  const nextDay = activePlan?.days[nextDayIndex];
  const stats = consistency(training.history, profile.daysPerWeek);
  const lastSession = training.history[0];

  return (
    <div className="space-y-7 px-5 pt-[max(env(safe-area-inset-top),1.25rem)]">
      <header className="pt-3">
        <h1 className="text-[26px] font-extrabold tracking-[-0.035em]">Training</h1>
        <p className="mt-1.5 text-[14px] text-muted-foreground">
          {activePlan ? activePlan.name : "Pick a plan and it becomes your default."}
        </p>
      </header>

      {training.active ? (
        <SurfaceCard className="border-primary/30 bg-primary-soft/70">
          <p className="text-[12px] font-bold uppercase tracking-[0.08em] text-accent-foreground">
            Session in progress
          </p>
          <h2 className="mt-1.5 text-[19px] font-extrabold tracking-tight">{training.active.title}</h2>
          <div className="mt-4">
            <PrimaryButton onClick={() => navigate({ to: "/session" })}>Resume session</PrimaryButton>
          </div>
        </SurfaceCard>
      ) : activePlan && nextDay ? (
        <SurfaceCard>
          <p className="text-[12px] font-bold uppercase tracking-[0.08em] text-muted-foreground">
            Next up · Day {nextDayIndex + 1}
          </p>
          <h2 className="mt-1.5 text-[20px] font-extrabold tracking-tight">{nextDay.label}</h2>
          <p className="mt-1 text-[13.5px] text-muted-foreground">
            {nextDay.focus} · {nextDay.exercises.length} exercises
          </p>
          <div className="mt-4 flex gap-2.5">
            <button
              type="button"
              onClick={() => {
                startPlanDay(activePlan, nextDayIndex);
                navigate({ to: "/session" });
              }}
              className="flex h-12 flex-1 items-center justify-center gap-2 rounded-full bg-primary text-[15px] font-bold text-primary-foreground active:scale-[0.98]"
            >
              <Play className="h-4 w-4" strokeWidth={2.4} />
              Start
            </button>
            <Link
              to="/plan/$planId"
              params={{ planId: activePlan.id }}
              className="flex h-12 items-center justify-center rounded-full border border-border px-5 text-[15px] font-bold"
            >
              Plan
            </Link>
          </div>
        </SurfaceCard>
      ) : (
        <SurfaceCard className="flex flex-col items-center py-8 text-center">
          <span className="flex h-14 w-14 items-center justify-center rounded-[1.15rem] bg-muted">
            <Dumbbell className="h-6 w-6 text-muted-foreground" strokeWidth={1.7} />
          </span>
          <h2 className="mt-4 text-[17px] font-bold tracking-tight">No active plan yet</h2>
        </SurfaceCard>
      )}

      <section>
        <SectionHeader title="Recommended for you" />
        <div className="space-y-3">
          {suggestions.map(({ plan }) => {
            const ids = plan.days.flatMap((d) => d.exercises.map((e) => e.exerciseId)).slice(0, 3);
            const names = ids.map((i) => getExercise(i)?.name ?? "Exercise");
            const total = plan.days.reduce((n, d) => n + d.exercises.length, 0);
            return (
              <Link
                key={plan.id}
                to="/plan/$planId"
                params={{ planId: plan.id }}
                className="flex gap-3.5 rounded-[1.5rem] border border-border/70 bg-card p-3.5 active:scale-[0.99]"
              >
                <ExerciseCollage exerciseIds={ids} names={names} />
                <div className="min-w-0 flex-1">
                  <p className="truncate text-[15.5px] font-bold tracking-tight">{plan.name}</p>
                  <p className="mt-0.5 text-[12.5px] text-muted-foreground">
                    {plan.daysPerWeek}× / week · {plan.minutesPerSession} min · {total} exercises
                  </p>
                  <div className="mt-2 flex flex-wrap items-center gap-1.5">
                    <span className="rounded-full bg-primary-soft px-2 py-0.5 text-[11px] font-bold capitalize text-accent-foreground">
                      {plan.level}
                    </span>
                    <span className="rounded-full bg-muted px-2 py-0.5 text-[11px] font-bold text-muted-foreground">
                      {plan.split}
                    </span>
                  </div>
                </div>
              </Link>
            );
          })}
        </div>
      </section>


      <section className="grid grid-cols-2 gap-3">
        <Link
          to="/exercises"
          className="rounded-[1.5rem] border border-border/70 bg-card p-4 active:scale-[0.98]"
        >
          <span className="flex h-10 w-10 items-center justify-center rounded-full bg-primary-soft text-accent-foreground">
            <Library className="h-[18px] w-[18px]" strokeWidth={2} />
          </span>
          <span className="mt-3 block text-[15px] font-bold tracking-tight">Exercise library</span>
          <span className="mt-0.5 block text-[12.5px] text-muted-foreground">
            {EXERCISES.length} movements
          </span>
        </Link>
        <Link
          to="/exercises"
          search={{ camera: true }}
          className="rounded-[1.5rem] border border-border/70 bg-card p-4 active:scale-[0.98]"
        >
          <span className="flex h-10 w-10 items-center justify-center rounded-full bg-primary-soft text-accent-foreground">
            <Camera className="h-[18px] w-[18px]" strokeWidth={2} />
          </span>
          <span className="mt-3 block text-[15px] font-bold tracking-tight">Form coach</span>
          <span className="mt-0.5 block text-[12.5px] text-muted-foreground">
            {CAMERA_EXERCISES.length} camera-ready lifts
          </span>
        </Link>
      </section>

      <section>
        <SectionHeader title="Consistency" />
        <SurfaceCard>
          <div className="flex items-end justify-between">
            <div>
              <p className="text-[30px] font-extrabold leading-none tracking-[-0.03em]">
                {stats.completed}
                <span className="text-[16px] text-muted-foreground">/{stats.planned}</span>
              </p>
              <p className="mt-1.5 text-[12.5px] text-muted-foreground">sessions, last 4 weeks</p>
            </div>
            <div className="flex items-center gap-1.5 rounded-full bg-primary-soft px-3 py-1.5 text-accent-foreground">
              <Flame className="h-4 w-4" strokeWidth={2.2} />
              <span className="text-[13px] font-bold">{stats.streak} streak</span>
            </div>
          </div>
          <div className="mt-4 h-2 w-full overflow-hidden rounded-full bg-muted">
            <div className="h-full rounded-full bg-primary" style={{ width: `${stats.percent}%` }} />
          </div>
          {lastSession && (
            <p className="mt-3 text-[12.5px] text-muted-foreground">
              Last: {lastSession.title} · {Math.round(lastSession.durationSec / 60)} min ·{" "}
              {lastSession.volumeKg > 0 ? `${lastSession.volumeKg} kg volume` : `${lastSession.totalReps} reps`}
              {lastSession.avgFormScore != null ? ` · form ${lastSession.avgFormScore}` : ""}
            </p>
          )}
        </SurfaceCard>
      </section>

    </div>
  );
}
