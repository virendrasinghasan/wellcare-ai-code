import { createFileRoute, Link } from "@tanstack/react-router";
import { Plus, Trash2 } from "lucide-react";
import { SurfaceCard, SectionHeader } from "@/components/wellcare/Card";
import { MacroBar } from "@/components/wellcare/MacroBar";
import { useWellcare } from "@/lib/wellcare/store";
import type { MealType } from "@/lib/wellcare/types";

export const Route = createFileRoute("/nutrition")({
  head: () => ({
    meta: [
      { title: "Nutrition - Wellcare AI" },
      {
        name: "description",
        content:
          "Everything you logged today with calories and macros against your personal Wellcare AI targets.",
      },
      { property: "og:title", content: "Nutrition - Wellcare AI" },
      { property: "og:description", content: "Today's food log and macro breakdown." },
    ],
  }),
  component: NutritionScreen,
});

const MEALS: MealType[] = ["breakfast", "lunch", "dinner", "snack"];

function NutritionScreen() {
  const { profile, consumed, todayLog, removeEntry } = useWellcare();
  const targets = profile.targets ?? { calories: 2200, protein: 150, carbs: 240, fat: 70 };

  return (
    <div className="space-y-6 px-5 pt-[max(env(safe-area-inset-top),1.25rem)]">
      <header className="pt-3">
        <h1 className="text-[26px] font-extrabold tracking-[-0.035em]">Nutrition</h1>
        <p className="mt-1.5 text-[14px] text-muted-foreground">Today's log, nothing hidden.</p>
      </header>

      <SurfaceCard>
        <div className="flex items-end justify-between">
          <div>
            <p className="text-[11px] font-bold uppercase tracking-[0.1em] text-muted-foreground">
              Eaten
            </p>
            <p className="mt-1 text-[32px] leading-none text-metric">
              {Math.round(consumed.calories).toLocaleString()}
              <span className="text-[14px] font-bold text-muted-foreground">
                {" "}
                / {targets.calories.toLocaleString()}
              </span>
            </p>
          </div>
          <Link
            to="/add-food"
            className="flex h-11 items-center gap-1.5 rounded-full bg-primary px-4 text-[13.5px] font-bold text-primary-foreground"
          >
            <Plus className="h-4 w-4" />
            Add
          </Link>
        </div>
        <div className="mt-6 grid grid-cols-3 gap-4">
          <MacroBar label="Protein" value={consumed.protein} target={targets.protein} tone="protein" />
          <MacroBar label="Carbs" value={consumed.carbs} target={targets.carbs} tone="carbs" />
          <MacroBar label="Fat" value={consumed.fat} target={targets.fat} tone="fat" />
        </div>
      </SurfaceCard>

      {MEALS.map((meal) => {
        const items = todayLog.entries.filter((e) => e.meal === meal);
        return (
          <div key={meal}>
            <SectionHeader
              title={meal}
              action={
                <span className="text-[12.5px] font-bold tabular-nums text-muted-foreground">
                  {items.reduce((s, i) => s + i.calories, 0)} kcal
                </span>
              }
            />
            <SurfaceCard className="divide-y divide-border/70 p-0">
              {items.length === 0 ? (
                <p className="px-5 py-5 text-[13.5px] text-muted-foreground">Nothing logged yet</p>
              ) : (
                items.map((i) => (
                  <div key={i.id} className="flex items-center gap-3 px-5 py-4">
                    <div className="min-w-0 flex-1">
                      <p className="truncate text-[14.5px] font-semibold">{i.name}</p>
                      <p className="mt-0.5 text-[12px] text-muted-foreground">
                        {i.time} · P {i.protein}g · C {i.carbs}g · F {i.fat}g
                      </p>
                    </div>
                    <span className="text-[14px] text-metric">{i.calories}</span>
                    <button
                      type="button"
                      aria-label={`Remove ${i.name}`}
                      onClick={() => removeEntry(i.id)}
                      className="flex h-9 w-9 shrink-0 items-center justify-center rounded-full text-muted-foreground transition-colors active:bg-muted"
                    >
                      <Trash2 className="h-4 w-4" />
                    </button>
                  </div>
                ))
              )}
            </SurfaceCard>
          </div>
        );
      })}
    </div>
  );
}
