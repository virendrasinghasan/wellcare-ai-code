import { createFileRoute, useNavigate } from "@tanstack/react-router";
import { useServerFn } from "@tanstack/react-start";
import { useQuery } from "@tanstack/react-query";
import { useEffect, useMemo, useRef, useState } from "react";
import { Sparkles, Send, Loader2, ChevronLeft } from "lucide-react";
import { SurfaceCard } from "@/components/wellcare/Card";
import { todayKey, useWellcare } from "@/lib/wellcare/store";
import { askCoach, confirmCoachAction } from "@/lib/wellcare/coach.functions";
import { readRouteBeforeCoach } from "@/lib/wellcare/last-route";
import { getHealthSummary } from "@/lib/wellcare/health/health.functions";
import type { AgentAction, ClientOp, PendingConfirmation } from "@/lib/wellcare/agent/types";

import { buildInsight } from "@/lib/wellcare/insight";
import wellcareIcon from "@/assets/wellcare-icon.svg";

export const Route = createFileRoute("/coach")({
  head: () => ({
    meta: [
      { title: "Wellcare AI - your coach" },
      {
        name: "description",
        content:
          "A blunt, useful read on your day: calories left, protein gap and what to do about it right now.",
      },
      { property: "og:title", content: "Wellcare AI - your coach" },
      {
        property: "og:description",
        content: "A blunt, useful read on your day and what to do about it right now.",
      },
    ],
  }),
  component: CoachScreen,
});

interface Msg {
  role: "coach" | "you";
  text: string;
  actions?: AgentAction[];
}

const THREAD_KEY = "wellcare:coach-thread:v1";

function readThread(): Msg[] {
  if (typeof window === "undefined") return [];
  try {
    const raw = window.localStorage.getItem(THREAD_KEY);
    return raw ? (JSON.parse(raw) as Msg[]).slice(-40) : [];
  } catch {
    return [];
  }
}

function CoachScreen() {
  const { profile, consumed, todayLog, addEntry, addWater, removeEntry, updateProfile, refreshDiary, signedIn } = useWellcare();
  const [input, setInput] = useState("");
  const [thread, setThread] = useState<Msg[]>([]);
  const [pending, setPending] = useState(false);
  const [confirmation, setConfirmation] = useState<{ request: string; value: PendingConfirmation } | null>(null);
  const bottomRef = useRef<HTMLDivElement>(null);
  const firstScroll = useRef(true);

  const ask = useServerFn(askCoach);
  const confirmAction = useServerFn(confirmCoachAction);
  const navigate = useNavigate();
  const fetchHealth = useServerFn(getHealthSummary);
  /** Real synced numbers when the user has an account; otherwise the coach says so. */
  const { data: health } = useQuery({
    queryKey: ["health-summary"],
    queryFn: () => fetchHealth({ data: undefined }),
    enabled: signedIn,
    staleTime: 60_000,
  });


  useEffect(() => setThread(readThread()), []);

  useEffect(() => {
    try {
      window.localStorage.setItem(THREAD_KEY, JSON.stringify(thread.slice(-40)));
    } catch {
      /* storage blocked - chat still works in-memory */
    }
    // First paint of a restored thread jumps straight to the newest message;
    // later updates animate.
    const behavior: ScrollBehavior = firstScroll.current ? "auto" : "smooth";
    const frame = requestAnimationFrame(() => {
      bottomRef.current?.scrollIntoView({ behavior, block: "end" });
      if (thread.length) firstScroll.current = false;
    });
    return () => cancelAnimationFrame(frame);
  }, [thread, pending]);


  const targets = profile.targets ?? { calories: 2200, protein: 150, carbs: 240, fat: 70 };
  const insight = useMemo(
    () => buildInsight(profile, consumed, todayLog.entries.length, new Date().getHours()),
    [profile, consumed, todayLog.entries.length],
  );

  const facts = [
    `${Math.round(consumed.calories).toLocaleString()} / ${targets.calories.toLocaleString()} kcal`,
    `${Math.round(consumed.protein)} / ${targets.protein} g protein`,
    `${todayLog.entries.length} meal${todayLog.entries.length === 1 ? "" : "s"} logged`,
    `${(todayLog.waterMl / 1000).toFixed(1)} L water`,
  ];

  const proteinLeft = Math.round(targets.protein - consumed.protein);
  const caloriesLeft = Math.round(targets.calories - consumed.calories);

  /** Suggestions derived from the user's actual state right now. */
  const prompts = useMemo(() => {
    const list: string[] = [];
    if (todayLog.entries.length === 0) list.push("What should I eat today?");
    else list.push("How am I doing today?");
    if (proteinLeft > 25) list.push("How do I hit my protein?");
    if (caloriesLeft > 300 && new Date().getHours() >= 16) list.push("What should I eat tonight?");
    if (profile.daysPerWeek) list.push("What workout should I do?");
    if (todayLog.waterMl < profile.waterTargetMl * 0.5) list.push("Am I drinking enough water?");
    return list.slice(0, 3);
  }, [todayLog.entries.length, todayLog.waterMl, proteinLeft, caloriesLeft, profile.daysPerWeek, profile.waterTargetMl]);

  function buildSnapshot() {
    return {
      profile: {
        name: profile.firstName || null,
        age: profile.ageYears ?? (profile.birthYear ? new Date().getFullYear() - profile.birthYear : null),
        sex: profile.sex,
        height_cm: profile.heightCm,
        weight_kg: profile.weightKg,
        goal: profile.goal?.replace(/_/g, " ") ?? null,
        activity_level: profile.activityLevel,
        diet: profile.dietType?.replace(/_/g, " ") ?? null,
        allergies: profile.allergies.join(", ") || null,
      },
      nutrition: {
        calorie_target: targets.calories,
        calories_eaten: Math.round(consumed.calories),
        calories_left: caloriesLeft,
        protein_target_g: targets.protein,
        protein_eaten_g: Math.round(consumed.protein),
        protein_left_g: proteinLeft,
        carbs_left_g: Math.round(targets.carbs - consumed.carbs),
        fat_left_g: Math.round(targets.fat - consumed.fat),
        meals_today:
          todayLog.entries
            .map((e) => `${e.meal}: ${e.name} (${Math.round(e.calories)} kcal, ${Math.round(e.protein)}g P)`)
            .join("; ") || "nothing logged yet",
        water_ml: todayLog.waterMl,
        water_target_ml: profile.waterTargetMl,
      },
      training: {
        experience: profile.experience,
        planned_days_per_week: profile.daysPerWeek,
        equipment: profile.equipment.join(", ") || null,
        todays_workout: "not scheduled yet - workout planning isn't set up in the app",
        workout_history: "not tracked yet",
      },
      activity: {
        steps: health?.steps
          ? `${health.steps.value} today (${health.steps.source === "device" ? "synced from your health app" : "logged manually"})`
          : "not tracked (no health data connected)",
        sleep: health?.sleepLastNight
          ? `${Math.floor(health.sleepLastNight.minutes / 60)}h ${health.sleepLastNight.minutes % 60}m last night${
              health.sleepWeekAvgMinutes
                ? `, 7-day average ${Math.floor(health.sleepWeekAvgMinutes / 60)}h ${health.sleepWeekAvgMinutes % 60}m`
                : ""
            }`
          : "not tracked",
        resting_heart_rate: health?.heartRate ? `${health.heartRate.bpm} bpm` : "not tracked",
        local_time: new Date().toLocaleTimeString([], { hour: "2-digit", minute: "2-digit" }),
        local_date: todayKey(),

      },
      notes: [`Wellcare's own read on today: ${insight}`],
    };
  }

  async function send(text?: string) {
    const q = (text ?? input).trim();
    if (!q || pending) return;
    const history = thread.slice(-8);
    setThread((t) => [...t, { role: "you", text: q }]);
    setInput("");
    setPending(true);
    try {
      const res = await ask({ data: { question: q, snapshot: buildSnapshot(), history } });
      applyClientOps(res.clientOps);
      if (res.performed.some((item) => item.ok)) void refreshDiary();
      if (res.pending) setConfirmation({ request: q, value: res.pending });
      setThread((t) => [...t, { role: "coach", text: res.reply, actions: res.actions }]);
    } catch {
      setThread((t) => [
        ...t,
        { role: "coach", text: "I'm having a little trouble connecting right now. Give me a moment and try again." },
      ]);
    } finally {
      setPending(false);
    }
  }

  function applyClientOps(ops: ClientOp[]) {
    for (const op of ops) {
      // Signed in, the backend already wrote the row; refreshDiary pulls it back.
      if (op.type === "add_food") {
        if (!signedIn) addEntry(op.payload);
      }
      else if (op.type === "add_water") {
        if (!signedIn) addWater(op.payload.ml);
      } else if (op.type === "remove_food") {
        if (signedIn) continue;
        const match = todayLog.entries.find((entry) => entry.name.toLowerCase() === op.payload.name.toLowerCase());
        if (match) removeEntry(match.id);
      } else updateProfile(op.payload);
    }
  }

  async function confirmPending() {
    if (!confirmation || pending) return;
    setPending(true);
    try {
      const res = await confirmAction({ data: { name: confirmation.value.name, args: confirmation.value.args, originalRequest: confirmation.request } });
      applyClientOps(res.clientOps);
      if (res.performed.some((item) => item.ok)) void refreshDiary();
      setThread((items) => [...items, { role: "coach", text: res.reply, actions: res.actions }]);
      setConfirmation(null);
    } catch {
      setThread((items) => [...items, { role: "coach", text: "Couldn't apply that change. Nothing was changed." }]);
    } finally {
      setPending(false);
    }
  }

  return (
    <div className="flex min-h-screen flex-col px-5 pb-[max(env(safe-area-inset-bottom),0.75rem)] pt-[max(env(safe-area-inset-top),0.5rem)]">
      <header className="sticky top-0 z-30 -mx-5 flex items-center gap-2 bg-background px-5 py-3">
        <button
          type="button"
          onClick={() => void navigate({ to: readRouteBeforeCoach() })}
          aria-label="Back"
          className="-ml-2 flex h-10 w-10 shrink-0 items-center justify-center rounded-full text-foreground transition-colors active:bg-muted"
        >
          <ChevronLeft className="h-6 w-6" strokeWidth={2.2} />
        </button>
        <img src={wellcareIcon} alt="" className="h-7 w-7" />
        <h1 className="text-[20px] font-extrabold tracking-[-0.03em]">Wellcare AI</h1>
      </header>

      <SurfaceCard className="mt-3">
        <div className="flex items-center gap-2">
          <Sparkles className="h-4 w-4 text-accent-foreground" />
          <span className="text-[12px] font-bold uppercase tracking-[0.08em] text-accent-foreground">
            Today's read
          </span>
        </div>
        <p className="mt-2 text-[14.5px] leading-relaxed text-foreground">{insight}</p>
        <div className="mt-4 flex flex-wrap gap-2">
          {facts.map((f) => (
            <span
              key={f}
              className="rounded-full bg-muted px-3 py-1.5 text-[12px] font-semibold tabular-nums text-muted-foreground"
            >
              {f}
            </span>
          ))}
        </div>
      </SurfaceCard>

      <div className="mt-5 flex-1 space-y-3">
        {thread.map((m, i) => (
          <div
            key={i}
            className={
              "animate-in fade-in slide-in-from-bottom-1 duration-200 " +
              (m.role === "you"
                ? "ml-auto max-w-[85%] rounded-[1.25rem] rounded-br-md bg-primary px-4 py-3 text-[14px] font-medium text-primary-foreground"
                : "mr-auto max-w-[90%] whitespace-pre-wrap rounded-[1.25rem] rounded-bl-md border border-border/70 bg-card px-4 py-3 text-[14px] leading-relaxed")
            }
          >
            <p>{m.text}</p>
            {m.actions && m.actions.length > 0 && (
              <div className="mt-3 flex flex-wrap gap-2">
                {m.actions.map((action) => (
                  <button
                    key={`${action.to}-${action.label}`}
                    type="button"
                    onClick={() => void navigate({ to: action.to })}
                    className="rounded-full bg-primary px-3.5 py-2 text-[12.5px] font-bold text-primary-foreground"
                  >
                    {action.label}
                  </button>
                ))}
              </div>
            )}
          </div>
        ))}
        {confirmation && (
          <SurfaceCard className="border-primary/30 bg-primary-soft/70">
            <p className="text-[12px] font-bold uppercase text-accent-foreground">Confirm change</p>
            <p className="mt-2 text-[14px] leading-relaxed">{confirmation.value.summary}</p>
            <div className="mt-4 flex gap-2">
              <button type="button" onClick={() => setConfirmation(null)} className="h-10 flex-1 rounded-full border border-border bg-card text-[13px] font-bold">Cancel</button>
              <button type="button" onClick={() => void confirmPending()} className="h-10 flex-1 rounded-full bg-primary text-[13px] font-bold text-primary-foreground">Confirm</button>
            </div>
          </SurfaceCard>
        )}
        {pending && (
          <div className="mr-auto flex max-w-[90%] items-center gap-2 rounded-[1.25rem] rounded-bl-md border border-border/70 bg-card px-4 py-3 text-[14px] text-muted-foreground">
            <Loader2 className="h-4 w-4 animate-spin" />
            Thinking…
          </div>
        )}
        {thread.length === 0 && !pending && (
          <p className="pt-2 text-[13px] leading-relaxed text-muted-foreground">
            Ask anything about food, training or recovery. I read your real logged numbers - no invented
            data, no lectures.
          </p>
        )}
        <div ref={bottomRef} />
      </div>

      {prompts.length > 0 && (
        <div className="mt-4 flex flex-wrap gap-2">
          {prompts.map((p) => (
            <button
              key={p}
              type="button"
              onClick={() => void send(p)}
              disabled={pending}
              className="rounded-full border border-border/80 bg-card px-3.5 py-2 text-[12.5px] font-semibold text-foreground disabled:opacity-50"
            >
              {p}
            </button>
          ))}
        </div>
      )}

      <div className="sticky bottom-0 z-30 mt-3 flex items-center gap-2 bg-background pb-2 pt-2">
        <input
          value={input}
          onChange={(e) => setInput(e.target.value)}
          onKeyDown={(e) => {
            if (e.key === "Enter") void send();
          }}
          placeholder="Ask Wellcare AI…"
          className="h-13 min-w-0 flex-1 rounded-full border border-border/80 bg-card px-5 text-[15px] font-medium outline-none focus:border-primary"
        />
        <button
          type="button"
          onClick={() => void send()}
          disabled={pending}
          aria-label="Send"
          className="flex h-13 w-13 shrink-0 items-center justify-center rounded-full bg-primary text-primary-foreground disabled:opacity-50"
        >
          {pending ? <Loader2 className="h-4.5 w-4.5 animate-spin" /> : <Send className="h-4.5 w-4.5" />}
        </button>
      </div>
    </div>
  );
}
