import { createFileRoute, Link, useNavigate } from "@tanstack/react-router";
import { ChevronLeft, Camera, Play, Star, Dumbbell, Plus } from "lucide-react";
import { toast } from "sonner";
import { cn } from "@/lib/utils";
import { SurfaceCard } from "@/components/wellcare/Card";
import { ExerciseDemo } from "@/components/wellcare/ExerciseMedia";
import { getExercise } from "@/lib/wellcare/workout/library";
import { GEAR_LABEL, MUSCLE_LABEL } from "@/lib/wellcare/workout/types";
import { useTraining, useToggleFavorite, personalBest } from "@/lib/wellcare/workout/training-store";
import { startSingleExercise, addExerciseToSession } from "@/lib/wellcare/workout/start-session";


export const Route = createFileRoute("/exercise/$id")({
  head: ({ params }) => {
    const ex = getExercise(params.id);
    const title = ex ? `${ex.name} - Wellcare AI` : "Exercise - Wellcare AI";
    const description = ex
      ? `${ex.description} Form cues, common mistakes and set guidance.`
      : "Exercise details, form cues and set guidance in Wellcare AI.";
    return {
      meta: [
        { title },
        { name: "description", content: description.slice(0, 158) },
        { property: "og:title", content: title },
        { property: "og:description", content: description.slice(0, 158) },
      ],
    };
  },
  component: ExerciseDetail,
});

function ExerciseDetail() {
  const { id } = Route.useParams();
  const navigate = useNavigate();
  const ex = getExercise(id);
  const { favorites, history } = useTraining();
  const toggleFavorite = useToggleFavorite();

  if (!ex) {
    return (
      <div className="px-5 pt-[max(env(safe-area-inset-top),2rem)]">
        <p className="text-[15px] font-bold">That exercise doesn't exist.</p>
        <Link to="/exercises" className="mt-3 inline-block text-[14px] text-accent-foreground">
          Back to the library
        </Link>
      </div>
    );
  }

  const pb = personalBest(history, ex.id);

  return (
    <div className="space-y-6 px-5 pt-[max(env(safe-area-inset-top),1.25rem)]">
      <div className="flex items-center justify-between gap-3">
        <button
          type="button"
          onClick={() => navigate({ to: "/exercises" })}
          className="flex h-10 w-10 items-center justify-center rounded-full bg-muted"
          aria-label="Back"
        >
          <ChevronLeft className="h-5 w-5" />
        </button>
        <button
          type="button"
          onClick={() => toggleFavorite(ex.id)}
          aria-label="Toggle favourite"
          className="flex h-10 w-10 items-center justify-center rounded-full bg-muted"
        >
          <Star
            className={cn(
              "h-4.5 w-4.5",
              favorites.includes(ex.id) ? "fill-current text-accent-foreground" : "text-muted-foreground",
            )}
          />
        </button>
      </div>

      <ExerciseDemo exerciseId={ex.id} name={ex.name} />

      <header>
        <h1 className="text-[25px] font-extrabold leading-tight tracking-[-0.035em]">{ex.name}</h1>
        <p className="mt-2 text-[14px] leading-relaxed text-muted-foreground">{ex.description}</p>
        <div className="mt-3 flex flex-wrap gap-1.5">
          {[
            ...ex.primary.map((m) => MUSCLE_LABEL[m]),
            ...ex.equipment.slice(0, 2).map((g) => GEAR_LABEL[g]),
            ex.difficulty,
          ].map((tag) => (
            <span
              key={tag}
              className="rounded-full bg-muted px-2.5 py-1 text-[11.5px] font-bold capitalize text-muted-foreground"
            >
              {tag}
            </span>
          ))}
        </div>
      </header>

      <SurfaceCard className="flex items-center justify-between">
        <div>
          <p className="text-[12px] font-bold uppercase tracking-[0.08em] text-muted-foreground">
            Prescription
          </p>
          <p className="mt-1 text-[15.5px] font-bold tracking-tight">
            {ex.sets} × {ex.reps} · {ex.restSec}s rest
          </p>
          {pb && (
            <p className="mt-1 text-[12.5px] text-muted-foreground">
              Best so far: {pb.weightKg} kg × {pb.reps}
            </p>
          )}
        </div>
        <Dumbbell className="h-6 w-6 text-muted-foreground" strokeWidth={1.7} />
      </SurfaceCard>

      <div className="flex gap-2.5">
        <button
          type="button"
          onClick={() => {
            startSingleExercise(ex);
            navigate({ to: "/session" });
          }}
          className="flex h-12 flex-1 items-center justify-center gap-2 rounded-full bg-primary text-[15px] font-bold text-primary-foreground active:scale-[0.98]"
        >
          <Play className="h-4 w-4" strokeWidth={2.4} /> Start set
        </button>
        {ex.analyzer && (
          <Link
            to="/form-coach/$exerciseId"
            params={{ exerciseId: ex.id }}
            className="flex h-12 items-center justify-center gap-2 rounded-full border border-border px-5 text-[15px] font-bold"
          >
            <Camera className="h-4 w-4" /> Form
          </Link>
        )}
      </div>

      <div className="flex gap-2.5 pb-6">
        <button
          type="button"
          onClick={() => {
            const r = addExerciseToSession(ex);
            toast.success(
              r === "added" ? `${ex.name} added to your session` : `Started a session with ${ex.name}`,
            );
          }}
          className="flex h-11 flex-1 items-center justify-center gap-2 rounded-full border border-border text-[14.5px] font-bold active:scale-[0.98]"
        >
          <Plus className="h-4 w-4" /> Add to workout
        </button>
      </div>
    </div>
  );
}
