import { createFileRoute, Link } from "@tanstack/react-router";
import {
  Sparkles,
  Activity,
  Droplets,
  Footprints,
  Plus,
  Camera,
  ScanBarcode,
  Dumbbell,
  ChevronRight,
  Flame,
} from "lucide-react";
import { SurfaceCard, SectionHeader } from "@/components/wellcare/Card";
import { WellcareAvatar } from "@/components/wellcare/Avatar";
import { dailyHealthScore, loggingStreak, nextBestAction } from "@/lib/wellcare/score";
import { ProgressRing } from "@/components/wellcare/ProgressRing";
import { MacroBar } from "@/components/wellcare/MacroBar";
import { useWellcare } from "@/lib/wellcare/store";
import { buildInsight } from "@/lib/wellcare/insight";

export const Route = createFileRoute("/")({
  head: () => ({
    meta: [
      { title: "Today - Wellcare AI" },
      {
        name: "description",
        content:
          "Your daily health command center: calories, macros, meals, workout, water and activity in one clean view.",
      },
      { property: "og:title", content: "Today - Wellcare AI" },
      {
        property: "og:description",
        content: "Your daily health command center: calories, macros, meals, workout and water.",
      },
    ],
  }),
  component: HomeScreen,
});

function greeting(hour: number) {
  if (hour < 12) return "Good morning";
  if (hour < 18) return "Good afternoon";
  return "Good evening";
}

const shortcuts = [
  { to: "/scan-meal", label: "Scan meal", icon: Camera },
  { to: "/scan-barcode", label: "Barcode", icon: ScanBarcode },
  { to: "/add-food", label: "Add food", icon: Plus },
  { to: "/workout", label: "Workout", icon: Dumbbell },
] as const;

function HomeScreen() {
  const { profile, consumed, todayLog, logs, addWater } = useWellcare();
  const now = new Date();
  const targets = profile.targets ?? { calories: 2200, protein: 150, carbs: 240, fat: 70 };
  const remaining = Math.max(0, targets.calories - Math.round(consumed.calories));
  const waterPct = Math.min(100, Math.round((todayLog.waterMl / profile.waterTargetMl) * 100));
  const insight = buildInsight(profile, consumed, todayLog.entries.length, now.getHours());
  const health = dailyHealthScore(profile, consumed, todayLog);
  const streak = loggingStreak(logs);
  const action = nextBestAction(profile, consumed, todayLog);

  const dateLabel = now.toLocaleDateString(undefined, {
    weekday: "long",
    day: "numeric",
    month: "long",
  });

  return (
    <div className="space-y-8 px-5 pt-[max(env(safe-area-inset-top),1.25rem)]">
      <header className="grid grid-cols-[minmax(0,1fr)_auto] items-center gap-3 pt-3">
        <div className="min-w-0">
          <p className="text-[12px] font-bold uppercase tracking-[0.08em] text-muted-foreground">
            {dateLabel}
          </p>
          <h1 className="mt-1.5 truncate text-[26px] font-extrabold tracking-[-0.035em]">
            {greeting(now.getHours())}
            {profile.firstName ? `, ${profile.firstName}` : ""}
          </h1>
        </div>
        <Link to="/profile" aria-label="Your profile" className="shrink-0">
          <WellcareAvatar
            name={profile.firstName}
            path={profile.avatarPath}
            local={profile.avatarLocal}
            className="h-11 w-11"
            textClassName="text-[15px]"
          />
        </Link>
      </header>

      {/* Calories + macros */}
      <SurfaceCard className="p-6">
        <div className="flex flex-col items-center">
          <ProgressRing value={consumed.calories} max={targets.calories}>
            <span className="text-[38px] leading-none text-metric">
              {remaining.toLocaleString()}
            </span>
            <span className="mt-1.5 text-[12px] font-semibold text-muted-foreground">kcal left</span>
          </ProgressRing>
          <p className="mt-4 text-[13px] text-muted-foreground">
            <span className="font-bold text-foreground tabular-nums">
              {Math.round(consumed.calories).toLocaleString()}
            </span>{" "}
            of {targets.calories.toLocaleString()} kcal target
          </p>
        </div>

        <div className="mt-7 grid grid-cols-3 gap-4">
          <MacroBar label="Protein" value={consumed.protein} target={targets.protein} tone="protein" />
          <MacroBar label="Carbs" value={consumed.carbs} target={targets.carbs} tone="carbs" />
          <MacroBar label="Fat" value={consumed.fat} target={targets.fat} tone="fat" />
        </div>
      </SurfaceCard>

      {/* Daily score + streak */}
      <SurfaceCard className="p-5">
        <div className="flex items-start justify-between gap-3">
          <div className="min-w-0">
            <p className="text-[12px] font-bold uppercase tracking-[0.08em] text-muted-foreground">
              Daily score
            </p>
            <p className="mt-1.5 flex items-baseline gap-1.5">
              <span className="text-[32px] leading-none text-metric">{health.score}</span>
              <span className="text-[13px] font-bold text-muted-foreground">/ 100</span>
            </p>
            <p className="mt-1 text-[13px] font-semibold tracking-tight">{health.label}</p>
          </div>
          <span className="flex shrink-0 items-center gap-1.5 rounded-full bg-muted px-3 py-2 text-[12.5px] font-bold leading-none">
            <Flame className="h-3.5 w-3.5 text-accent-foreground" strokeWidth={2.4} />
            <span className="tabular-nums">{streak}</span>
            <span className="text-muted-foreground">day streak</span>
          </span>
        </div>

        <div className="mt-5 space-y-2.5">
          {health.parts.map((part) => (
            <div key={part.label} className="flex items-center gap-3">
              <span className="w-16 shrink-0 text-[12px] font-semibold text-muted-foreground">
                {part.label}
              </span>
              <span className="h-1.5 flex-1 overflow-hidden rounded-full bg-muted">
                <span
                  className="block h-full rounded-full bg-primary"
                  style={{ width: `${part.value}%` }}
                />
              </span>
              <span className="w-9 shrink-0 text-right text-[12px] font-bold tabular-nums">
                {part.value}
              </span>
            </div>
          ))}
        </div>
      </SurfaceCard>

      {/* Quick actions */}
      <div className="grid grid-cols-4 gap-2.5">
        {shortcuts.map(({ to, label, icon: Icon }) => (
          <Link
            key={to}
            to={to}
            className="flex flex-col items-center gap-2 rounded-[1.25rem] border border-border/70 bg-card px-1 py-3.5 transition-transform active:scale-[0.97]"
          >
            <Icon className="h-[18px] w-[18px] text-accent-foreground" strokeWidth={2} />
            <span className="text-[11.5px] font-bold tracking-tight">{label}</span>
          </Link>
        ))}
      </div>

      {/* AI insight */}
      <SurfaceCard className="bg-primary-soft">
        <div className="flex items-center gap-2">
          <Sparkles className="h-4 w-4 text-accent-foreground" />
          <span className="text-[12px] font-bold uppercase tracking-[0.08em] text-accent-foreground">
            Coach
          </span>
        </div>
        <p className="mt-2 text-[14.5px] font-medium leading-relaxed text-foreground">{insight}</p>
        <Link
          to={action.to}
          className="mt-4 flex items-center gap-3 rounded-[1.25rem] bg-card p-4"
        >
          <span className="min-w-0 flex-1">
            <span className="block text-[13.5px] font-bold tracking-tight">{action.title}</span>
            <span className="mt-0.5 block text-[12.5px] leading-snug text-muted-foreground">
              {action.detail}
            </span>
          </span>
          <ChevronRight className="h-4 w-4 shrink-0 text-muted-foreground" />
        </Link>
        <Link
          to="/coach"
          className="mt-3 inline-flex items-center gap-1 text-[13px] font-bold text-accent-foreground"
        >
          Open coach <ChevronRight className="h-3.5 w-3.5" />
        </Link>
      </SurfaceCard>

      {/* Meals */}
      <section>
        <SectionHeader
          title="Today's food"
          action={
            <Link to="/add-food" className="text-[13px] font-bold text-accent-foreground">
              Add
            </Link>
          }
        />
        {todayLog.entries.length === 0 ? (
          <SurfaceCard>
            <p className="text-[14px] font-semibold tracking-tight">Nothing logged yet</p>
            <p className="mt-1 text-[13px] leading-relaxed text-muted-foreground">
              Log your first meal and the numbers above stop being theoretical.
            </p>
          </SurfaceCard>
        ) : (
          <SurfaceCard className="divide-y divide-border/70 p-0">
            {todayLog.entries.map((e) => (
              <div key={e.id} className="flex items-center gap-3 px-5 py-3.5">
                <span className="min-w-0 flex-1">
                  <span className="block truncate text-[14.5px] font-bold tracking-tight">
                    {e.name}
                  </span>
                  <span className="block text-[12.5px] capitalize text-muted-foreground">
                    {e.meal} · {e.time}
                  </span>
                </span>
                <span className="shrink-0 text-[14px] font-bold tabular-nums">
                  {Math.round(e.calories)} kcal
                </span>
              </div>
            ))}
          </SurfaceCard>
        )}
      </section>

      {/* Water + activity */}
      <section className="grid grid-cols-2 items-stretch gap-3">
        <SurfaceCard className="flex h-full flex-col p-5">
          <Droplets className="h-[18px] w-[18px] text-[var(--water)]" strokeWidth={2} />
          <p className="mt-3 flex items-baseline gap-1 text-[24px] leading-none text-metric">
            <span>{(todayLog.waterMl / 1000).toFixed(1)}</span>
            <span className="text-[13px] font-bold text-muted-foreground">L</span>
          </p>
          <p className="mt-1 text-[12.5px] leading-snug text-muted-foreground">
            {waterPct}% of {(profile.waterTargetMl / 1000).toFixed(1)} L
          </p>
          <button
            type="button"
            onClick={() => addWater(250)}
            aria-label="Add 250 millilitres of water"
            className="mt-4 flex h-11 w-full items-center justify-center gap-1.5 rounded-full bg-muted px-3 text-[12.5px] font-bold leading-none transition-transform active:scale-[0.97]"
          >
            <Plus className="h-3.5 w-3.5 shrink-0" strokeWidth={2.6} />
            <span className="whitespace-nowrap tabular-nums">250 ml</span>
          </button>
        </SurfaceCard>

        <SurfaceCard className="flex h-full flex-col p-5">
          <Footprints className="h-[18px] w-[18px] text-accent-foreground" strokeWidth={2} />
          <p className="mt-3 text-[24px] leading-none text-metric">
            {profile.health.connected ? "0" : "Not set"}
          </p>
          <p className="mt-1 text-[12.5px] leading-snug text-muted-foreground">
            {profile.health.connected ? "No steps yet today" : "Steps need a health connection"}
          </p>
          <Link
            to="/soon/$feature"
            params={{ feature: "health-data" }}
            className="mt-4 flex h-11 w-full items-center justify-center gap-1.5 rounded-full bg-muted px-3 text-[12.5px] font-bold leading-none transition-transform active:scale-[0.97]"
          >
            <Activity className="h-3.5 w-3.5 shrink-0" strokeWidth={2.4} />
            <span className="whitespace-nowrap">{profile.health.connected ? "Manage" : "Connect"}</span>
          </Link>
        </SurfaceCard>
      </section>


      {/* Trackers */}
      <section>
        <SectionHeader
          title="Trackers"
          action={
            <Link to="/trackers" className="text-[13px] font-bold text-accent-foreground">
              Track more
            </Link>
          }
        />
        <div className="grid grid-cols-2 gap-3">
          {[
            { key: "sleep", label: "Sleep", note: "Bedtime and rest" },
            { key: "steps", label: "Steps", note: "Daily movement" },
            { key: "heart_rate", label: "Heart rate", note: "BPM and resting" },
            { key: "weight", label: "Weight", note: "Body weight trend" },
          ].map((t) => (
            <Link
              key={t.key}
              to="/tracker/$key"
              params={{ key: t.key }}
              className="rounded-[1.5rem] border border-border/70 bg-card p-4 transition-transform active:scale-[0.98]"
            >
              <span className="block text-[14.5px] font-bold tracking-tight">{t.label}</span>
              <span className="mt-0.5 block text-[12.5px] leading-snug text-muted-foreground">
                {t.note}
              </span>
            </Link>
          ))}
        </div>
      </section>

      {/* Training */}
      <section>
        <SectionHeader title="Training" />
        <Link
          to="/workout"
          className="flex items-center gap-3 rounded-[1.5rem] border border-border/70 bg-card p-5"
        >
          <span className="flex h-11 w-11 shrink-0 items-center justify-center rounded-full bg-primary-soft text-accent-foreground">
            <Dumbbell className="h-5 w-5" strokeWidth={2} />
          </span>
          <span className="min-w-0 flex-1">
            <span className="block text-[14.5px] font-bold tracking-tight">
              {profile.daysPerWeek
                ? `${profile.daysPerWeek} sessions a week planned`
                : "No training plan yet"}
            </span>
            <span className="block text-[12.5px] text-muted-foreground">
              Open training to set today's session
            </span>
          </span>
          <ChevronRight className="h-4.5 w-4.5 shrink-0 text-muted-foreground" />
        </Link>
      </section>
    </div>
  );
}
