import { createFileRoute, Link } from "@tanstack/react-router";
import { useMutation, useQuery, useQueryClient } from "@tanstack/react-query";
import { useServerFn } from "@tanstack/react-start";
import { ChevronRight, Check, Plus } from "lucide-react";
import { SectionHeader } from "@/components/wellcare/Card";
import { TrackerIcon } from "@/components/wellcare/TrackerIcon";
import { useWellcare } from "@/lib/wellcare/store";
import { DEFAULT_HOME_TRACKERS, TRACKERS } from "@/lib/wellcare/trackers/registry";
import type { TrackerKey } from "@/lib/wellcare/trackers/registry";
import { listTrackerPrefs, setTrackerPref } from "@/lib/wellcare/trackers/trackers.functions";

export const Route = createFileRoute("/trackers")({
  head: () => ({
    meta: [
      { title: "Trackers - Wellcare AI" },
      {
        name: "description",
        content:
          "Pick the health trackers you actually use: sleep, medicine, heart rate, glucose, steps, water, weight and more.",
      },
      { property: "og:title", content: "Trackers - Wellcare AI" },
      {
        property: "og:description",
        content: "Choose and manage the health trackers on your Wellcare dashboard.",
      },
    ],
  }),
  component: TrackersScreen,
});

function TrackersScreen() {
  const { signedIn } = useWellcare();
  const queryClient = useQueryClient();
  const fetchPrefs = useServerFn(listTrackerPrefs);
  const savePref = useServerFn(setTrackerPref);

  const prefsQuery = useQuery({
    queryKey: ["tracker-prefs"],
    queryFn: () => fetchPrefs(),
    enabled: signedIn,
  });

  const toggle = useMutation({
    mutationFn: (vars: { key: TrackerKey; pinnedHome: boolean }) =>
      savePref({ data: { key: vars.key, pinnedHome: vars.pinnedHome, enabled: true } }),
    onSuccess: () => queryClient.invalidateQueries({ queryKey: ["tracker-prefs"] }),
  });

  const pinned = new Set<string>(
    prefsQuery.data
      ? prefsQuery.data.filter((p) => p.pinnedHome).map((p) => p.key)
      : DEFAULT_HOME_TRACKERS,
  );
  const hasSavedPrefs = (prefsQuery.data?.length ?? 0) > 0;
  const isPinned = (key: TrackerKey) =>
    hasSavedPrefs ? pinned.has(key) : DEFAULT_HOME_TRACKERS.includes(key);

  return (
    <div className="space-y-8 px-5 pt-[max(env(safe-area-inset-top),1.25rem)]">
      <header className="pt-3">
        <p className="text-[12px] font-bold uppercase tracking-[0.08em] text-muted-foreground">
          Trackers
        </p>
        <h1 className="mt-1.5 text-[26px] font-extrabold tracking-[-0.035em]">
          What you want to keep an eye on
        </h1>
        <p className="mt-2 text-[13.5px] leading-relaxed text-muted-foreground">
          Tap a tracker to log and review it. Use the pin to decide what shows on Home.
        </p>
      </header>

      {!signedIn && (
        <div className="rounded-[1.5rem] border border-border/70 bg-card p-4">
          <p className="text-[14px] font-bold tracking-tight">Sign in to save tracker data</p>
          <p className="mt-1 text-[13px] leading-relaxed text-muted-foreground">
            Health readings are stored privately against your account, so they need one.
          </p>
          <Link
            to="/welcome"
            className="mt-3 inline-flex h-11 items-center rounded-full bg-primary px-5 text-[13px] font-bold text-primary-foreground"
          >
            Sign in
          </Link>
        </div>
      )}

      <section>
        <SectionHeader title="All trackers" />
        <ul className="space-y-2.5">
          {TRACKERS.map((t) => (
            <li key={t.key} className="flex items-center gap-2">
              <Link
                to="/tracker/$key"
                params={{ key: t.key }}
                className="flex min-w-0 flex-1 items-center gap-3 rounded-[1.5rem] border border-border/70 bg-card p-4 transition-transform active:scale-[0.98]"
              >
                <span className="flex h-11 w-11 shrink-0 items-center justify-center rounded-full bg-primary-soft text-accent-foreground">
                  <TrackerIcon name={t.icon} className="h-[18px] w-[18px]" />
                </span>
                <span className="min-w-0 flex-1">
                  <span className="block truncate text-[15px] font-bold tracking-tight">
                    {t.label}
                  </span>
                  <span className="block truncate text-[12.5px] text-muted-foreground">
                    {t.blurb}
                  </span>
                </span>
                <ChevronRight className="h-4 w-4 shrink-0 text-muted-foreground" />
              </Link>
              <button
                type="button"
                disabled={!signedIn || toggle.isPending}
                onClick={() => toggle.mutate({ key: t.key, pinnedHome: !isPinned(t.key) })}
                aria-pressed={isPinned(t.key)}
                aria-label={
                  isPinned(t.key) ? `Remove ${t.label} from Home` : `Add ${t.label} to Home`
                }
                className={`flex h-11 w-11 shrink-0 items-center justify-center rounded-full border transition-colors disabled:opacity-40 ${
                  isPinned(t.key)
                    ? "border-transparent bg-primary text-primary-foreground"
                    : "border-border/70 bg-card text-muted-foreground"
                }`}
              >
                {isPinned(t.key) ? <Check className="h-4 w-4" /> : <Plus className="h-4 w-4" />}
              </button>
            </li>
          ))}
        </ul>
        <p className="mt-3 px-1 text-[12px] text-muted-foreground">
          Checked trackers appear on your Home screen.
        </p>
      </section>
    </div>
  );
}
