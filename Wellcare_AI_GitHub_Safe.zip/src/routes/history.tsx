import { useMemo, useState } from "react";
import { createFileRoute, Link } from "@tanstack/react-router";
import { useServerFn } from "@tanstack/react-start";
import { useQuery } from "@tanstack/react-query";
import { ChevronLeft, Dumbbell, Footprints, Moon, Scale, UtensilsCrossed, Droplets, HeartPulse } from "lucide-react";
import { SurfaceCard } from "@/components/wellcare/Card";
import { getHistory, type HistoryDay } from "@/lib/wellcare/history.functions";

export const Route = createFileRoute("/history")({
  head: () => ({
    meta: [
      { title: "History - Wellcare AI" },
      {
        name: "description",
        content:
          "Browse your last 30 days of meals, workouts, weight, water, steps and sleep in one timeline.",
      },
      { property: "og:title", content: "History - Wellcare AI" },
      { property: "og:description", content: "Your last 30 days of meals, workouts and trackers." },
      { property: "og:type", content: "website" },
      { name: "twitter:card", content: "summary" },
    ],
  }),
  component: HistoryScreen,
});

type RangeKey = "today" | "yesterday" | "7" | "30" | "date";

const RANGES: Array<{ key: RangeKey; label: string }> = [
  { key: "today", label: "Today" },
  { key: "yesterday", label: "Yesterday" },
  { key: "7", label: "Last 7 days" },
  { key: "30", label: "Last 30 days" },
  { key: "date", label: "Pick a date" },
];

function iso(offsetDays: number) {
  const d = new Date();
  d.setDate(d.getDate() - offsetDays);
  return d.toISOString().slice(0, 10);
}

function prettyDate(date: string) {
  if (date === iso(0)) return "Today";
  if (date === iso(1)) return "Yesterday";
  return new Date(`${date}T00:00:00`).toLocaleDateString(undefined, {
    weekday: "short",
    day: "numeric",
    month: "short",
  });
}

function HistoryScreen() {
  const fetchHistory = useServerFn(getHistory);
  const [range, setRange] = useState<RangeKey>("7");
  const [pickedDate, setPickedDate] = useState(iso(0));

  const { start, end } = useMemo(() => {
    if (range === "today") return { start: iso(0), end: iso(0) };
    if (range === "yesterday") return { start: iso(1), end: iso(1) };
    if (range === "date") return { start: pickedDate, end: pickedDate };
    return { start: iso(range === "7" ? 6 : 29), end: iso(0) };
  }, [range, pickedDate]);

  const query = useQuery({
    queryKey: ["history", start, end],
    queryFn: () => fetchHistory({ data: { start, end } }),
  });

  const days = (query.data?.days ?? []).filter(
    (day) =>
      day.meals.length ||
      day.workouts.length ||
      day.waterMl ||
      day.steps ||
      day.sleepMinutes ||
      day.weightKg ||
      day.glucose.length ||
      day.restingHeartRate,
  );

  return (
    <div className="space-y-5 px-5 pb-6 pt-[max(env(safe-area-inset-top),1.25rem)]">
      <header className="flex items-center gap-3 pt-3">
        <Link
          to="/progress"
          className="flex h-11 w-11 items-center justify-center rounded-full border border-border/70 bg-card"
          aria-label="Back to progress"
        >
          <ChevronLeft className="h-5 w-5" />
        </Link>
        <div>
          <h1 className="text-[24px] font-extrabold tracking-[-0.035em]">History</h1>
          <p className="text-[13px] text-muted-foreground">Everything you actually logged.</p>
        </div>
      </header>

      <div className="-mx-5 flex gap-2 overflow-x-auto px-5 pb-1">
        {RANGES.map((option) => (
          <button
            key={option.key}
            type="button"
            onClick={() => setRange(option.key)}
            className={`shrink-0 rounded-full border px-4 py-2 text-[13px] font-semibold transition ${
              range === option.key
                ? "border-transparent bg-primary text-primary-foreground"
                : "border-border/70 bg-card text-muted-foreground"
            }`}
          >
            {option.label}
          </button>
        ))}
      </div>

      {range === "date" ? (
        <input
          type="date"
          value={pickedDate}
          max={iso(0)}
          onChange={(event) => setPickedDate(event.target.value)}
          className="w-full rounded-2xl border border-border/70 bg-card px-4 py-3 text-[15px]"
        />
      ) : null}

      {query.isLoading ? (
        <SurfaceCard className="py-10 text-center text-[14px] text-muted-foreground">
          Loading your history...
        </SurfaceCard>
      ) : query.isError ? (
        <SurfaceCard className="py-10 text-center text-[14px] text-muted-foreground">
          Couldn't load history. Sign in and try again.
        </SurfaceCard>
      ) : days.length === 0 ? (
        <SurfaceCard className="py-10 text-center">
          <h2 className="text-[16px] font-bold tracking-tight">No activity logged</h2>
          <p className="mt-1.5 text-[13.5px] text-muted-foreground">
            Nothing was recorded for this period.
          </p>
        </SurfaceCard>
      ) : (
        days.map((day) => <DayCard key={day.date} day={day} />)
      )}
    </div>
  );
}

function Stat({ icon, label, value }: { icon: React.ReactNode; label: string; value: string }) {
  return (
    <div className="rounded-2xl bg-muted/60 px-3 py-2.5">
      <div className="flex items-center gap-1.5 text-muted-foreground">
        {icon}
        <span className="text-[10.5px] font-bold uppercase tracking-[0.08em]">{label}</span>
      </div>
      <p className="mt-1 text-[15px] font-bold tracking-tight">{value}</p>
    </div>
  );
}

function DayCard({ day }: { day: HistoryDay }) {
  const stats: Array<{ icon: React.ReactNode; label: string; value: string }> = [];
  if (day.totals.calories > 0)
    stats.push({
      icon: <UtensilsCrossed className="h-3.5 w-3.5" />,
      label: "Calories",
      value: `${Math.round(day.totals.calories)} kcal`,
    });
  if (day.waterMl > 0)
    stats.push({
      icon: <Droplets className="h-3.5 w-3.5" />,
      label: "Water",
      value: `${(day.waterMl / 1000).toFixed(1)} L`,
    });
  if (day.steps != null)
    stats.push({
      icon: <Footprints className="h-3.5 w-3.5" />,
      label: "Steps",
      value: day.steps.toLocaleString(),
    });
  if (day.sleepMinutes != null)
    stats.push({
      icon: <Moon className="h-3.5 w-3.5" />,
      label: "Sleep",
      value: `${Math.floor(day.sleepMinutes / 60)}h ${day.sleepMinutes % 60}m`,
    });
  if (day.weightKg != null)
    stats.push({
      icon: <Scale className="h-3.5 w-3.5" />,
      label: "Weight",
      value: `${Math.round(day.weightKg * 10) / 10} kg`,
    });
  if (day.restingHeartRate != null)
    stats.push({
      icon: <HeartPulse className="h-3.5 w-3.5" />,
      label: "Resting HR",
      value: `${day.restingHeartRate} bpm`,
    });

  return (
    <SurfaceCard className="space-y-4">
      <div className="flex items-baseline justify-between">
        <h2 className="text-[17px] font-extrabold tracking-[-0.03em]">{prettyDate(day.date)}</h2>
        {day.totals.calories > 0 ? (
          <span className="text-[12px] text-muted-foreground">
            P {Math.round(day.totals.protein)}g · C {Math.round(day.totals.carbs)}g · F{" "}
            {Math.round(day.totals.fat)}g
          </span>
        ) : null}
      </div>

      {stats.length ? <div className="grid grid-cols-2 gap-2">{stats.map((stat) => <Stat key={stat.label} {...stat} />)}</div> : null}

      {day.meals.length ? (
        <div className="space-y-2">
          <p className="text-[11px] font-bold uppercase tracking-[0.1em] text-muted-foreground">
            Meals
          </p>
          {day.meals.map((meal) => (
            <div key={meal.id} className="rounded-2xl border border-border/60 px-3 py-2.5">
              <p className="text-[13px] font-bold capitalize">{meal.title || meal.type}</p>
              <ul className="mt-1 space-y-0.5">
                {meal.items.map((item, index) => (
                  <li
                    key={`${meal.id}-${index}`}
                    className="flex justify-between gap-3 text-[13px] text-muted-foreground"
                  >
                    <span className="truncate">
                      {item.name}
                      {item.quantity ? ` · ${Math.round(item.quantity * 10) / 10}${item.unit}` : ""}
                    </span>
                    <span className="shrink-0">{Math.round(item.calories)} kcal</span>
                  </li>
                ))}
              </ul>
            </div>
          ))}
        </div>
      ) : null}

      {day.workouts.length ? (
        <div className="space-y-2">
          <p className="flex items-center gap-1.5 text-[11px] font-bold uppercase tracking-[0.1em] text-muted-foreground">
            <Dumbbell className="h-3.5 w-3.5" /> Workouts
          </p>
          {day.workouts.map((workout) => (
            <div key={workout.id} className="rounded-2xl border border-border/60 px-3 py-2.5">
              <div className="flex justify-between gap-3">
                <p className="text-[13px] font-bold">{workout.title ?? "Workout"}</p>
                {workout.durationMinutes != null ? (
                  <span className="text-[12px] text-muted-foreground">
                    {workout.durationMinutes} min
                  </span>
                ) : null}
              </div>
              {workout.sets.length ? (
                <ul className="mt-1 space-y-0.5">
                  {workout.sets.map((set, index) => (
                    <li
                      key={`${workout.id}-${index}`}
                      className="flex justify-between gap-3 text-[13px] text-muted-foreground"
                    >
                      <span className="truncate">
                        {set.exercise} · set {set.setNumber}
                      </span>
                      <span className="shrink-0">
                        {set.reps ?? "-"} reps
                        {set.weightKg ? ` @ ${set.weightKg} kg` : ""}
                      </span>
                    </li>
                  ))}
                </ul>
              ) : null}
            </div>
          ))}
        </div>
      ) : null}

      {day.glucose.length ? (
        <p className="text-[13px] text-muted-foreground">
          Glucose: {day.glucose.map((entry) => `${entry.value} ${entry.unit === "mg_dl" ? "mg/dL" : "mmol/L"}`).join(", ")}
        </p>
      ) : null}
    </SurfaceCard>
  );
}
