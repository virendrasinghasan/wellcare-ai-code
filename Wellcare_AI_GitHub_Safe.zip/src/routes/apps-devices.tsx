import { createFileRoute, useNavigate } from "@tanstack/react-router";
import { useServerFn } from "@tanstack/react-start";
import { useQuery, useQueryClient } from "@tanstack/react-query";
import { useEffect, useRef, useState } from "react";
import { Activity, Check, ChevronLeft, Loader2, RefreshCw, ShieldCheck, X } from "lucide-react";
import { SurfaceCard, SectionHeader } from "@/components/wellcare/Card";
import { useWellcare } from "@/lib/wellcare/store";
import {
  HEALTH_INTEGRATIONS,
  HEALTH_METRICS,
  METRIC_LABEL,
  formatSyncedAt,
  getBridge,
  isSupportedHere,
  unsupportedReason,
  type HealthIntegrationMeta,
  type HealthMetricKey,
} from "@/lib/wellcare/health/integrations";
import {
  disconnectHealthProvider,
  ingestHealthSamples,
  listHealthConnections,
  recordSyncFailure,
  saveHealthConnection,
  type HealthConnectionRow,
} from "@/lib/wellcare/health/health.functions";

export const Route = createFileRoute("/apps-devices")({
  head: () => ({
    meta: [
      { title: "Apps & Devices - Wellcare AI" },
      {
        name: "description",
        content:
          "Connect Google Health and other health platforms to Wellcare AI, manage permissions and sync your steps, sleep, heart rate and weight.",
      },
      { property: "og:title", content: "Apps & Devices - Wellcare AI" },
      {
        property: "og:description",
        content: "Manage your health data connections, permissions and sync status.",
      },
      { property: "og:type", content: "website" },
      { name: "twitter:card", content: "summary" },
    ],
  }),
  component: AppsDevicesScreen,
});

function AppsDevicesScreen() {
  const navigate = useNavigate();
  const queryClient = useQueryClient();
  const { signedIn } = useWellcare();
  const list = useServerFn(listHealthConnections);
  const save = useServerFn(saveHealthConnection);
  const ingest = useServerFn(ingestHealthSamples);
  const fail = useServerFn(recordSyncFailure);
  const disconnect = useServerFn(disconnectHealthProvider);

  const [busy, setBusy] = useState<string | null>(null);
  const [error, setError] = useState<string | null>(null);
  const [note, setNote] = useState<string | null>(null);
  const [explainer, setExplainer] = useState<HealthIntegrationMeta | null>(null);

  const { data: connections = [], isLoading } = useQuery({
    queryKey: ["health-connections"],
    queryFn: () => list({ data: undefined }),
    enabled: signedIn,
  });

  const byProvider = new Map<string, HealthConnectionRow>(connections.map((c) => [c.provider, c]));
  const refresh = () => queryClient.invalidateQueries({ queryKey: ["health-connections"] });

  async function connect(meta: HealthIntegrationMeta) {
    setExplainer(null);
    setError(null);
    setNote(null);
    setBusy(meta.id);
    try {
      const bridge = getBridge();
      if (!bridge || bridge.id !== meta.id) throw new Error(unsupportedReason(meta));
      const granted = await bridge.requestPermissions(meta.metrics);
      if (!granted.length) {
        setError("No permissions were granted, so nothing was connected.");
        return;
      }
      const accountId = (await bridge.accountId?.()) ?? null;
      await save({ data: { provider: meta.id, grantedMetrics: granted, externalAccountId: accountId } });
      if (granted.length < meta.metrics.length) {
        setNote(
          `Connected with partial access. Not shared: ${meta.metrics
            .filter((m) => !granted.includes(m))
            .map((m) => METRIC_LABEL[m])
            .join(", ")}.`,
        );
      }
      await refresh();
      await sync(meta, granted);
    } catch (err) {
      setError(err instanceof Error ? err.message : "Couldn't connect. Try again.");
    } finally {
      setBusy(null);
    }
  }

  async function sync(meta: HealthIntegrationMeta, metricsOverride?: HealthMetricKey[]) {
    const connection = byProvider.get(meta.id);
    const metrics = metricsOverride ?? connection?.grantedMetrics ?? [];
    if (!metrics.length) return;
    setBusy(meta.id);
    setError(null);
    try {
      const bridge = getBridge();
      if (!bridge || bridge.id !== meta.id) throw new Error(unsupportedReason(meta));
      const since = connection?.lastSyncedAt ?? new Date(Date.now() - 30 * 86_400_000).toISOString();
      const samples = await bridge.readSamples(metrics, since);
      const result = await ingest({
        data: {
          provider: meta.id,
          samples,
          unavailable: meta.metrics.filter((m) => !metrics.includes(m)),
        },
      });
      setNote(
        result.imported
          ? `Imported ${result.imported} record${result.imported === 1 ? "" : "s"}.`
          : "Nothing new to import.",
      );
      await refresh();
    } catch (err) {
      const message = err instanceof Error ? err.message : "Sync failed.";
      setError(`${message} Your connection is still active - you can retry.`);
      try {
        await fail({ data: { provider: meta.id, message: message.slice(0, 300) } });
        await refresh();
      } catch {
        /* the message on screen is enough */
      }
    } finally {
      setBusy(null);
    }
  }

  async function remove(meta: HealthIntegrationMeta) {
    setBusy(meta.id);
    setError(null);
    try {
      await disconnect({ data: { provider: meta.id } });
      setNote("Disconnected. Everything already imported stays in Wellcare AI.");
      await refresh();
    } catch (err) {
      setError(err instanceof Error ? err.message : "Couldn't disconnect.");
    } finally {
      setBusy(null);
    }
  }

  /**
   * Browsers have no background sync, so the next best thing is syncing when
   * the screen opens and the last sync is older than 30 minutes.
   */
  const autoSynced = useRef(false);
  useEffect(() => {
    if (autoSynced.current || !signedIn || !connections.length) return;
    const stale = connections.find(
      (c) =>
        c.status !== "disconnected" &&
        isSupportedHere(c.provider) &&
        (!c.lastSyncedAt || Date.now() - new Date(c.lastSyncedAt).getTime() > 30 * 60_000),
    );
    if (!stale) return;
    const meta = HEALTH_INTEGRATIONS.find((i) => i.id === stale.provider);
    if (!meta) return;
    autoSynced.current = true;
    void sync(meta);
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [signedIn, connections]);

  return (
    <div className="space-y-6 px-5 pb-6 pt-[max(env(safe-area-inset-top),1rem)]">
      <header className="flex items-center gap-2 pt-2">
        <button
          type="button"
          onClick={() => void navigate({ to: "/profile" })}
          aria-label="Back to profile"
          className="-ml-2 flex h-10 w-10 items-center justify-center rounded-full active:bg-muted"
        >
          <ChevronLeft className="h-6 w-6" strokeWidth={2.2} />
        </button>
        <h1 className="text-[24px] font-extrabold tracking-[-0.035em]">Apps & Devices</h1>
      </header>

      <p className="text-[13.5px] leading-relaxed text-muted-foreground">
        Connect a health platform and Wellcare AI reads your real numbers instead of guessing.
        Everything imported is labelled with its source, so synced data never gets confused with
        what you typed in yourself.
      </p>

      {!signedIn && (
        <SurfaceCard>
          <p className="text-[14px] font-bold">Sign in first</p>
          <p className="mt-1 text-[13px] leading-relaxed text-muted-foreground">
            Connections are stored on your account so they survive across devices and sessions.
          </p>
          <button
            type="button"
            onClick={() => void navigate({ to: "/welcome" })}
            className="mt-4 h-11 w-full rounded-full bg-primary text-[13.5px] font-bold text-primary-foreground"
          >
            Sign in
          </button>
        </SurfaceCard>
      )}

      {error && (
        <p className="rounded-[1rem] bg-destructive/10 px-4 py-3 text-[13px] font-medium text-destructive">
          {error}
        </p>
      )}
      {note && (
        <p className="rounded-[1rem] bg-muted px-4 py-3 text-[13px] font-medium text-muted-foreground">
          {note}
        </p>
      )}

      <div>
        <SectionHeader title="Health platforms" />
        <div className="space-y-3">
          {HEALTH_INTEGRATIONS.map((meta) => {
            const connection = byProvider.get(meta.id);
            const connected = connection?.status === "connected";
            const supported = isSupportedHere(meta.id);
            const working = busy === meta.id;

            return (
              <SurfaceCard key={meta.id}>
                <div className="flex items-start gap-3">
                  <span className="flex h-10 w-10 shrink-0 items-center justify-center rounded-[0.9rem] bg-muted">
                    <Activity className="h-5 w-5 text-accent-foreground" strokeWidth={1.9} />
                  </span>
                  <div className="min-w-0 flex-1">
                    <div className="flex items-center gap-2">
                      <h2 className="text-[15px] font-bold tracking-tight">{meta.label}</h2>
                      <span
                        className={
                          "rounded-full px-2.5 py-1 text-[11px] font-bold uppercase tracking-[0.04em] " +
                          (connected
                            ? "bg-primary/15 text-accent-foreground"
                            : "bg-muted text-muted-foreground")
                        }
                      >
                        {connected ? "Connected" : supported ? "Not connected" : "Unavailable here"}
                      </span>
                    </div>
                    <p className="mt-1 text-[12.5px] leading-snug text-muted-foreground">
                      {connected ? formatSyncedAt(connection?.lastSyncedAt) : meta.blurb}
                    </p>
                    {connection?.status === "error" && connection.lastError && (
                      <p className="mt-1 text-[12.5px] font-medium text-destructive">
                        Last sync failed: {connection.lastError}
                      </p>
                    )}
                    {!supported && !connected && (
                      <p className="mt-1 text-[12.5px] leading-snug text-muted-foreground">
                        {unsupportedReason(meta)}
                      </p>
                    )}
                  </div>
                </div>

                {connected && connection && (
                  <div className="mt-3 flex flex-wrap gap-1.5">
                    {meta.metrics.map((m) => {
                      const on = connection.grantedMetrics.includes(m);
                      return (
                        <span
                          key={m}
                          className={
                            "inline-flex items-center gap-1 rounded-full px-2.5 py-1 text-[11.5px] font-semibold " +
                            (on ? "bg-muted text-foreground" : "bg-muted/50 text-muted-foreground line-through")
                          }
                        >
                          {on ? <Check className="h-3 w-3" /> : <X className="h-3 w-3" />}
                          {METRIC_LABEL[m]}
                        </span>
                      );
                    })}
                  </div>
                )}

                <div className="mt-4 flex flex-wrap gap-2">
                  {connected ? (
                    <>
                      <button
                        type="button"
                        disabled={working || !supported}
                        onClick={() => void sync(meta)}
                        className="inline-flex h-10 items-center gap-2 rounded-full bg-primary px-4 text-[13px] font-bold text-primary-foreground disabled:opacity-50"
                      >
                        {working ? (
                          <Loader2 className="h-4 w-4 animate-spin" />
                        ) : (
                          <RefreshCw className="h-4 w-4" />
                        )}
                        Sync now
                      </button>
                      <button
                        type="button"
                        disabled={working || !supported}
                        onClick={() => void connect(meta)}
                        className="h-10 rounded-full border border-border bg-card px-4 text-[13px] font-bold disabled:opacity-50"
                      >
                        Manage permissions
                      </button>
                      <button
                        type="button"
                        disabled={working}
                        onClick={() => void remove(meta)}
                        className="h-10 rounded-full border border-border bg-card px-4 text-[13px] font-bold text-destructive disabled:opacity-50"
                      >
                        Disconnect
                      </button>
                    </>
                  ) : supported ? (
                    <button
                      type="button"
                      disabled={working || !signedIn}
                      onClick={() => setExplainer(meta)}
                      className="h-10 rounded-full bg-primary px-4 text-[13px] font-bold text-primary-foreground disabled:opacity-50"
                    >
                      {working ? "Connecting…" : "Connect"}
                    </button>
                  ) : null}
                </div>
              </SurfaceCard>
            );
          })}
        </div>
        {isLoading && signedIn && (
          <p className="mt-3 text-[12.5px] text-muted-foreground">Checking your connections…</p>
        )}
      </div>

      {explainer && (
        <div className="fixed inset-0 z-50 flex items-end bg-foreground/40 px-4 pb-4">
          <SurfaceCard className="w-full">
            <div className="flex items-center gap-2">
              <ShieldCheck className="h-4.5 w-4.5 text-accent-foreground" />
              <h2 className="text-[16px] font-extrabold tracking-tight">
                What {explainer.label} shares
              </h2>
            </div>
            <ul className="mt-3 space-y-2">
              {HEALTH_METRICS.filter((m) => explainer.metrics.includes(m.key)).map((m) => (
                <li key={m.key} className="text-[13px] leading-snug">
                  <span className="font-bold">{m.label}</span>
                  <span className="text-muted-foreground"> - {m.why}</span>
                </li>
              ))}
            </ul>
            <p className="mt-3 text-[12.5px] leading-relaxed text-muted-foreground">
              You approve each category on Google's own consent screen. Deny anything you'd rather
              keep private - Wellcare AI just marks it unavailable.
            </p>
            <div className="mt-4 flex gap-2">
              <button
                type="button"
                onClick={() => setExplainer(null)}
                className="h-11 flex-1 rounded-full border border-border bg-card text-[13.5px] font-bold"
              >
                Not now
              </button>
              <button
                type="button"
                onClick={() => void connect(explainer)}
                className="h-11 flex-1 rounded-full bg-primary text-[13.5px] font-bold text-primary-foreground"
              >
                Continue
              </button>
            </div>
          </SurfaceCard>
        </div>
      )}
    </div>
  );
}
