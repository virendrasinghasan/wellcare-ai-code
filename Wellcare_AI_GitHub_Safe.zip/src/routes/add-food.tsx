import { createFileRoute, useNavigate } from "@tanstack/react-router";
import { useState } from "react";
import { ChevronLeft } from "lucide-react";
import { Field, PrimaryButton, inputClass } from "@/components/wellcare/onboarding-ui";
import { useWellcare } from "@/lib/wellcare/store";
import type { MealType } from "@/lib/wellcare/types";
import { cn } from "@/lib/utils";

export const Route = createFileRoute("/add-food")({
  head: () => ({
    meta: [
      { title: "Add food - Wellcare AI" },
      {
        name: "description",
        content: "Log a meal with calories and macros so your Wellcare AI dashboard stays accurate.",
      },
      { property: "og:title", content: "Add food - Wellcare AI" },
      { property: "og:description", content: "Quick manual food logging in Wellcare AI." },
    ],
  }),
  component: AddFoodScreen,
});

const MEALS: MealType[] = ["breakfast", "lunch", "dinner", "snack"];

function defaultMeal(hour: number): MealType {
  if (hour < 11) return "breakfast";
  if (hour < 16) return "lunch";
  if (hour < 21) return "dinner";
  return "snack";
}

function AddFoodScreen() {
  const navigate = useNavigate();
  const { addEntry } = useWellcare();
  const [meal, setMeal] = useState<MealType>(defaultMeal(new Date().getHours()));
  const [name, setName] = useState("");
  const [calories, setCalories] = useState("");
  const [protein, setProtein] = useState("");
  const [carbs, setCarbs] = useState("");
  const [fat, setFat] = useState("");

  const valid = name.trim().length > 0 && Number(calories) > 0;

  function submit(e: React.FormEvent) {
    e.preventDefault();
    if (!valid) return;
    addEntry({
      meal,
      name: name.trim(),
      calories: Math.round(Number(calories)),
      protein: Math.round(Number(protein) || 0),
      carbs: Math.round(Number(carbs) || 0),
      fat: Math.round(Number(fat) || 0),
    });
    void navigate({ to: "/" });
  }

  return (
    <form onSubmit={submit} className="space-y-6 px-5 pt-[max(env(safe-area-inset-top),1.25rem)]">
      <button
        type="button"
        onClick={() => navigate({ to: "/" })}
        className="flex h-10 w-10 items-center justify-center rounded-full bg-muted"
        aria-label="Back"
      >
        <ChevronLeft className="h-5 w-5" />
      </button>

      <header>
        <h1 className="text-[26px] font-extrabold tracking-[-0.03em]">Add food</h1>
        <p className="mt-2 text-[14px] text-muted-foreground">
          Calories are required. Macros make the coaching sharper.
        </p>
      </header>

      <div className="grid grid-cols-4 gap-2">
        {MEALS.map((m) => (
          <button
            key={m}
            type="button"
            onClick={() => setMeal(m)}
            className={cn(
              "rounded-[1rem] border py-3 text-[12.5px] font-bold capitalize transition-colors",
              meal === m
                ? "border-primary bg-primary-soft text-accent-foreground"
                : "border-border/70 bg-card text-muted-foreground",
            )}
          >
            {m}
          </button>
        ))}
      </div>

      <Field label="What did you eat?">
        <input
          autoFocus
          value={name}
          onChange={(e) => setName(e.target.value)}
          placeholder="Chicken rice bowl"
          className={inputClass}
        />
      </Field>

      <Field label="Calories">
        <input
          type="number"
          inputMode="numeric"
          value={calories}
          onChange={(e) => setCalories(e.target.value)}
          placeholder="620"
          className={inputClass}
        />
      </Field>

      <div className="grid grid-cols-3 gap-2">
        <Field label="Protein (g)">
          <input
            type="number"
            inputMode="numeric"
            value={protein}
            onChange={(e) => setProtein(e.target.value)}
            placeholder="0"
            className={inputClass}
          />
        </Field>
        <Field label="Carbs (g)">
          <input
            type="number"
            inputMode="numeric"
            value={carbs}
            onChange={(e) => setCarbs(e.target.value)}
            placeholder="0"
            className={inputClass}
          />
        </Field>
        <Field label="Fat (g)">
          <input
            type="number"
            inputMode="numeric"
            value={fat}
            onChange={(e) => setFat(e.target.value)}
            placeholder="0"
            className={inputClass}
          />
        </Field>
      </div>

      <PrimaryButton type="submit" disabled={!valid}>
        Log it
      </PrimaryButton>
    </form>
  );
}
