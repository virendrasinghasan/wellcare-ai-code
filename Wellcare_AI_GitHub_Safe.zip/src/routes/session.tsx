import { createFileRoute, useNavigate, Link } from "@tanstack/react-router";
import { useEffect, useMemo, useState } from "react";
import { X, Check, Timer, Camera, Minus, Plus, Flag } from "lucide-react";
import { cn } from "@/lib/utils";
import { SurfaceCard } from "@/components/wellcare/Card";
import { getExercise } from "@/lib/wellcare/workout/library";
import { ExerciseThumb } from "@/components/wellcare/ExerciseMedia";

import {
  cancelSession,
  finishSession,
  overloadHint,
  personalBest,
  updateActive,
  useTraining,
} from "@/lib/wellcare/workout/training-store";
import { readLastFormResult } from "@/lib/wellcare/form/form-result";

export const Route = createFileRoute("/session")({
  head: () => ({
    meta: [
      { title: "Workout session - Wellcare AI" },
      {
        name: "description",
        content: "Track sets, reps, weight and rest in real time, with camera form scoring per set.",
      },
      { property: "og:title", content: "Workout session - Wellcare AI" },
      { property: "og:description", content: "Live set tracking with rest timers and form scores." },
    ],
  }),
  component: SessionScreen,
});

function useRestTimer() {
  const [remaining, setRemaining] = useState(0);
  useEffect(() => {
    if (remaining <= 0) return;
    const t = setInterval(() => setRemaining((r) => Math.max(0, r - 1)), 1000);
    return () => clearInterval(t);
  }, [remaining]);
  return { remaining, start: setRemaining, stop: () => setRemaining(0) };
}

function SessionScreen() {
  const navigate = useNavigate();
  const { active, history } = useTraining();
  const rest = useRestTimer();
  const [elapsed, setElapsed] = useState(0);

  useEffect(() => {
    if (!active) return;
    const tick = () => setElapsed(Math.round((Date.now() - active.startedAt) / 1000));
    tick();
    const t = setInterval(tick, 1000);
    return () => clearInterval(t);
  }, [active]);

  // Pull in a form score captured by the camera coach, if one is waiting.
  useEffect(() => {
    if (!active) return;
    const result = readLastFormResult();
    if (!result) return;
    updateActive((a) => {
      const exIndex = a.exercises.findIndex((e) => e.exerciseId === result.exerciseId);
      if (exIndex < 0) return a;
      const exercises = a.exercises.map((e, i) => {
        if (i !== exIndex) return e;
        const setIndex = e.sets.findIndex((s) => !s.done);
        if (setIndex < 0) return e;
        return {
          ...e,
          sets: e.sets.map((s, j) =>
            j === setIndex
              ? { ...s, done: true, reps: result.reps || s.reps, formScore: result.score }
              : s,
          ),
        };
      });
      return { ...a, exercises };
    });
  }, [active]);

  const currentEx = active?.exercises[active.cursor.exercise];
  const exerciseMeta = currentEx ? getExercise(currentEx.exerciseId) : undefined;
  const hint = useMemo(
    () => (currentEx ? overloadHint(history, currentEx.exerciseId, currentEx.targetReps) : null),
    [history, currentEx],
  );
  const pb = currentEx ? personalBest(history, currentEx.exerciseId) : null;

  if (!active || !currentEx) {
    return (
      <div className="flex min-h-screen flex-col items-center justify-center gap-4 px-8 text-center">
        <p className="text-[15px] font-bold">No session running.</p>
        <Link
          to="/workout"
          className="flex h-12 items-center justify-center rounded-full bg-primary px-6 text-[15px] font-bold text-primary-foreground"
        >
          Back to training
        </Link>
      </div>
    );
  }

  const done = active.exercises.flatMap((e) => e.sets).filter((s) => s.done).length;
  const total = active.exercises.flatMap((e) => e.sets).length;

  const patchSet = (exIndex: number, setIndex: number, patch: Partial<(typeof currentEx.sets)[number]>) =>
    updateActive((a) => ({
      ...a,
      exercises: a.exercises.map((e, i) =>
        i === exIndex ? { ...e, sets: e.sets.map((s, j) => (j === setIndex ? { ...s, ...patch } : s)) } : e,
      ),
    }));

  const completeSet = (setIndex: number) => {
    patchSet(active.cursor.exercise, setIndex, { done: true });
    rest.start(currentEx.restSec);
  };

  const mmss = (s: number) => `${Math.floor(s / 60)}:${String(s % 60).padStart(2, "0")}`;

  return (
    <div className="min-h-screen pb-[max(env(safe-area-inset-bottom),1.5rem)]">
      <header className="sticky top-0 z-20 border-b border-border/70 bg-background/95 px-5 pt-[max(env(safe-area-inset-top),0.9rem)] pb-3 backdrop-blur">
        <div className="flex items-center justify-between gap-3">
          <button
            type="button"
            onClick={() => {
              cancelSession();
              navigate({ to: "/workout" });
            }}
            className="flex h-10 w-10 items-center justify-center rounded-full bg-muted"
            aria-label="Discard session"
          >
            <X className="h-5 w-5" />
          </button>
          <div className="min-w-0 text-center">
            <p className="truncate text-[14.5px] font-bold tracking-tight">{active.title}</p>
            <p className="text-[12px] text-muted-foreground">
              {mmss(elapsed)} · {done}/{total} sets
            </p>
          </div>
          <button
            type="button"
            onClick={() => {
              finishSession();
              navigate({ to: "/workout" });
            }}
            className="flex h-10 w-10 items-center justify-center rounded-full bg-primary text-primary-foreground"
            aria-label="Finish session"
          >
            <Flag className="h-4.5 w-4.5" />
          </button>
        </div>
        <div className="mt-3 h-1.5 w-full overflow-hidden rounded-full bg-muted">
          <div
            className="h-full rounded-full bg-primary transition-all"
            style={{ width: `${total ? (done / total) * 100 : 0}%` }}
          />
        </div>
      </header>

      {rest.remaining > 0 && (
        <div className="mx-5 mt-4 flex items-center justify-between rounded-[1.35rem] bg-primary-soft px-5 py-3.5">
          <span className="flex items-center gap-2 text-[13.5px] font-bold text-accent-foreground">
            <Timer className="h-4 w-4" /> Rest {mmss(rest.remaining)}
          </span>
          <button
            type="button"
            onClick={rest.stop}
            className="text-[13px] font-bold text-accent-foreground underline"
          >
            Skip
          </button>
        </div>
      )}

      <div className="space-y-5 px-5 pt-5">
        <div className="flex items-center gap-3.5">
          <ExerciseThumb exerciseId={currentEx.exerciseId} name={currentEx.name} />
          <div className="min-w-0">
            <p className="text-[12px] font-bold uppercase tracking-[0.08em] text-muted-foreground">
              Exercise {active.cursor.exercise + 1} of {active.exercises.length}
            </p>
            <h1 className="mt-1 text-[21px] font-extrabold leading-tight tracking-[-0.035em]">
              {currentEx.name}
            </h1>
            <p className="mt-1 text-[13px] text-muted-foreground">
              Target {currentEx.sets.length} × {currentEx.targetReps}
              {pb ? ` · best ${pb.weightKg} kg × ${pb.reps}` : ""}
            </p>
          </div>
        </div>


        {hint && (
          <SurfaceCard className="border-primary/25 bg-primary-soft/70 py-3.5">
            <p className="text-[13px] leading-relaxed">{hint}</p>
          </SurfaceCard>
        )}

        <SurfaceCard className="space-y-2.5">
          {currentEx.sets.map((s, j) => (
            <div
              key={j}
              className={cn(
                "flex items-center gap-2.5 rounded-[1.1rem] border p-2.5",
                s.done ? "border-primary/30 bg-primary-soft/50" : "border-border/70",
              )}
            >
              <span className="flex h-8 w-8 shrink-0 items-center justify-center rounded-full bg-muted text-[12.5px] font-bold">
                {j + 1}
              </span>

              <div className="flex flex-1 items-center gap-1.5">
                <button
                  type="button"
                  onClick={() => patchSet(active.cursor.exercise, j, { reps: Math.max(0, s.reps - 1) })}
                  className="flex h-8 w-8 items-center justify-center rounded-full bg-muted"
                  aria-label="Fewer reps"
                >
                  <Minus className="h-3.5 w-3.5" />
                </button>
                <span className="w-12 text-center text-[14px] font-bold tabular-nums">{s.reps}</span>
                <button
                  type="button"
                  onClick={() => patchSet(active.cursor.exercise, j, { reps: s.reps + 1 })}
                  className="flex h-8 w-8 items-center justify-center rounded-full bg-muted"
                  aria-label="More reps"
                >
                  <Plus className="h-3.5 w-3.5" />
                </button>
              </div>

              <input
                inputMode="decimal"
                value={s.weightKg ?? ""}
                onChange={(e) => {
                  const v = e.target.value.replace(/[^\d.]/g, "");
                  patchSet(active.cursor.exercise, j, { weightKg: v === "" ? null : Number(v) });
                }}
                placeholder="kg"
                className="h-9 w-16 rounded-full border border-border/70 bg-background px-3 text-center text-[13.5px] font-semibold outline-none"
                aria-label={`Weight for set ${j + 1}`}
              />

              {s.formScore != null && (
                <span className="shrink-0 text-[12px] font-bold text-accent-foreground">{s.formScore}</span>
              )}

              <button
                type="button"
                onClick={() => (s.done ? patchSet(active.cursor.exercise, j, { done: false }) : completeSet(j))}
                aria-label={s.done ? "Mark set incomplete" : "Complete set"}
                className={cn(
                  "flex h-9 w-9 shrink-0 items-center justify-center rounded-full",
                  s.done ? "bg-primary text-primary-foreground" : "bg-muted",
                )}
              >
                <Check className="h-4 w-4" strokeWidth={2.6} />
              </button>
            </div>
          ))}
        </SurfaceCard>

        <div className="flex gap-2.5">
          {exerciseMeta?.analyzer && (
            <Link
              to="/form-coach/$exerciseId"
              params={{ exerciseId: currentEx.exerciseId }}
              className="flex h-12 flex-1 items-center justify-center gap-2 rounded-full border border-border text-[15px] font-bold"
            >
              <Camera className="h-4 w-4" /> Form coach
            </Link>
          )}
          <button
            type="button"
            onClick={() =>
              updateActive((a) => ({
                ...a,
                cursor: {
                  exercise: Math.min(a.exercises.length - 1, a.cursor.exercise + 1),
                  set: 0,
                },
              }))
            }
            disabled={active.cursor.exercise >= active.exercises.length - 1}
            className="flex h-12 flex-1 items-center justify-center rounded-full bg-primary text-[15px] font-bold text-primary-foreground disabled:opacity-40"
          >
            Next exercise
          </button>
        </div>

        {active.cursor.exercise >= active.exercises.length - 1 && (
          <button
            type="button"
            onClick={() => {
              finishSession();
              navigate({ to: "/workout" });
            }}
            className="h-12 w-full rounded-full border border-border text-[15px] font-bold"
          >
            Finish workout
          </button>
        )}
      </div>
    </div>
  );
}
