import { createFileRoute, useNavigate } from "@tanstack/react-router";
import { useQueryClient } from "@tanstack/react-query";
import { useRef, useState } from "react";
import { Activity, Camera, ChevronRight, Loader2, LogOut, RotateCcw } from "lucide-react";
import { WellcareAvatar } from "@/components/wellcare/Avatar";
import { squareDataUrl, uploadAvatar } from "@/lib/wellcare/avatar";
import { saveProfile } from "@/lib/wellcare/profile.functions";
import { SurfaceCard, SectionHeader } from "@/components/wellcare/Card";
import { supabase } from "@/integrations/supabase/client";
import { useWellcare } from "@/lib/wellcare/store";

export const Route = createFileRoute("/profile")({
  head: () => ({
    meta: [
      { title: "Profile - Wellcare AI" },
      {
        name: "description",
        content: "Your goals, daily targets, activity connections and Wellcare AI account settings.",
      },
      { property: "og:title", content: "Profile - Wellcare AI" },
      { property: "og:description", content: "Goals, daily targets and account settings." },
    ],
  }),
  component: ProfileScreen,
});

const GOAL_LABEL: Record<string, string> = {
  lose_weight: "Lose weight",
  gain_muscle: "Gain muscle",
  maintain_weight: "Maintain weight",
  build_strength: "Build strength",
  improve_fitness: "Improve fitness",
  improve_health: "Improve overall health",
};

function ProfileScreen() {
  const navigate = useNavigate();
  const queryClient = useQueryClient();
  const { profile, signedIn, updateProfile, resetAll } = useWellcare();
  const targets = profile.targets;
  const fileRef = useRef<HTMLInputElement | null>(null);
  const [avatarBusy, setAvatarBusy] = useState(false);
  const [avatarError, setAvatarError] = useState<string | null>(null);

  async function onPickAvatar(file: File | undefined) {
    if (!file) return;
    setAvatarError(null);
    setAvatarBusy(true);
    try {
      const dataUrl = await squareDataUrl(file);
      updateProfile({ avatarLocal: dataUrl });
      if (signedIn) {
        const path = await uploadAvatar(dataUrl);
        if (path) {
          const next = { ...profile, avatarLocal: dataUrl, avatarPath: path };
          updateProfile({ avatarPath: path });
          try {
            await saveProfile({ data: next });
          } catch {
            /* it stays on the device and re-syncs on the next save */
          }
        }
      }
    } catch {
      setAvatarError("That image didn't work. Try another one.");
    } finally {
      setAvatarBusy(false);
    }
  }

  async function signOut() {
    await queryClient.cancelQueries();
    queryClient.clear();
    await supabase.auth.signOut();
    void navigate({ to: "/welcome", replace: true });
  }

  /** Connections now live on their own screen, with real permissions and sync. */


  return (
    <div className="space-y-6 px-5 pt-[max(env(safe-area-inset-top),1.25rem)]">
      <header className="flex items-center gap-4 pt-3">
        <input
          ref={fileRef}
          type="file"
          accept="image/*"
          className="hidden"
          onChange={(e) => {
            void onPickAvatar(e.target.files?.[0]);
            e.target.value = "";
          }}
        />
        <button
          type="button"
          onClick={() => fileRef.current?.click()}
          aria-label="Change your profile photo"
          className="relative shrink-0 rounded-full transition-transform active:scale-[0.97]"
        >
          <WellcareAvatar
            name={profile.firstName}
            path={profile.avatarPath}
            local={profile.avatarLocal}
            className="h-16 w-16"
            textClassName="text-[22px]"
          />
          <span className="absolute -bottom-0.5 -right-0.5 flex h-6 w-6 items-center justify-center rounded-full border-2 border-background bg-primary text-primary-foreground">
            {avatarBusy ? (
              <Loader2 className="h-3 w-3 animate-spin" />
            ) : (
              <Camera className="h-3 w-3" strokeWidth={2.4} />
            )}
          </span>
        </button>
        <div className="min-w-0">
          <h1 className="truncate text-[24px] font-extrabold tracking-[-0.035em]">
            {profile.firstName || "Your profile"}
          </h1>
          <p className="mt-0.5 text-[13px] text-muted-foreground">
            {avatarError ?? (signedIn ? "Synced to your account" : "Saved on this device only")}
          </p>
        </div>
      </header>

      <button
        type="button"
        onClick={() => navigate({ to: "/edit-profile" })}
        className="flex w-full items-center gap-3 rounded-[1.25rem] border border-border/70 bg-card px-5 py-4 text-left"
      >
        <span className="min-w-0 flex-1">
          <span className="block text-[14.5px] font-bold tracking-tight">Edit your details</span>
          <span className="block text-[12.5px] text-muted-foreground">
            Weight, goal, activity - targets recalculate
          </span>
        </span>
        <ChevronRight className="h-4 w-4 shrink-0 text-muted-foreground" />
      </button>

      <div>
        <SectionHeader title="Daily targets" />

        <SurfaceCard className="divide-y divide-border/70 p-0">
          {[
            ["Calories", targets ? `${targets.calories.toLocaleString()} kcal` : "Not set"],
            ["Protein", targets ? `${targets.protein} g` : "Not set"],
            ["Carbs", targets ? `${targets.carbs} g` : "Not set"],
            ["Fat", targets ? `${targets.fat} g` : "Not set"],
            ["Water", `${(profile.waterTargetMl / 1000).toFixed(1)} L`],
          ].map(([label, value]) => (
            <div key={label} className="flex items-center justify-between px-5 py-4">
              <span className="text-[13.5px] font-medium text-muted-foreground">{label}</span>
              <span className="text-[15px] font-bold tracking-tight">{value}</span>
            </div>
          ))}
        </SurfaceCard>
      </div>

      <div>
        <SectionHeader title="Your setup" />
        <SurfaceCard className="divide-y divide-border/70 p-0">
          {[
            ["Goal", profile.goal ? (GOAL_LABEL[profile.goal] ?? "Not set") : "Not set"],
            ["Activity level", profile.activityLevel?.replace("_", " ") ?? "Not set"],
            ["Training", profile.daysPerWeek ? `${profile.daysPerWeek} days/week` : "Not set"],
            ["Diet", profile.dietType?.replace("_", " ") ?? "Not set"],
            [
              "Estimated needs",
              profile.tdeeEstimate ? `${profile.tdeeEstimate.toLocaleString()} kcal` : "Not set",
            ],
          ].map(([label, value]) => (
            <div key={label} className="flex items-center justify-between px-5 py-4">
              <span className="text-[13.5px] font-medium text-muted-foreground">{label}</span>
              <span className="text-[15px] font-bold capitalize tracking-tight">{value}</span>
            </div>
          ))}
        </SurfaceCard>
      </div>

      <div>
        <SectionHeader title="Connections" />
        <SurfaceCard className="p-0">
          <button
            type="button"
            onClick={() => navigate({ to: "/apps-devices" })}
            className="flex min-h-[4.25rem] w-full items-center gap-3 rounded-[1.75rem] px-5 py-4 text-left transition-colors active:bg-muted/60"
          >
            <span className="flex h-10 w-10 shrink-0 items-center justify-center rounded-[0.9rem] bg-muted">
              <Activity className="h-5 w-5 text-accent-foreground" strokeWidth={1.9} />
            </span>
            <span className="flex min-w-0 flex-1 flex-col justify-center">
              <span className="truncate text-[14.5px] font-bold leading-tight tracking-tight">
                Apps & Devices
              </span>
              <span className="mt-0.5 text-[12.5px] leading-snug text-muted-foreground">
                Google Health, Apple Health and trackers - permissions and sync
              </span>
            </span>
            <ChevronRight className="h-4 w-4 shrink-0 text-muted-foreground" />
          </button>

        </SurfaceCard>

      </div>

      <div className="space-y-2 pb-2">
        <button
          type="button"
          onClick={() => {
            resetAll();
            void navigate({ to: "/onboarding", replace: true });
          }}
          className="flex h-13 w-full items-center gap-3 rounded-[1.25rem] border border-border/70 bg-card px-5 py-4 text-[14.5px] font-bold"
        >
          <RotateCcw className="h-4.5 w-4.5 text-muted-foreground" />
          Redo setup
        </button>

        {signedIn ? (
          <button
            type="button"
            onClick={signOut}
            className="flex h-13 w-full items-center gap-3 rounded-[1.25rem] border border-border/70 bg-card px-5 py-4 text-[14.5px] font-bold text-destructive"
          >
            <LogOut className="h-4.5 w-4.5" />
            Sign out
          </button>
        ) : (
          <button
            type="button"
            onClick={() => navigate({ to: "/welcome" })}
            className="flex h-13 w-full items-center gap-3 rounded-[1.25rem] bg-primary px-5 py-4 text-[14.5px] font-bold text-primary-foreground"
          >
            Sign in to sync your data
          </button>
        )}
      </div>
    </div>
  );
}
