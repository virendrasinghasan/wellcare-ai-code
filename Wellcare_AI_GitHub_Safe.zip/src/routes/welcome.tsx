import { createFileRoute, useNavigate } from "@tanstack/react-router";
import { useState } from "react";
import { Loader2, TerminalSquare } from "lucide-react";
import { supabase } from "@/integrations/supabase/client";
import { PrimaryButton, inputClass } from "@/components/wellcare/onboarding-ui";
import { cn } from "@/lib/utils";
import { useWellcare } from "@/lib/wellcare/store";
import { demoLogin } from "@/lib/wellcare/demo/demo.functions";
import wellcareIcon from "@/assets/wellcare-icon.svg";


export const Route = createFileRoute("/welcome")({
  head: () => ({
    meta: [
      { title: "Welcome - Wellcare AI" },
      {
        name: "description",
        content:
          "Create your Wellcare AI account or explore first. Personalized nutrition targets, training and an AI coach that tells it straight.",
      },
      { property: "og:title", content: "Welcome to Wellcare AI" },
      {
        property: "og:description",
        content: "Sign up, log in, or look around first - your setup is saved either way.",
      },
    ],
  }),
  component: WelcomeScreen,
});

type Mode = "signup" | "login";

function WelcomeScreen() {
  const navigate = useNavigate();
  const { profile, resetAll } = useWellcare();

  /** Returning users keep their setup; new users go through onboarding. */
  const proceed = () =>
    navigate({ to: profile.onboardingCompleted ? "/" : "/onboarding", replace: true });
  const [mode, setMode] = useState<Mode>("signup");
  const [email, setEmail] = useState("");
  const [password, setPassword] = useState("");
  const [busy, setBusy] = useState(false);
  const [message, setMessage] = useState<string | null>(null);
  const [error, setError] = useState<string | null>(null);

  async function submit(e: React.FormEvent) {
    e.preventDefault();
    setBusy(true);
    setError(null);
    setMessage(null);
    try {
      if (mode === "signup") {
        const { data, error: err } = await supabase.auth.signUp({
          email,
          password,
          options: { emailRedirectTo: window.location.origin },
        });
        if (err) throw err;
        if (!data.session) {
          setMessage("Check your email to confirm your account. You can keep going meanwhile.");
          return;
        }
      } else {
        const { error: err } = await supabase.auth.signInWithPassword({ email, password });
        if (err) throw err;
      }
      proceed();
    } catch (err) {
      setError(err instanceof Error ? err.message : "Something went wrong. Try again.");
    } finally {
      setBusy(false);
    }
  }

  /**
   * Google returns to the app root, not a protected route, so the session is
   * hydrated before anything gated renders.
   */
  async function continueWithGoogle() {
    setBusy(true);
    setError(null);
    setMessage(null);
    try {
      const { error: err } = await supabase.auth.signInWithOAuth({
        provider: "google",
        options: { redirectTo: window.location.origin },
      });
      if (err) throw err;
    } catch (err) {
      setError(
        err instanceof Error
          ? `Google sign-in didn't start: ${err.message}`
          : "Google sign-in didn't start. Try again.",
      );
      setBusy(false);
  }

  /**
   * Developer Login: the server creates/seeds the shared demo account and
   * hands back a normal Supabase session. No credentials live in this bundle.
   * A full reload lets the store rehydrate from the demo account's own rows.
   */
  async function developerLogin() {
    setBusy(true);
    setError(null);
    setMessage("Preparing the demo account...");
    try {
      const session = await demoLogin();
      resetAll();
      const { error: err } = await supabase.auth.setSession(session);
      if (err) throw err;
      window.location.replace("/");
    } catch (err) {
      setError(
        err instanceof Error ? `Demo login failed: ${err.message}` : "Demo login failed.",
      );
      setMessage(null);
      setBusy(false);
    }
  }


  }


  return (
    <div className="flex min-h-screen flex-col bg-background px-5 pb-[max(env(safe-area-inset-bottom),1.25rem)] pt-[max(env(safe-area-inset-top),1rem)]">
      <div className="flex justify-end py-2">
        <button
          type="button"
          onClick={proceed}
          className="rounded-full px-3 py-2 text-[13px] font-semibold text-muted-foreground underline-offset-4 transition-colors active:text-foreground"
        >
          Skip for now
        </button>
      </div>

      <div className="pt-6">
        <img src={wellcareIcon} alt="Wellcare AI" className="h-14 w-14" />
        <h1 className="mt-6 text-[30px] font-extrabold leading-[1.1] tracking-[-0.035em]">
          Your health, <br />
          without the guesswork.
        </h1>
        <p className="mt-3 text-[14px] leading-relaxed text-muted-foreground">
          Real targets from your own numbers, honest coaching, and a log that takes seconds.
        </p>
      </div>

      <div className="mt-8 inline-flex self-start rounded-full bg-muted p-1">
        {(["signup", "login"] as Mode[]).map((m) => (
          <button
            key={m}
            type="button"
            onClick={() => setMode(m)}
            className={cn(
              "rounded-full px-5 py-2 text-[13px] font-bold transition-colors",
              mode === m
                ? "bg-card text-foreground shadow-[var(--shadow-card)]"
                : "text-muted-foreground",
            )}
          >
            {m === "signup" ? "Sign up" : "Log in"}
          </button>
        ))}
      </div>

      <button
        type="button"
        onClick={() => void continueWithGoogle()}
        disabled={busy}
        className="mt-5 inline-flex h-12 w-full items-center justify-center gap-2.5 rounded-full border border-border bg-card text-[14px] font-bold disabled:opacity-60"
      >
        <svg viewBox="0 0 18 18" className="h-[18px] w-[18px]" aria-hidden="true">
          <path fill="#4285F4" d="M17.64 9.2c0-.64-.06-1.25-.16-1.84H9v3.48h4.84a4.14 4.14 0 0 1-1.8 2.72v2.26h2.92c1.7-1.57 2.68-3.88 2.68-6.62Z" />
          <path fill="#34A853" d="M9 18c2.43 0 4.47-.8 5.96-2.18l-2.92-2.26c-.81.54-1.84.86-3.04.86-2.34 0-4.32-1.58-5.03-3.7H.94v2.33A9 9 0 0 0 9 18Z" />
          <path fill="#FBBC05" d="M3.97 10.72a5.41 5.41 0 0 1 0-3.44V4.95H.94a9 9 0 0 0 0 8.1l3.03-2.33Z" />
          <path fill="#EA4335" d="M9 3.58c1.32 0 2.5.45 3.44 1.35l2.58-2.58C13.46.9 11.43 0 9 0A9 9 0 0 0 .94 4.95l3.03 2.33C4.68 5.16 6.66 3.58 9 3.58Z" />
        </svg>
        Continue with Google
      </button>

      <div className="my-5 flex items-center gap-3">
        <span className="h-px flex-1 bg-border" />
        <span className="text-[11.5px] font-bold uppercase tracking-[0.08em] text-muted-foreground">
          or use email
        </span>
        <span className="h-px flex-1 bg-border" />
      </div>

      <form onSubmit={submit} className="space-y-3">

        <input
          type="email"
          required
          autoComplete="email"
          value={email}
          onChange={(e) => setEmail(e.target.value)}
          placeholder="you@email.com"
          className={inputClass}
        />
        <input
          type="password"
          required
          minLength={6}
          autoComplete={mode === "signup" ? "new-password" : "current-password"}
          value={password}
          onChange={(e) => setPassword(e.target.value)}
          placeholder="Password"
          className={inputClass}
        />

        {error && <p className="text-[13px] font-medium text-destructive">{error}</p>}
        {message && <p className="text-[13px] font-medium text-accent-foreground">{message}</p>}

        <PrimaryButton type="submit" disabled={busy} className="mt-2">
          {busy ? (
            <Loader2 className="h-5 w-5 animate-spin" />
          ) : mode === "signup" ? (
            "Create account"
          ) : (
            "Log in"
          )}
        </PrimaryButton>
      </form>

      <button
        type="button"
        onClick={() => void developerLogin()}
        disabled={busy}
        className="mt-4 inline-flex h-11 w-full items-center justify-center gap-2 rounded-full border border-dashed border-border text-[13.5px] font-bold text-muted-foreground disabled:opacity-60"
      >
        <TerminalSquare className="h-4 w-4" strokeWidth={2} />
        Developer Login (demo data)
      </button>



      <p className="mt-auto pt-8 text-center text-[12px] leading-relaxed text-muted-foreground">
        Skipping is fine - your setup is stored on this device and syncs to your account the
        moment you sign in.
      </p>
    </div>
  );
}
