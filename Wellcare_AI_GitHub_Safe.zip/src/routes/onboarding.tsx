import { createFileRoute, useNavigate } from "@tanstack/react-router";
import { useEffect, useMemo, useState } from "react";
import { Activity, Check, Moon, Footprints, ShieldCheck } from "lucide-react";
import {
  Field,
  GhostButton,
  OptionRow,
  PrimaryButton,
  SegmentedControl,
  StepShell,
  inputClass,
} from "@/components/wellcare/onboarding-ui";
import { SurfaceCard } from "@/components/wellcare/Card";
import { useWellcare } from "@/lib/wellcare/store";
import {
  resolveAgeYears,
  calculateTdee,
  cmToFtIn,
  ftInToCm,
  kgToLb,
  lbToKg,
  waterTargetMl,
} from "@/lib/wellcare/tdee";
import { detectPlatformProvider, getHealthProvider } from "@/lib/wellcare/health";
import type {
  ActivityLevel,
  DietType,
  Equipment,
  Experience,
  PrimaryGoal,
  Sex,
  WellcareProfile,
} from "@/lib/wellcare/types";

export const Route = createFileRoute("/onboarding")({
  head: () => ({
    meta: [
      { title: "Set up your plan - Wellcare AI" },
      {
        name: "description",
        content:
          "A few focused questions to build your personal calorie and macro targets, training plan and activity setup.",
      },
      { property: "og:title", content: "Set up your plan - Wellcare AI" },
      {
        property: "og:description",
        content: "Personal calorie and macro targets built from your own numbers.",
      },
    ],
  }),
  component: OnboardingScreen,
});

const TOTAL = 10;

const GOALS: { value: PrimaryGoal; label: string; description: string }[] = [
  { value: "lose_weight", label: "Lose weight", description: "Drop fat while keeping muscle." },
  { value: "gain_muscle", label: "Gain muscle", description: "Add size with a controlled surplus." },
  { value: "maintain_weight", label: "Maintain weight", description: "Hold steady, eat well." },
  { value: "build_strength", label: "Build strength", description: "Move heavier weight over time." },
  { value: "improve_fitness", label: "Improve fitness", description: "Better conditioning and stamina." },
  { value: "improve_health", label: "Improve overall health", description: "Habits, energy, bloodwork." },
];

const ACTIVITY: { value: ActivityLevel; label: string; description: string }[] = [
  { value: "sedentary", label: "Sedentary", description: "Desk job, little walking, mostly seated." },
  { value: "light", label: "Lightly active", description: "Some walking, light chores most days." },
  { value: "moderate", label: "Moderately active", description: "On your feet a fair bit, regular movement." },
  { value: "active", label: "Very active", description: "Physical job or lots of daily walking." },
  { value: "very_active", label: "Extremely active", description: "Manual labour or two-a-day training." },
];

const EXPERIENCE: { value: Experience; label: string; description: string }[] = [
  { value: "beginner", label: "Beginner", description: "New to training or coming back after a long break." },
  { value: "intermediate", label: "Intermediate", description: "A year or two of consistent lifting." },
  { value: "advanced", label: "Advanced", description: "Years in, you know your numbers." },
];

const EQUIPMENT: { value: Equipment; label: string }[] = [
  { value: "full_gym", label: "Full gym" },
  { value: "home_gym", label: "Home gym" },
  { value: "dumbbells", label: "Dumbbells" },
  { value: "bands", label: "Resistance bands" },
  { value: "bodyweight", label: "Bodyweight only" },
  { value: "other", label: "Other" },
];

const DIETS: { value: DietType; label: string }[] = [
  { value: "omnivore", label: "Omnivore" },
  { value: "vegetarian", label: "Vegetarian" },
  { value: "vegan", label: "Vegan" },
  { value: "pescatarian", label: "Pescatarian" },
  { value: "no_preference", label: "No preference" },
];

function OnboardingScreen() {
  const navigate = useNavigate();
  const { profile, completeOnboarding, hydrated } = useWellcare();
  const [step, setStep] = useState(1);
  const [draft, setDraft] = useState<WellcareProfile>(profile);

  useEffect(() => {
    if (hydrated) setDraft((d) => (d.firstName ? d : profile));
  }, [hydrated, profile]);

  const set = (patch: Partial<WellcareProfile>) => setDraft((d) => ({ ...d, ...patch }));
  const back = step > 1 ? () => setStep((s) => s - 1) : undefined;
  const next = () => setStep((s) => Math.min(TOTAL, s + 1));
  const name = draft.firstName.trim() || "you";

  const tdee = useMemo(() => {
    const age = resolveAgeYears(draft);
    if (!age || !draft.heightCm || !draft.weightKg || !draft.activityLevel || !draft.goal)
      return null;
    return calculateTdee(
      {
        sex: draft.sex ?? "other",
        ageYears: age,
        heightCm: draft.heightCm,
        weightKg: draft.weightKg,
        bodyFatPct: draft.bodyFatPct,
        activityLevel: draft.activityLevel,
      },
      draft.goal,
    );
  }, [draft]);

  async function finish() {
    if (!tdee) return;
    await completeOnboarding({
      ...draft,
      tdeeEstimate: tdee.estimate,
      tdeeMethod: tdee.method,
      targets: tdee.macros,
      waterTargetMl: draft.weightKg ? waterTargetMl(draft.weightKg) : 2500,
      onboardingCompleted: true,
    });
    void navigate({ to: "/", replace: true });
  }

  /* ---------------------------------------------------------------- */

  if (step === 1) {
    return (
      <StepShell
        step={1}
        total={TOTAL}
        title="What should we call you?"
        subtitle="First name is enough. It shows up everywhere in the app."
        footer={
          <PrimaryButton disabled={draft.firstName.trim().length < 1} onClick={next}>
            Continue
          </PrimaryButton>
        }
      >
        <input
          autoFocus
          value={draft.firstName}
          onChange={(e) => set({ firstName: e.target.value })}
          placeholder="First name"
          className={inputClass}
        />
      </StepShell>
    );
  }

  if (step === 2) {
    const ftIn = draft.heightCm ? cmToFtIn(draft.heightCm) : { ft: 5, inch: 8 };
    const canContinue = Boolean(draft.sex && resolveAgeYears(draft) && draft.heightCm && draft.weightKg);
    return (
      <StepShell
        step={2}
        total={TOTAL}
        onBack={back}
        title={`Nice to meet you, ${draft.firstName.trim() || "friend"}.`}
        subtitle="These four numbers drive every target the app gives you."
        footer={
          <PrimaryButton disabled={!canContinue} onClick={next}>
            Continue
          </PrimaryButton>
        }
      >
        <div className="space-y-6">
          <Field label="Gender">
            <div className="grid grid-cols-3 gap-2">
              {(["male", "female", "other"] as Sex[]).map((s) => (
                <button
                  key={s}
                  type="button"
                  onClick={() => set({ sex: s })}
                  className={`h-13 rounded-[1.15rem] border py-3.5 text-[14px] font-bold capitalize transition-colors ${
                    draft.sex === s
                      ? "border-primary bg-primary-soft text-accent-foreground"
                      : "border-border/70 bg-card text-muted-foreground"
                  }`}
                >
                  {s}
                </button>
              ))}
            </div>
          </Field>

          <div>
            <div className="mb-2 flex items-center justify-between">
              <span className="text-[13px] font-bold tracking-tight">Age</span>
              <SegmentedControl
                value={draft.ageMode}
                onChange={(v) => set({ ageMode: v })}
                options={[
                  { value: "age", label: "Age" },
                  { value: "birth_year", label: "Birth year" },
                ]}
              />
            </div>
            {draft.ageMode === "age" ? (
              <input
                type="number"
                inputMode="numeric"
                value={draft.ageYears ?? ""}
                onChange={(e) => set({ ageYears: e.target.value ? Number(e.target.value) : null })}
                placeholder="29"
                className={inputClass}
              />
            ) : (
              <input
                type="number"
                inputMode="numeric"
                value={draft.birthYear ?? ""}
                onChange={(e) => set({ birthYear: e.target.value ? Number(e.target.value) : null })}
                placeholder={String(new Date().getFullYear() - 29)}
                className={inputClass}
              />
            )}
            <span className="mt-1.5 block text-[12px] text-muted-foreground">
              Whichever you'd rather give. Age changes your calorie maths, nothing else.
            </span>
          </div>


          <div>
            <div className="mb-2 flex items-center justify-between">
              <span className="text-[13px] font-bold tracking-tight">Height</span>
              <SegmentedControl
                value={draft.heightUnit}
                onChange={(v) => set({ heightUnit: v })}
                options={[
                  { value: "cm", label: "cm" },
                  { value: "ftin", label: "ft/in" },
                ]}
              />
            </div>
            {draft.heightUnit === "cm" ? (
              <input
                type="number"
                inputMode="decimal"
                value={draft.heightCm ?? ""}
                onChange={(e) => set({ heightCm: e.target.value ? Number(e.target.value) : null })}
                placeholder="175"
                className={inputClass}
              />
            ) : (
              <div className="grid grid-cols-2 gap-2">
                <input
                  type="number"
                  inputMode="numeric"
                  value={draft.heightCm ? ftIn.ft : ""}
                  onChange={(e) =>
                    set({ heightCm: ftInToCm(Number(e.target.value || 0), ftIn.inch) })
                  }
                  placeholder="ft"
                  className={inputClass}
                />
                <input
                  type="number"
                  inputMode="numeric"
                  value={draft.heightCm ? ftIn.inch : ""}
                  onChange={(e) => set({ heightCm: ftInToCm(ftIn.ft, Number(e.target.value || 0)) })}
                  placeholder="in"
                  className={inputClass}
                />
              </div>
            )}
          </div>

          <div>
            <div className="mb-2 flex items-center justify-between">
              <span className="text-[13px] font-bold tracking-tight">Weight</span>
              <SegmentedControl
                value={draft.weightUnit}
                onChange={(v) => set({ weightUnit: v })}
                options={[
                  { value: "kg", label: "kg" },
                  { value: "lb", label: "lb" },
                ]}
              />
            </div>
            <input
              type="number"
              inputMode="decimal"
              value={
                draft.weightKg == null
                  ? ""
                  : draft.weightUnit === "kg"
                    ? Math.round(draft.weightKg * 10) / 10
                    : Math.round(kgToLb(draft.weightKg))
              }
              onChange={(e) => {
                const v = e.target.value ? Number(e.target.value) : null;
                set({ weightKg: v == null ? null : draft.weightUnit === "kg" ? v : lbToKg(v) });
              }}
              placeholder={draft.weightUnit === "kg" ? "72" : "160"}
              className={inputClass}
            />
          </div>

          <Field
            label="Body fat % (optional)"
            hint="Only if you actually know it. We won't guess - it unlocks a third calculation method."
          >
            <input
              type="number"
              inputMode="decimal"
              value={draft.bodyFatPct ?? ""}
              onChange={(e) => set({ bodyFatPct: e.target.value ? Number(e.target.value) : null })}
              placeholder="e.g. 18"
              className={inputClass}
            />
          </Field>
        </div>
      </StepShell>
    );
  }

  if (step === 3) {
    return (
      <StepShell
        step={3}
        total={TOTAL}
        onBack={back}
        title="What are you working toward?"
        subtitle="Pick one main goal. Tap others to add them as secondary."
        footer={
          <PrimaryButton disabled={!draft.goal} onClick={next}>
            Continue
          </PrimaryButton>
        }
      >
        <div className="space-y-2.5">
          {GOALS.map((g) => {
            const isPrimary = draft.goal === g.value;
            const isSecondary = draft.secondaryGoals.includes(g.value);
            return (
              <div key={g.value} className="relative">
                <OptionRow
                  label={g.label}
                  description={
                    isPrimary
                      ? `Primary goal · ${g.description}`
                      : isSecondary
                        ? `Secondary goal · ${g.description}`
                        : g.description
                  }
                  selected={isPrimary || isSecondary}
                  onClick={() => {
                    if (!draft.goal) return set({ goal: g.value });
                    if (isPrimary)
                      return set({
                        goal: null,
                        secondaryGoals: draft.secondaryGoals.filter((s) => s !== g.value),
                      });
                    set({
                      secondaryGoals: isSecondary
                        ? draft.secondaryGoals.filter((s) => s !== g.value)
                        : [...draft.secondaryGoals, g.value],
                    });
                  }}
                />
              </div>
            );
          })}
        </div>
      </StepShell>
    );
  }

  if (step === 4) {
    return (
      <StepShell
        step={4}
        total={TOTAL}
        onBack={back}
        title="How active is a normal day?"
        subtitle="Ignore workouts for a second - this is everything else you do."
        footer={
          <PrimaryButton disabled={!draft.activityLevel} onClick={next}>
            Continue
          </PrimaryButton>
        }
      >
        <div className="space-y-2.5">
          {ACTIVITY.map((a) => (
            <OptionRow
              key={a.value}
              label={a.label}
              description={a.description}
              selected={draft.activityLevel === a.value}
              onClick={() => set({ activityLevel: a.value })}
            />
          ))}
        </div>
      </StepShell>
    );
  }

  if (step === 5) {
    return (
      <StepShell
        step={5}
        total={TOTAL}
        onBack={back}
        title="How much training have you got behind you?"
        footer={
          <PrimaryButton disabled={!draft.experience || !draft.daysPerWeek} onClick={next}>
            Continue
          </PrimaryButton>
        }
      >
        <div className="space-y-2.5">
          {EXPERIENCE.map((e) => (
            <OptionRow
              key={e.value}
              label={e.label}
              description={e.description}
              selected={draft.experience === e.value}
              onClick={() => set({ experience: e.value })}
            />
          ))}
        </div>

        <div className="mt-8">
          <h2 className="text-[15px] font-bold tracking-tight">
            How many days can you realistically train each week?
          </h2>
          <p className="mt-1 text-[13px] text-muted-foreground">
            Realistically. A plan you follow beats a plan you admire.
          </p>
          <div className="mt-4 grid grid-cols-5 gap-2">
            {[2, 3, 4, 5, 6].map((d) => (
              <button
                key={d}
                type="button"
                onClick={() => set({ daysPerWeek: d })}
                className={`rounded-[1.15rem] border py-4 text-[15px] font-extrabold transition-colors ${
                  draft.daysPerWeek === d
                    ? "border-primary bg-primary-soft text-accent-foreground"
                    : "border-border/70 bg-card text-muted-foreground"
                }`}
              >
                {d === 6 ? "6+" : d}
              </button>
            ))}
          </div>
        </div>
      </StepShell>
    );
  }

  if (step === 6) {
    return (
      <StepShell
        step={6}
        total={TOTAL}
        onBack={back}
        title="What can you train with?"
        subtitle="Select everything you have access to."
        footer={
          <PrimaryButton disabled={draft.equipment.length === 0} onClick={next}>
            Continue
          </PrimaryButton>
        }
      >
        <div className="space-y-2.5">
          {EQUIPMENT.map((e) => (
            <OptionRow
              key={e.value}
              multi
              label={e.label}
              selected={draft.equipment.includes(e.value)}
              onClick={() =>
                set({
                  equipment: draft.equipment.includes(e.value)
                    ? draft.equipment.filter((x) => x !== e.value)
                    : [...draft.equipment, e.value],
                })
              }
            />
          ))}
        </div>
      </StepShell>
    );
  }

  if (step === 7) {
    return (
      <StepShell
        step={7}
        total={TOTAL}
        onBack={back}
        title="How do you eat?"
        subtitle="This shapes food suggestions later. The extras are optional."
        footer={
          <div className="space-y-1">
            <PrimaryButton disabled={!draft.dietType} onClick={next}>
              Continue
            </PrimaryButton>
            <GhostButton onClick={next}>Skip the extras</GhostButton>
          </div>
        }
      >
        <div className="space-y-2.5">
          {DIETS.map((d) => (
            <OptionRow
              key={d.value}
              label={d.label}
              selected={draft.dietType === d.value}
              onClick={() => set({ dietType: d.value })}
            />
          ))}
        </div>

        <div className="mt-7 space-y-4">
          <Field label="Allergies (optional)" hint="Comma separated.">
            <input
              value={draft.allergies.join(", ")}
              onChange={(e) =>
                set({
                  allergies: e.target.value
                    .split(",")
                    .map((s) => s.trim())
                    .filter(Boolean),
                })
              }
              placeholder="peanuts, shellfish"
              className={inputClass}
            />
          </Field>
          <Field label="Foods you avoid (optional)">
            <input
              value={draft.avoidedFoods.join(", ")}
              onChange={(e) =>
                set({
                  avoidedFoods: e.target.value
                    .split(",")
                    .map((s) => s.trim())
                    .filter(Boolean),
                })
              }
              placeholder="pork, mushrooms"
              className={inputClass}
            />
          </Field>
        </div>
      </StepShell>
    );
  }

  if (step === 8) {
    const platform = detectPlatformProvider();
    const available = getHealthProvider().isAvailable();
    return (
      <StepShell
        step={8}
        total={TOTAL}
        onBack={back}
        title="Connect your activity"
        subtitle="Wellcare can use your phone's health data to make the dashboard accurate instead of theoretical."
        footer={
          <div className="space-y-1">
            <PrimaryButton
              onClick={async () => {
                const metrics = ["steps", "activity", "sleep"] as const;
                const granted = await getHealthProvider().requestPermissions([...metrics]);
                set({
                  health: {
                    connected: granted,
                    provider: granted ? platform : null,
                    metrics: granted ? [...metrics] : [],
                  },
                });
                next();
              }}
            >
              {platform === "apple_health" ? "Connect Apple Health" : "Connect Google Fit"}
            </PrimaryButton>
            <GhostButton onClick={next}>Not now</GhostButton>
          </div>
        }
      >
        <div className="space-y-2.5">
          {[
            { icon: Footprints, label: "Steps", note: "Daily step count" },
            { icon: Activity, label: "Daily activity", note: "Active minutes and workouts" },
            { icon: Moon, label: "Sleep", note: "Duration where your device reports it" },
          ].map(({ icon: Icon, label, note }) => (
            <div
              key={label}
              className="flex items-center gap-3 rounded-[1.25rem] border border-border/70 bg-card p-4"
            >
              <span className="flex h-10 w-10 items-center justify-center rounded-[0.9rem] bg-muted">
                <Icon className="h-5 w-5 text-foreground" strokeWidth={1.8} />
              </span>
              <span>
                <span className="block text-[14px] font-bold tracking-tight">{label}</span>
                <span className="block text-[12.5px] text-muted-foreground">{note}</span>
              </span>
            </div>
          ))}
        </div>

        <div className="mt-5 flex gap-3 rounded-[1.25rem] bg-muted/70 p-4">
          <ShieldCheck className="mt-0.5 h-5 w-5 shrink-0 text-muted-foreground" />
          <p className="text-[12.5px] leading-relaxed text-muted-foreground">
            {available
              ? "Permission is requested from your device, and nothing is read until you approve it."
              : "Heads up: health data can't be read inside a browser preview. The connection is ready and switches on in the mobile build - until then the app shows real logged data only, never invented numbers."}
          </p>
        </div>
      </StepShell>
    );
  }

  if (step === 9) {
    return (
      <StepShell
        step={9}
        total={TOTAL}
        onBack={back}
        title="Your starting numbers"
        subtitle="Averaged across recognised formulas rather than one lucky guess."
        footer={<PrimaryButton onClick={next}>Looks good</PrimaryButton>}
      >
        {tdee ? (
          <div className="space-y-4">
            <SurfaceCard>
              <p className="text-[12px] font-bold uppercase tracking-[0.08em] text-muted-foreground">
                Estimated daily needs
              </p>
              <p className="mt-1 text-[40px] leading-none text-metric">
                {tdee.estimate.toLocaleString()}
                <span className="ml-1.5 text-[15px] font-bold text-muted-foreground">kcal/day</span>
              </p>
              <div className="mt-4 space-y-1.5 border-t border-border/70 pt-4">
                {tdee.methods.map((m) => (
                  <div key={m.key} className="flex items-center justify-between text-[13px]">
                    <span className="text-muted-foreground">{m.label}</span>
                    <span className="font-bold tabular-nums">{m.tdee.toLocaleString()} kcal</span>
                  </div>
                ))}
                {tdee.methods.length < 3 && (
                  <p className="pt-2 text-[12px] leading-relaxed text-muted-foreground">
                    Katch-McArdle needs a body fat percentage. You didn't give one, so we left it
                    out rather than invent it.
                  </p>
                )}
              </div>
            </SurfaceCard>

            <SurfaceCard className="border-primary/30 bg-primary-soft/70">
              <p className="text-[12px] font-bold uppercase tracking-[0.08em] text-accent-foreground">
                Suggested target
              </p>
              <p className="mt-1 text-[40px] leading-none text-metric">
                {tdee.target.toLocaleString()}
                <span className="ml-1.5 text-[15px] font-bold text-muted-foreground">kcal/day</span>
              </p>
              <div className="mt-4 grid grid-cols-3 gap-3 border-t border-primary/20 pt-4">
                {[
                  ["Protein", tdee.macros.protein],
                  ["Carbs", tdee.macros.carbs],
                  ["Fat", tdee.macros.fat],
                ].map(([label, value]) => (
                  <div key={String(label)}>
                    <p className="text-[12px] font-semibold text-muted-foreground">{label}</p>
                    <p className="mt-0.5 text-[19px] text-metric">{value}g</p>
                  </div>
                ))}
              </div>
            </SurfaceCard>

            <p className="px-1 text-[12.5px] leading-relaxed text-muted-foreground">
              This is a starting estimate, not a medical measurement. Wellcare adjusts the
              recommendation as your real progress comes in.
            </p>
          </div>
        ) : (
          <p className="text-[14px] text-muted-foreground">
            Some details are missing - go back a couple of steps and fill them in.
          </p>
        )}
      </StepShell>
    );
  }

  return (
    <StepShell
      step={10}
      total={TOTAL}
      onBack={back}
      title={`You're all set, ${name}.`}
      subtitle="Everything below is editable later from your profile."
      footer={<PrimaryButton onClick={finish}>Let's get started</PrimaryButton>}
    >
      <SurfaceCard className="divide-y divide-border/70 p-0">
        {[
          ["Goal", GOALS.find((g) => g.value === draft.goal)?.label ?? "Not set"],
          ["Daily target", tdee ? `${tdee.target.toLocaleString()} kcal` : "Not set"],
          ["Protein", tdee ? `${tdee.macros.protein}g` : "Not set"],
          ["Carbs", tdee ? `${tdee.macros.carbs}g` : "Not set"],
          ["Fat", tdee ? `${tdee.macros.fat}g` : "Not set"],
          ["Training", draft.daysPerWeek ? `${draft.daysPerWeek} days/week` : "Not set"],
          [
            "Activity data",
            draft.health.connected ? "Connected" : "Not connected",
          ],
        ].map(([label, value]) => (
          <div key={label} className="flex items-center justify-between px-5 py-4">
            <span className="text-[13.5px] font-medium text-muted-foreground">{label}</span>
            <span className="text-[15px] font-bold tracking-tight">{value}</span>
          </div>
        ))}
      </SurfaceCard>

      <div className="mt-5 flex items-start gap-3 rounded-[1.25rem] bg-muted/70 p-4">
        <Check className="mt-0.5 h-5 w-5 shrink-0 text-primary" strokeWidth={2.5} />
        <p className="text-[12.5px] leading-relaxed text-muted-foreground">
          Saved on this device. If you signed in, it's already on your account - if you skipped, it
          syncs the moment you do.
        </p>
      </div>
    </StepShell>
  );
}
