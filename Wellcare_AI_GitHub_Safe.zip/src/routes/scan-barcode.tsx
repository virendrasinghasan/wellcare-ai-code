import { createFileRoute, Link, useNavigate } from "@tanstack/react-router";
import { useCallback, useEffect, useRef, useState } from "react";
import {
  ChevronLeft,
  ScanBarcode,
  Loader2,
  Sparkles,
  Flashlight,
  FlashlightOff,
} from "lucide-react";

import { SurfaceCard } from "@/components/wellcare/Card";
import { PrimaryButton } from "@/components/wellcare/onboarding-ui";
import { useWellcare } from "@/lib/wellcare/store";
import {
  focusAt,
  openRearCamera,
  readCapabilities,
  setTorch,
  setZoom,
  stopStream,
  tuneForCloseUp,
  type CameraCapabilities,
} from "@/lib/wellcare/camera";
import { lookupBarcode } from "@/lib/wellcare/food/barcode.functions";
import type { NormalizedFood } from "@/lib/wellcare/food/barcode.server";
import type { MealType } from "@/lib/wellcare/types";


const SOURCE_LABEL: Record<NormalizedFood["source"], string> = {
  cache: "Wellcare catalogue",
  off: "Open Food Facts",
  usda: "USDA",
};

export const Route = createFileRoute("/scan-barcode")({
  head: () => ({
    meta: [
      { title: "Scan a barcode - Wellcare AI" },
      {
        name: "description",
        content:
          "Scan a packaged food barcode and log accurate calories and macros straight into your Wellcare diary.",
      },
      { property: "og:title", content: "Scan a barcode - Wellcare AI" },
      { property: "og:description", content: "Barcode food logging with real nutrition data." },
    ],
  }),
  component: ScanBarcodeScreen,
});

type Stage = "idle" | "scanning" | "denied" | "looking" | "found" | "missing";

const MEALS: MealType[] = ["breakfast", "lunch", "dinner", "snack"];

/** Rounds to one decimal for display and logging. */
const r1 = (n: number) => Math.round(n * 10) / 10;

function ScanBarcodeScreen() {
  const navigate = useNavigate();
  const { addEntry } = useWellcare();
  const videoRef = useRef<HTMLVideoElement | null>(null);
  const controlsRef = useRef<{ stop: () => void } | null>(null);
  const streamRef = useRef<MediaStream | null>(null);

  const [stage, setStage] = useState<Stage>("idle");
  const [code, setCode] = useState("");
  const [food, setFood] = useState<NormalizedFood | null>(null);
  const [message, setMessage] = useState<string | null>(null);
  const [servings, setServings] = useState(1);
  const [meal, setMeal] = useState<MealType>("snack");
  const [caps, setCaps] = useState<CameraCapabilities | null>(null);
  const [zoomValue, setZoomValue] = useState(1);
  const [torchOn, setTorchOn] = useState(false);
  const [focusDot, setFocusDot] = useState<{ x: number; y: number } | null>(null);

  const stopScanner = useCallback(() => {
    controlsRef.current?.stop();
    controlsRef.current = null;
    stopStream(streamRef.current);
    streamRef.current = null;
    setCaps(null);
    setTorchOn(false);

  }, []);

  useEffect(() => stopScanner, [stopScanner]);

  const resolve = useCallback(
    async (barcode: string) => {
      stopScanner();
      setCode(barcode);
      setStage("looking");
      setMessage(null);

      // Catalogue first, then Open Food Facts, then USDA. All server-side,
      // so it works signed out and every new product gets cached for later.
      try {
        const result = await lookupBarcode({ data: { barcode } });
        if (result.found && result.food) {
          setFood(result.food);
          setServings(1);
          setStage("found");
          return;
        }
        setMessage(result.message);
        setStage("missing");
      } catch {
        setMessage("I couldn't reach the food databases just now. Type the label numbers in instead.");
        setStage("missing");
      }
    },
    [stopScanner],
  );

  const startScanner = useCallback(async () => {
    setStage("scanning");
    setMessage(null);
    try {
      const video = videoRef.current;
      if (!video) return;

      const stream = await openRearCamera(video);
      streamRef.current = stream;
      await tuneForCloseUp(stream);
      const capabilities = readCapabilities(stream);
      setCaps(capabilities);
      setZoomValue(capabilities.zoom ? capabilities.zoom.min : 1);
      setTorchOn(false);

      const onHit = (raw: string) => {
        const text = raw.replace(/\D/g, "");
        if (text.length >= 6) void resolve(text);
      };

      // Native detector first (fast and sharp on Android), ZXing everywhere else.
      const Detector = (window as unknown as { BarcodeDetector?: new (o?: unknown) => {
        detect: (source: CanvasImageSource) => Promise<{ rawValue: string }[]>;
      } }).BarcodeDetector;

      if (Detector) {
        const detector = new Detector({
          formats: ["ean_13", "ean_8", "upc_a", "upc_e", "code_128", "itf"],
        });
        let alive = true;
        const tick = async () => {
          if (!alive || !videoRef.current) return;
          try {
            const hits = await detector.detect(videoRef.current);
            if (hits[0]?.rawValue) {
              onHit(hits[0].rawValue);
              return;
            }
          } catch {
            /* a dropped frame is not a failure */
          }
          if (alive) window.setTimeout(tick, 180);
        };
        void tick();
        controlsRef.current = {
          stop: () => {
            alive = false;
          },
        };
        return;
      }

      const { BrowserMultiFormatReader } = await import("@zxing/browser");
      const { DecodeHintType, BarcodeFormat } = await import("@zxing/library");

      const hints = new Map();
      hints.set(DecodeHintType.POSSIBLE_FORMATS, [
        BarcodeFormat.EAN_13,
        BarcodeFormat.EAN_8,
        BarcodeFormat.UPC_A,
        BarcodeFormat.UPC_E,
        BarcodeFormat.CODE_128,
        BarcodeFormat.ITF,
      ]);
      hints.set(DecodeHintType.TRY_HARDER, true);

      const reader = new BrowserMultiFormatReader(hints, { delayBetweenScanAttempts: 120 });
      const controls = await reader.decodeFromStream(stream, video, (result) => {
        if (result) onHit(result.getText());
      });
      controlsRef.current = controls;
    } catch (err) {
      const name = (err as { name?: string })?.name;
      setStage(name === "NotAllowedError" ? "denied" : "idle");
      if (name !== "NotAllowedError") {
        setMessage("The camera scanner won't start on this device. Enter the barcode by hand.");
      }
    }
  }, [resolve]);

  const handleTapFocus = useCallback((e: React.MouseEvent<HTMLDivElement>) => {
    const stream = streamRef.current;
    if (!stream) return;
    const rect = e.currentTarget.getBoundingClientRect();
    const x = (e.clientX - rect.left) / rect.width;
    const y = (e.clientY - rect.top) / rect.height;
    setFocusDot({ x: e.clientX - rect.left, y: e.clientY - rect.top });
    window.setTimeout(() => setFocusDot(null), 900);
    void focusAt(stream, x, y);
  }, []);


  const logIt = () => {
    if (!food) return;
    addEntry({
      meal,
      name: food.brand ? `${food.brand} ${food.name}` : food.name,
      calories: Math.round(food.calories * servings),
      protein: r1(food.protein * servings),
      carbs: r1(food.carbs * servings),
      fat: r1(food.fat * servings),
    });
    navigate({ to: "/nutrition" });
  };

  return (
    <div className="space-y-5 px-5 pt-[max(env(safe-area-inset-top),1.25rem)]">
      <button
        type="button"
        onClick={() => {
          stopScanner();
          navigate({ to: "/explore" });
        }}
        className="flex h-10 w-10 items-center justify-center rounded-full bg-muted"
        aria-label="Back"
      >
        <ChevronLeft className="h-5 w-5" />
      </button>

      <header>
        <h1 className="text-[26px] font-extrabold tracking-[-0.03em]">Scan a barcode</h1>
        <p className="mt-2 text-[14px] text-muted-foreground">
          Point at the barcode on the packet. I check our database, then Open Food Facts, then USDA.
        </p>
      </header>

      {stage === "found" && food ? (
        <SurfaceCard className="space-y-4">
          <div className="flex gap-3">
            {food.imageUrl && (
              <img
                src={food.imageUrl}
                alt={food.name}
                loading="lazy"
                className="h-16 w-16 shrink-0 rounded-[1rem] object-cover"
              />
            )}
            <div className="min-w-0">
              <p className="text-[16px] font-bold leading-tight tracking-tight">{food.name}</p>
              <p className="mt-0.5 text-[12.5px] text-muted-foreground">
                {food.brand ? `${food.brand} · ` : ""}
                {food.servingLabel} · {SOURCE_LABEL[food.source]}
              </p>
            </div>
          </div>

          <div className="grid grid-cols-4 gap-2 text-center">
            {[
              ["kcal", Math.round(food.calories * servings)],
              ["protein", `${r1(food.protein * servings)}g`],
              ["carbs", `${r1(food.carbs * servings)}g`],
              ["fat", `${r1(food.fat * servings)}g`],
            ].map(([label, value]) => (
              <div key={label as string} className="rounded-[1rem] bg-muted py-2.5">
                <p className="text-[14.5px] font-bold tabular-nums">{value as string}</p>
                <p className="text-[11px] text-muted-foreground">{label}</p>
              </div>
            ))}
          </div>

          <div>
            <p className="mb-2 text-[12.5px] font-semibold text-muted-foreground">Servings</p>
            <div className="flex gap-2">
              {[0.5, 1, 1.5, 2].map((s) => (
                <button
                  key={s}
                  type="button"
                  onClick={() => setServings(s)}
                  className={`h-10 flex-1 rounded-full text-[13.5px] font-bold ${
                    servings === s ? "bg-primary text-primary-foreground" : "bg-muted"
                  }`}
                >
                  {s}
                </button>
              ))}
            </div>
          </div>

          <div>
            <p className="mb-2 text-[12.5px] font-semibold text-muted-foreground">Meal</p>
            <div className="flex gap-2">
              {MEALS.map((m) => (
                <button
                  key={m}
                  type="button"
                  onClick={() => setMeal(m)}
                  className={`h-10 flex-1 rounded-full text-[12.5px] font-bold capitalize ${
                    meal === m ? "bg-primary text-primary-foreground" : "bg-muted"
                  }`}
                >
                  {m}
                </button>
              ))}
            </div>
          </div>

          <PrimaryButton onClick={logIt}>Log it</PrimaryButton>
          <button
            type="button"
            onClick={() => {
              setFood(null);
              setStage("idle");
            }}
            className="w-full text-[13.5px] font-semibold text-muted-foreground"
          >
            Scan something else
          </button>
        </SurfaceCard>
      ) : (
        <div className="space-y-3">
          <div
            onClick={stage === "scanning" ? handleTapFocus : undefined}
            className="relative aspect-[4/3] w-full overflow-hidden rounded-[1.75rem] border border-border bg-muted/60"
          >
            <video ref={videoRef} playsInline muted className="h-full w-full object-cover" />
            {stage !== "scanning" && (
              <div className="absolute inset-0 flex flex-col items-center justify-center gap-3 bg-muted/80 px-8 text-center">
                {stage === "looking" ? (
                  <>
                    <Loader2 className="h-7 w-7 animate-spin text-muted-foreground" />
                    <p className="text-[13px] text-muted-foreground">Looking up {code}…</p>
                  </>
                ) : (
                  <>
                    <ScanBarcode className="h-10 w-10 text-muted-foreground" strokeWidth={1.5} />
                    <p className="text-[13px] text-muted-foreground">
                      {stage === "denied"
                        ? "Camera access is blocked. Allow it in your browser settings, or type the barcode below."
                        : (message ?? "Tap start and hold the barcode steady in the frame.")}
                    </p>
                    <button
                      type="button"
                      onClick={startScanner}
                      className="h-11 rounded-full bg-primary px-6 text-[14px] font-bold text-primary-foreground"
                    >
                      Start scanner
                    </button>
                  </>
                )}
              </div>
            )}
            {stage === "scanning" && (
              <>
                {/* Dimmed surround with a clear cut-out window over the barcode. */}
                <div className="pointer-events-none absolute inset-0">
                  <div className="absolute inset-x-0 top-0 h-[calc(50%-3.5rem)] bg-foreground/45" />
                  <div className="absolute inset-x-0 bottom-0 h-[calc(50%-3.5rem)] bg-foreground/45" />
                  <div className="absolute inset-y-[calc(50%-3.5rem)] left-0 w-6 bg-foreground/45" />
                  <div className="absolute inset-y-[calc(50%-3.5rem)] right-0 w-6 bg-foreground/45" />
                </div>
                <div className="pointer-events-none absolute inset-x-6 top-1/2 h-28 -translate-y-1/2 rounded-[1.25rem] ring-2 ring-background/90">
                  <span className="absolute left-0 top-0 h-7 w-7 rounded-tl-[1.25rem] border-l-4 border-t-4 border-primary" />
                  <span className="absolute right-0 top-0 h-7 w-7 rounded-tr-[1.25rem] border-r-4 border-t-4 border-primary" />
                  <span className="absolute bottom-0 left-0 h-7 w-7 rounded-bl-[1.25rem] border-b-4 border-l-4 border-primary" />
                  <span className="absolute bottom-0 right-0 h-7 w-7 rounded-br-[1.25rem] border-b-4 border-r-4 border-primary" />
                </div>
                {focusDot && (
                  <span
                    className="pointer-events-none absolute h-14 w-14 -translate-x-1/2 -translate-y-1/2 rounded-full border-2 border-primary"
                    style={{ left: focusDot.x, top: focusDot.y }}
                  />
                )}
                {caps?.torch && (
                  <button
                    type="button"
                    onClick={(e) => {
                      e.stopPropagation();
                      const next = !torchOn;
                      setTorchOn(next);
                      void setTorch(streamRef.current, next);
                    }}
                    aria-label={torchOn ? "Turn the light off" : "Turn the light on"}
                    className="absolute right-3 top-3 flex h-10 w-10 items-center justify-center rounded-full bg-background/85"
                  >
                    {torchOn ? (
                      <FlashlightOff className="h-4.5 w-4.5" />
                    ) : (
                      <Flashlight className="h-4.5 w-4.5" />
                    )}
                  </button>
                )}
                <p className="pointer-events-none absolute inset-x-0 bottom-4 text-center text-[12.5px] font-semibold text-background">
                  Tap the barcode to focus, hold it inside the frame
                </p>
              </>
            )}
          </div>

          {stage === "scanning" && caps?.zoom && (
            <div className="flex items-center gap-3 px-1">
              <span className="text-[12px] font-semibold text-muted-foreground">Zoom</span>
              <input
                type="range"
                min={caps.zoom.min}
                max={caps.zoom.max}
                step={caps.zoom.step}
                value={zoomValue}
                aria-label="Camera zoom"
                onChange={(e) => {
                  const v = Number(e.target.value);
                  setZoomValue(v);
                  void setZoom(streamRef.current, v);
                }}
                className="h-1.5 flex-1 accent-[var(--primary)]"
              />
            </div>
          )}
        </div>
      )}


      {stage !== "found" && (
        <form
          onSubmit={(e) => {
            e.preventDefault();
            const digits = code.replace(/\D/g, "");
            if (digits.length >= 6) void resolve(digits);
          }}
          className="flex gap-2"
        >
          <input
            value={code}
            onChange={(e) => setCode(e.target.value)}
            inputMode="numeric"
            maxLength={14}
            placeholder="Type the barcode number"
            aria-label="Barcode number"
            className="h-12 flex-1 rounded-full border border-border/70 bg-card px-4 text-[14px] outline-none"
          />
          <button
            type="submit"
            className="h-12 rounded-full bg-primary px-5 text-[14px] font-bold text-primary-foreground"
          >
            Find
          </button>
        </form>
      )}

      <SurfaceCard className="border-primary/25 bg-primary-soft/70">
        <div className="flex gap-3">
          <Sparkles className="mt-0.5 h-5 w-5 shrink-0 text-accent-foreground" />
          <p className="text-[13px] leading-relaxed">
            Barcodes are only as honest as the label. If the numbers look wrong, trust the packet and
            edit it manually.
          </p>
        </div>
      </SurfaceCard>

      <Link to="/add-food" className="block pb-4">
        <PrimaryButton>Add food manually</PrimaryButton>
      </Link>
    </div>
  );
}
