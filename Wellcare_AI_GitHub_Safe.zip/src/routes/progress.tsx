import { createFileRoute, Link } from "@tanstack/react-router";
import { CalendarRange, ChevronRight, LineChart, Scale } from "lucide-react";
import { SurfaceCard } from "@/components/wellcare/Card";
import { useWellcare } from "@/lib/wellcare/store";
import { kgToLb } from "@/lib/wellcare/tdee";

export const Route = createFileRoute("/progress")({
  head: () => ({
    meta: [
      { title: "Progress - Wellcare AI" },
      {
        name: "description",
        content:
          "Track weight, measurements and training consistency over time and let Wellcare AI adjust your targets.",
      },
      { property: "og:title", content: "Progress - Wellcare AI" },
      { property: "og:description", content: "Weight, measurements and consistency over time." },
    ],
  }),
  component: ProgressScreen,
});

function ProgressScreen() {
  const { profile } = useWellcare();
  const weight =
    profile.weightKg == null
      ? "Not set"
      : profile.weightUnit === "kg"
        ? `${Math.round(profile.weightKg * 10) / 10} kg`
        : `${Math.round(kgToLb(profile.weightKg))} lb`;

  return (
    <div className="space-y-6 px-5 pt-[max(env(safe-area-inset-top),1.25rem)]">
      <header className="pt-3">
        <h1 className="text-[26px] font-extrabold tracking-[-0.035em]">Progress</h1>
        <p className="mt-1.5 text-[14px] text-muted-foreground">
          One data point isn't a trend. Come back with a few.
        </p>
      </header>

      <SurfaceCard>
        <div className="flex items-center gap-2 text-muted-foreground">
          <Scale className="h-[18px] w-[18px]" />
          <span className="text-[11px] font-bold uppercase tracking-[0.1em]">Starting weight</span>
        </div>
        <p className="mt-3 text-[32px] leading-none text-metric">{weight}</p>
      </SurfaceCard>

      <Link to="/history" className="block">
        <SurfaceCard className="flex items-center gap-3">
          <span className="flex h-11 w-11 items-center justify-center rounded-[1rem] bg-muted">
            <CalendarRange className="h-5 w-5 text-muted-foreground" strokeWidth={1.8} />
          </span>
          <span className="flex-1">
            <span className="block text-[15px] font-bold tracking-tight">30-day history</span>
            <span className="block text-[13px] text-muted-foreground">
              Meals, workouts, weight, water, steps and sleep by day.
            </span>
          </span>
          <ChevronRight className="h-5 w-5 text-muted-foreground" />
        </SurfaceCard>
      </Link>

      <SurfaceCard className="flex flex-col items-center py-10 text-center">
        <span className="flex h-14 w-14 items-center justify-center rounded-[1.15rem] bg-muted">
          <LineChart className="h-6 w-6 text-muted-foreground" strokeWidth={1.7} />
        </span>
        <h2 className="mt-4 text-[17px] font-bold tracking-tight">No history yet</h2>
        <p className="mt-1.5 max-w-[17rem] text-[13.5px] leading-relaxed text-muted-foreground">
          Weight check-ins, measurements and photos land here. Your targets get corrected from this
          data rather than from a formula alone.
        </p>
      </SurfaceCard>
    </div>
  );
}
