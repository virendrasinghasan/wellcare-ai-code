import { createFileRoute, Link, useParams } from "@tanstack/react-router";
import { ArrowLeft, Clock } from "lucide-react";
import { SurfaceCard } from "@/components/wellcare/Card";

export const Route = createFileRoute("/soon/$feature")({
  head: () => ({
    meta: [
      { title: "Coming soon - Wellcare AI" },
      {
        name: "description",
        content: "This part of Wellcare AI is being built. Here's what it will do when it lands.",
      },
      { property: "og:title", content: "Coming soon - Wellcare AI" },
      {
        property: "og:description",
        content: "This part of Wellcare AI is being built. Here's what it will do when it lands.",
      },
    ],
  }),
  component: SoonScreen,
});

const COPY: Record<string, { title: string; body: string }> = {
  hydration: {
    title: "Hydration",
    body: "A full water history with reminders and a weekly view. For now you can add water straight from the home screen.",
  },
  sleep: {
    title: "Sleep",
    body: "Sleep duration and recovery, pulled from your phone's health data rather than typed in by hand.",
  },
  "health-data": {
    title: "Health data",
    body: "Apple Health and Google Fit sync for steps, workouts and sleep. The permission flow exists - the native bridge doesn't run in a browser.",
  },
  habits: {
    title: "Habits",
    body: "Small daily promises with honest streaks. No confetti for showing up once.",
  },
};

function SoonScreen() {
  const { feature } = useParams({ from: "/soon/$feature" });
  const copy = COPY[feature] ?? {
    title: "Not built yet",
    body: "This screen is on the roadmap. Nothing here is faked in the meantime.",
  };

  return (
    <div className="px-5 pt-[max(env(safe-area-inset-top),1.25rem)]">
      <Link
        to="/explore"
        className="mt-3 inline-flex h-10 w-10 items-center justify-center rounded-full bg-muted"
        aria-label="Back to explore"
      >
        <ArrowLeft className="h-5 w-5" />
      </Link>

      <h1 className="mt-5 text-[26px] font-extrabold tracking-[-0.035em]">{copy.title}</h1>

      <SurfaceCard className="mt-5">
        <div className="flex items-center gap-2 text-accent-foreground">
          <Clock className="h-4 w-4" />
          <span className="text-[12px] font-bold uppercase tracking-[0.08em]">In development</span>
        </div>
        <p className="mt-2 text-[14.5px] leading-relaxed text-muted-foreground">{copy.body}</p>
      </SurfaceCard>
    </div>
  );
}
