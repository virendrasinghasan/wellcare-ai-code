import { createFileRoute, Link } from "@tanstack/react-router";
import {
  Apple,
  Dumbbell,
  LineChart,
  Droplets,
  Camera,
  ScanBarcode,
  Plus,
  Moon,
  HeartPulse,
  NotebookPen,
  ChevronRight,
} from "lucide-react";
import type { LucideIcon } from "lucide-react";
import { SectionHeader } from "@/components/wellcare/Card";
import { useWellcare } from "@/lib/wellcare/store";

export const Route = createFileRoute("/explore")({
  head: () => ({
    meta: [
      { title: "Explore - Wellcare AI" },
      {
        name: "description",
        content:
          "Every part of Wellcare in one place: nutrition, training, progress, hydration, habits and logging tools.",
      },
      { property: "og:title", content: "Explore - Wellcare AI" },
      {
        property: "og:description",
        content: "Nutrition, training, progress, hydration and logging tools in one place.",
      },
    ],
  }),
  component: ExploreScreen,
});

interface Tile {
  to: string;
  label: string;
  note: string;
  icon: LucideIcon;
}

const core: Tile[] = [
  { to: "/nutrition", label: "Nutrition", note: "Meals, macros, day view", icon: Apple },
  { to: "/workout", label: "Training", note: "Plan and sessions", icon: Dumbbell },
  { to: "/progress", label: "Progress", note: "Weight and trends", icon: LineChart },
  { to: "/trackers", label: "Trackers", note: "Sleep, vitals, medicine", icon: HeartPulse },
];

const logging: Tile[] = [
  { to: "/add-food", label: "Add food", note: "Manual entry", icon: Plus },
  { to: "/scan-meal", label: "Scan a meal", note: "Photo logging", icon: Camera },
  { to: "/scan-barcode", label: "Scan barcode", note: "Packaged food", icon: ScanBarcode },
  { to: "/tracker/water", label: "Log water", note: "Hydration", icon: Droplets },
];

const upcoming: Tile[] = [
  { to: "/tracker/sleep", label: "Sleep", note: "Bedtime and rest", icon: Moon },
  { to: "/soon/health-data", label: "Health data", note: "Apple Health, Google Fit", icon: HeartPulse },
  { to: "/soon/habits", label: "Habits", note: "Daily streaks", icon: NotebookPen },
];


function TileGrid({ items }: { items: Tile[] }) {
  return (
    <div className="grid grid-cols-2 gap-3">
      {items.map(({ to, label, note, icon: Icon }) => (
        <Link
          key={to}
          to={to}
          className="rounded-[1.5rem] border border-border/70 bg-card p-4 transition-transform active:scale-[0.98]"
        >
          <span className="flex h-10 w-10 items-center justify-center rounded-full bg-primary-soft text-accent-foreground">
            <Icon className="h-[18px] w-[18px]" strokeWidth={2} />
          </span>
          <span className="mt-3 block text-[15px] font-bold tracking-tight">{label}</span>
          <span className="mt-0.5 block text-[12.5px] leading-snug text-muted-foreground">{note}</span>
        </Link>
      ))}
    </div>
  );
}

function ExploreScreen() {
  const { profile } = useWellcare();

  return (
    <div className="space-y-8 px-5 pt-[max(env(safe-area-inset-top),1.25rem)]">
      <header className="pt-3">
        <p className="text-[12px] font-bold uppercase tracking-[0.08em] text-muted-foreground">
          Explore
        </p>
        <h1 className="mt-1.5 text-[26px] font-extrabold tracking-[-0.035em]">
          Everything Wellcare does
        </h1>
      </header>

      <section>
        <SectionHeader title="Daily tracking" />
        <TileGrid items={core} />
      </section>

      <section>
        <SectionHeader title="Log something" />
        <TileGrid items={logging} />
      </section>

      <section>
        <SectionHeader title="More" />
        <TileGrid items={upcoming} />
      </section>

      <Link
        to="/profile"
        className="flex items-center gap-3 rounded-[1.5rem] border border-border/70 bg-card p-4"
      >
        <span className="flex h-11 w-11 shrink-0 items-center justify-center rounded-full bg-primary-soft text-[15px] font-extrabold text-accent-foreground">
          {(profile.firstName || "W").slice(0, 1).toUpperCase()}
        </span>
        <span className="min-w-0 flex-1">
          <span className="block truncate text-[15px] font-bold tracking-tight">
            {profile.firstName || "Your profile"}
          </span>
          <span className="block text-[12.5px] text-muted-foreground">
            Targets, units, account and data
          </span>
        </span>
        <ChevronRight className="h-4.5 w-4.5 shrink-0 text-muted-foreground" />
      </Link>
    </div>
  );
}
