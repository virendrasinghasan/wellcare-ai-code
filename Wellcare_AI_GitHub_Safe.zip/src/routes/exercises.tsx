import { createFileRoute, Link, useNavigate } from "@tanstack/react-router";
import { useMemo, useState } from "react";
import { ChevronLeft, Search, Camera, Star } from "lucide-react";
import { cn } from "@/lib/utils";
import { filterExercises, EXERCISES } from "@/lib/wellcare/workout/library";
import {
  GEAR_LABEL,
  MUSCLE_LABEL,
  PATTERN_LABEL,
  type Difficulty,
  type Gear,
  type Muscle,
  type Pattern,
} from "@/lib/wellcare/workout/types";
import { useTraining, useToggleFavorite } from "@/lib/wellcare/workout/training-store";
import { ExerciseThumb } from "@/components/wellcare/ExerciseMedia";


interface ExerciseSearch {
  camera?: boolean | undefined;
  muscle?: Muscle | undefined;
}

export const Route = createFileRoute("/exercises")({
  validateSearch: (search: Record<string, unknown>): ExerciseSearch => ({
    camera: search['camera'] === true || search['camera'] === "true" ? true : undefined,
    muscle: typeof search['muscle'] === "string" ? (search['muscle'] as Muscle) : undefined,
  }),
  head: () => ({
    meta: [
      { title: "Exercise library - Wellcare AI" },
      {
        name: "description",
        content:
          "Browse 150+ exercises by muscle group, equipment and difficulty, with form cues and camera-coached lifts.",
      },
      { property: "og:title", content: "Exercise library - Wellcare AI" },
      { property: "og:description", content: "150+ exercises with cues, mistakes and form coaching." },
    ],
  }),
  component: LibraryScreen,
});

const MUSCLES: Muscle[] = [
  "chest",
  "back",
  "shoulders",
  "biceps",
  "triceps",
  "core",
  "quadriceps",
  "hamstrings",
  "glutes",
  "calves",
  "full_body",
];
const GEARS: Gear[] = ["bodyweight", "dumbbell", "barbell", "machine", "cable", "kettlebell", "band", "pullup_bar"];
const LEVELS: Difficulty[] = ["beginner", "intermediate", "advanced"];
const PATTERNS: Pattern[] = [
  "push",
  "pull",
  "squat",
  "hinge",
  "lunge",
  "core",
  "compound",
  "isolation",
  "carry",
  "cardio",
];


function Chip({
  active,
  onClick,
  children,
}: {
  active: boolean;
  onClick: () => void;
  children: React.ReactNode;
}) {
  return (
    <button
      type="button"
      onClick={onClick}
      className={cn(
        "shrink-0 rounded-full border px-3.5 py-2 text-[12.5px] font-bold tracking-tight transition-colors",
        active
          ? "border-primary bg-primary text-primary-foreground"
          : "border-border/70 bg-card text-muted-foreground",
      )}
    >
      {children}
    </button>
  );
}

function LibraryScreen() {
  const navigate = useNavigate();
  const search = Route.useSearch();
  const { favorites } = useTraining();
  const toggleFavorite = useToggleFavorite();

  const [query, setQuery] = useState("");
  const [muscle, setMuscle] = useState<Muscle | null>(search.muscle ?? null);
  const [gear, setGear] = useState<Gear | null>(null);
  const [level, setLevel] = useState<Difficulty | null>(null);
  const [pattern, setPattern] = useState<Pattern | null>(null);
  const [cameraOnly, setCameraOnly] = useState(Boolean(search.camera));

  const results = useMemo(
    () => filterExercises({ query, muscle, gear, difficulty: level, pattern, cameraOnly }),
    [query, muscle, gear, level, pattern, cameraOnly],
  );


  return (
    <div className="space-y-4 px-5 pt-[max(env(safe-area-inset-top),1.25rem)]">
      <div className="flex items-center gap-3">
        <button
          type="button"
          onClick={() => navigate({ to: "/workout" })}
          className="flex h-10 w-10 items-center justify-center rounded-full bg-muted"
          aria-label="Back"
        >
          <ChevronLeft className="h-5 w-5" />
        </button>
        <h1 className="text-[20px] font-extrabold tracking-[-0.03em]">Exercise library</h1>
      </div>

      <label className="flex h-12 items-center gap-2.5 rounded-full border border-border/70 bg-card px-4">
        <Search className="h-4 w-4 shrink-0 text-muted-foreground" />
        <input
          value={query}
          onChange={(e) => setQuery(e.target.value)}
          placeholder={`Search ${EXERCISES.length} exercises`}
          className="w-full bg-transparent text-[14.5px] outline-none placeholder:text-muted-foreground"
        />
      </label>

      <div className="-mx-5 space-y-2 px-5">
        <div className="flex gap-2 overflow-x-auto pb-1 [scrollbar-width:none]">
          <Chip active={cameraOnly} onClick={() => setCameraOnly((v) => !v)}>
            <span className="flex items-center gap-1.5">
              <Camera className="h-3.5 w-3.5" /> Form coach
            </span>
          </Chip>
          {LEVELS.map((l) => (
            <Chip key={l} active={level === l} onClick={() => setLevel(level === l ? null : l)}>
              {l[0]!.toUpperCase() + l.slice(1)}
            </Chip>
          ))}
        </div>
        <div className="flex gap-2 overflow-x-auto pb-1 [scrollbar-width:none]">
          {MUSCLES.map((m) => (
            <Chip key={m} active={muscle === m} onClick={() => setMuscle(muscle === m ? null : m)}>
              {MUSCLE_LABEL[m]}
            </Chip>
          ))}
        </div>
        <div className="flex gap-2 overflow-x-auto pb-1 [scrollbar-width:none]">
          {GEARS.map((g) => (
            <Chip key={g} active={gear === g} onClick={() => setGear(gear === g ? null : g)}>
              {GEAR_LABEL[g]}
            </Chip>
          ))}
        </div>
        <div className="flex gap-2 overflow-x-auto pb-1 [scrollbar-width:none]">
          {PATTERNS.map((p) => (
            <Chip key={p} active={pattern === p} onClick={() => setPattern(pattern === p ? null : p)}>
              {PATTERN_LABEL[p]}
            </Chip>
          ))}
        </div>

      </div>

      <p className="px-1 text-[12.5px] text-muted-foreground">
        {results.length} {results.length === 1 ? "exercise" : "exercises"}
      </p>

      <div className="space-y-2.5 pb-4">
        {results.map((ex) => (
          <div
            key={ex.id}
            className="flex items-center gap-3 rounded-[1.35rem] border border-border/70 bg-card p-3"
          >
            <Link to="/exercise/$id" params={{ id: ex.id }} className="flex min-w-0 flex-1 items-center gap-3">
              <ExerciseThumb exerciseId={ex.id} name={ex.name} />
              <span className="min-w-0 flex-1">
                <span className="block truncate text-[15px] font-bold tracking-tight">{ex.name}</span>
                <span className="mt-0.5 block truncate text-[12.5px] text-muted-foreground">
                  {ex.primary.map((m) => MUSCLE_LABEL[m]).join(", ")} ·{" "}
                  {GEAR_LABEL[ex.equipment[0] ?? "bodyweight"]} · {ex.difficulty}
                </span>
                {ex.analyzer && (
                  <span className="mt-1.5 inline-flex items-center gap-1 rounded-full bg-primary-soft px-2 py-0.5 text-[11px] font-bold text-accent-foreground">
                    <Camera className="h-3 w-3" /> Form coach
                  </span>
                )}
              </span>
            </Link>
            <button
              type="button"
              onClick={() => toggleFavorite(ex.id)}
              aria-label={favorites.includes(ex.id) ? "Remove favourite" : "Add favourite"}
              className="flex h-9 w-9 shrink-0 items-center justify-center rounded-full bg-muted"
            >
              <Star
                className={cn(
                  "h-4 w-4",
                  favorites.includes(ex.id) ? "fill-current text-accent-foreground" : "text-muted-foreground",
                )}
              />
            </button>
          </div>
        ))}
        {results.length === 0 && (
          <div className="flex flex-col items-center px-1 py-12 text-center">
            <span className="flex h-14 w-14 items-center justify-center rounded-[1.15rem] bg-primary-soft text-accent-foreground">
              <Search className="h-6 w-6" strokeWidth={1.8} />
            </span>
            <p className="mt-4 text-[15px] font-bold tracking-tight">No movements match</p>
            <p className="mt-1 max-w-[16rem] text-[13.5px] text-muted-foreground">
              Loosen a filter - the library has {EXERCISES.length} exercises, one of them fits.
            </p>
          </div>
        )}
      </div>

    </div>
  );
}
