import { createFileRoute, Link, useNavigate } from "@tanstack/react-router";
import { ExerciseThumb } from "@/components/wellcare/ExerciseMedia";

import { useState } from "react";
import { ChevronLeft, Play, Check } from "lucide-react";
import { cn } from "@/lib/utils";
import { SurfaceCard } from "@/components/wellcare/Card";
import { getPlan } from "@/lib/wellcare/workout/plans";
import { getExercise } from "@/lib/wellcare/workout/library";
import { setTraining, useTraining } from "@/lib/wellcare/workout/training-store";
import { startPlanDay } from "@/lib/wellcare/workout/start-session";

export const Route = createFileRoute("/plan/$planId")({
  head: ({ params }) => {
    const plan = getPlan(params.planId);
    const title = plan ? `${plan.name} - Wellcare AI` : "Training plan - Wellcare AI";
    const description = plan
      ? `${plan.summary} ${plan.daysPerWeek} days a week, about ${plan.minutesPerSession} minutes per session.`
      : "A structured training plan in Wellcare AI.";
    return {
      meta: [
        { title },
        { name: "description", content: description.slice(0, 158) },
        { property: "og:title", content: title },
        { property: "og:description", content: description.slice(0, 158) },
      ],
    };
  },
  component: PlanDetail,
});

function PlanDetail() {
  const { planId } = Route.useParams();
  const navigate = useNavigate();
  const plan = getPlan(planId);
  const training = useTraining();
  const [openDay, setOpenDay] = useState(0);

  if (!plan) {
    return (
      <div className="px-5 pt-[max(env(safe-area-inset-top),2rem)]">
        <p className="text-[15px] font-bold">That plan doesn't exist.</p>
        <Link to="/workout" className="mt-3 inline-block text-[14px] text-accent-foreground">
          Back to training
        </Link>
      </div>
    );
  }

  const isActive = training.activePlanId === plan.id;

  return (
    <div className="space-y-6 px-5 pt-[max(env(safe-area-inset-top),1.25rem)]">
      <button
        type="button"
        onClick={() => navigate({ to: "/workout" })}
        className="flex h-10 w-10 items-center justify-center rounded-full bg-muted"
        aria-label="Back"
      >
        <ChevronLeft className="h-5 w-5" />
      </button>

      <header>
        <p className="text-[12px] font-bold uppercase tracking-[0.08em] text-muted-foreground">
          {plan.level} · {plan.split}
        </p>
        <h1 className="mt-1.5 text-[25px] font-extrabold leading-tight tracking-[-0.035em]">
          {plan.name}
        </h1>
        <p className="mt-2 text-[14px] leading-relaxed text-muted-foreground">{plan.summary}</p>
        <p className="mt-2 text-[13px] text-muted-foreground">
          {plan.daysPerWeek}× per week · ~{plan.minutesPerSession} min · {plan.days.length} sessions
        </p>
      </header>

      <button
        type="button"
        onClick={() => setTraining({ activePlanId: isActive ? null : plan.id })}
        className={cn(
          "flex h-12 w-full items-center justify-center gap-2 rounded-full text-[15px] font-bold active:scale-[0.98]",
          isActive ? "border border-border bg-card" : "bg-primary text-primary-foreground",
        )}
      >
        {isActive ? (
          <>
            <Check className="h-4 w-4" /> Active plan
          </>
        ) : (
          "Make this my plan"
        )}
      </button>

      <div className="space-y-3 pb-4">
        {plan.days.map((day, i) => {
          const open = openDay === i;
          return (
            <SurfaceCard key={day.label} className="p-0">
              <button
                type="button"
                onClick={() => setOpenDay(open ? -1 : i)}
                className="flex w-full items-center justify-between gap-3 px-5 py-4 text-left"
              >
                <span className="min-w-0">
                  <span className="block text-[15.5px] font-bold tracking-tight">
                    Day {i + 1} · {day.label}
                  </span>
                  <span className="mt-0.5 block truncate text-[12.5px] text-muted-foreground">
                    {day.focus} · {day.exercises.length} exercises
                  </span>
                </span>
                <span
                  role="presentation"
                  onClick={(e) => {
                    e.stopPropagation();
                    startPlanDay(plan, i);
                    navigate({ to: "/session" });
                  }}
                  className="flex h-10 w-10 shrink-0 items-center justify-center rounded-full bg-primary text-primary-foreground"
                >
                  <Play className="h-4 w-4" strokeWidth={2.4} />
                </span>
              </button>

              {open && (
                <div className="divide-y divide-border/70 border-t border-border/70">
                  {day.exercises.map((pe) => {
                    const ex = getExercise(pe.exerciseId);
                    return (
                      <Link
                        key={pe.exerciseId}
                        to="/exercise/$id"
                        params={{ id: pe.exerciseId }}
                        className="flex items-center gap-3 px-5 py-3"
                      >
                        <ExerciseThumb
                          exerciseId={pe.exerciseId}
                          name={ex?.name ?? pe.exerciseId}
                          compact
                        />
                        <span className="min-w-0 flex-1 truncate text-[14px] font-semibold tracking-tight">
                          {ex?.name ?? pe.exerciseId}
                        </span>
                        <span className="shrink-0 text-[12.5px] text-muted-foreground">
                          {pe.sets} × {pe.reps}
                        </span>
                      </Link>

                    );
                  })}
                </div>
              )}
            </SurfaceCard>
          );
        })}
      </div>
    </div>
  );
}
