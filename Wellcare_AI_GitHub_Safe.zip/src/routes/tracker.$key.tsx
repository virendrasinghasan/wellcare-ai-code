import { useMemo, useState } from "react";
import { createFileRoute, Link, useNavigate } from "@tanstack/react-router";
import { useMutation, useQuery, useQueryClient } from "@tanstack/react-query";
import { useServerFn } from "@tanstack/react-start";
import { ChevronLeft, Trash2, Target, Loader2 } from "lucide-react";
import { SurfaceCard, SectionHeader } from "@/components/wellcare/Card";
import { TrackerIcon } from "@/components/wellcare/TrackerIcon";
import { TrendChart } from "@/components/wellcare/TrendChart";
import { useWellcare } from "@/lib/wellcare/store";
import {
  TRACKER_MAP,
  formatTrackerValue,
  isTrackerKey,
} from "@/lib/wellcare/trackers/registry";
import type { TrackerEntry, TrackerKey, TrackerMeta } from "@/lib/wellcare/trackers/registry";
import {
  addMedicine,
  addTrackerEntry,
  deleteMedicine,
  deleteTrackerEntry,
  listMedicines,
  listTrackerEntries,
  listTrackerGoals,
  logMedicine,
  setTrackerGoal,
} from "@/lib/wellcare/trackers/trackers.functions";

export const Route = createFileRoute("/tracker/$key")({
  head: ({ params }) => {
    const meta = TRACKER_MAP[params.key];
    const label = meta?.label ?? "Tracker";
    return {
      meta: [
        { title: `${label} tracker - Wellcare AI` },
        {
          name: "description",
          content: meta
            ? `Log and review your ${label.toLowerCase()}: today's value, history and trend, stored privately in Wellcare AI.`
            : "Track a health metric in Wellcare AI.",
        },
        { property: "og:title", content: `${label} tracker - Wellcare AI` },
        {
          property: "og:description",
          content: `Log and review your ${label.toLowerCase()} in Wellcare AI.`,
        },
      ],
    };
  },
  component: TrackerDetail,
});

function dayLabel(at: string) {
  const d = new Date(at.length === 10 ? `${at}T00:00:00` : at);
  return d.toLocaleDateString(undefined, { day: "numeric", month: "short" });
}

function timeLabel(at: string) {
  if (at.length === 10) return dayLabel(at);
  return new Date(at).toLocaleString(undefined, {
    day: "numeric",
    month: "short",
    hour: "2-digit",
    minute: "2-digit",
  });
}

function isToday(at: string) {
  const key = new Date(at.length === 10 ? `${at}T00:00:00` : at).toDateString();
  return key === new Date().toDateString();
}

function TrackerDetail() {
  const { key } = Route.useParams();
  const navigate = useNavigate();
  const { signedIn } = useWellcare();

  if (!isTrackerKey(key)) {
    return (
      <div className="space-y-4 px-5 pt-[max(env(safe-area-inset-top),1.5rem)]">
        <BackBar title="Tracker" />
        <SurfaceCard>
          <p className="text-[14px] font-bold tracking-tight">Unknown tracker</p>
          <p className="mt-1 text-[13px] text-muted-foreground">
            That tracker does not exist. Pick one from the list.
          </p>
          <Link
            to="/trackers"
            className="mt-3 inline-flex h-11 items-center rounded-full bg-primary px-5 text-[13px] font-bold text-primary-foreground"
          >
            All trackers
          </Link>
        </SurfaceCard>
      </div>
    );
  }

  const meta = TRACKER_MAP[key] as TrackerMeta;

  if (meta.kind === "local") {
    return (
      <div className="space-y-4 px-5 pt-[max(env(safe-area-inset-top),1.5rem)]">
        <BackBar title={meta.label} />
        <SurfaceCard>
          <p className="text-[14px] font-bold tracking-tight">{meta.blurb}</p>
          <p className="mt-1 text-[13px] leading-relaxed text-muted-foreground">
            This one already has its own screen in Wellcare.
          </p>
          <button
            type="button"
            onClick={() => navigate({ to: meta.linkTo ?? "/" })}
            className="mt-3 inline-flex h-11 items-center rounded-full bg-primary px-5 text-[13px] font-bold text-primary-foreground"
          >
            Open {meta.label.toLowerCase()}
          </button>
        </SurfaceCard>
      </div>
    );
  }

  if (!signedIn) {
    return (
      <div className="space-y-4 px-5 pt-[max(env(safe-area-inset-top),1.5rem)]">
        <BackBar title={meta.label} />
        <SurfaceCard>
          <p className="text-[14px] font-bold tracking-tight">Sign in first</p>
          <p className="mt-1 text-[13px] leading-relaxed text-muted-foreground">
            Health readings are private to your account, so they need one.
          </p>
          <Link
            to="/welcome"
            className="mt-3 inline-flex h-11 items-center rounded-full bg-primary px-5 text-[13px] font-bold text-primary-foreground"
          >
            Sign in
          </Link>
        </SurfaceCard>
      </div>
    );
  }

  if (meta.kind === "medicine") return <MedicineTracker />;
  return <NumericTracker meta={meta} trackerKey={key} />;
}

function BackBar({ title }: { title: string }) {
  return (
    <header className="flex items-center gap-2 pt-1">
      <Link
        to="/trackers"
        aria-label="Back to trackers"
        className="flex h-11 w-11 items-center justify-center rounded-full border border-border/70 bg-card"
      >
        <ChevronLeft className="h-5 w-5" />
      </Link>
      <h1 className="truncate text-[20px] font-extrabold tracking-[-0.03em]">{title}</h1>
    </header>
  );
}

/* ------------------------------ numeric ---------------------------------- */

function NumericTracker({ meta, trackerKey }: { meta: TrackerMeta; trackerKey: TrackerKey }) {
  const queryClient = useQueryClient();
  const fetchEntries = useServerFn(listTrackerEntries);
  const fetchGoals = useServerFn(listTrackerGoals);
  const addEntry = useServerFn(addTrackerEntry);
  const removeEntry = useServerFn(deleteTrackerEntry);
  const saveGoal = useServerFn(setTrackerGoal);

  const [value, setValue] = useState("");
  const [context, setContext] = useState("");
  const [bedtime, setBedtime] = useState("");
  const [wake, setWake] = useState("");
  const [goalDraft, setGoalDraft] = useState("");
  const [error, setError] = useState<string | null>(null);

  const entriesQuery = useQuery({
    queryKey: ["tracker-entries", trackerKey],
    queryFn: () => fetchEntries({ data: { key: trackerKey, days: 90 } }),
  });
  const goalsQuery = useQuery({ queryKey: ["tracker-goals"], queryFn: () => fetchGoals() });

  const goal =
    goalsQuery.data?.find((g) => g.key === trackerKey)?.target ?? meta.defaultGoal ?? null;

  const entries: TrackerEntry[] = entriesQuery.data ?? [];

  const todayTotal = useMemo(() => {
    const today = entries.filter((e) => isToday(e.at));
    if (today.length === 0) return null;
    if (trackerKey === "water") return today.reduce((s, e) => s + e.value, 0);
    if (trackerKey === "steps" || trackerKey === "sleep")
      return today.reduce((s, e) => s + e.value, 0);
    return today[0]!.value;
  }, [entries, trackerKey]);

  const chartPoints = useMemo(() => {
    const byDay = new Map<string, number>();
    for (const e of [...entries].reverse()) {
      const d = new Date(e.at.length === 10 ? `${e.at}T00:00:00` : e.at);
      const k = d.toISOString().slice(0, 10);
      const additive = trackerKey === "water" || trackerKey === "sleep" || trackerKey === "steps";
      byDay.set(k, additive ? (byDay.get(k) ?? 0) + e.value : e.value);
    }
    return [...byDay.entries()].slice(-14).map(([k, v]) => ({ label: dayLabel(k), value: v }));
  }, [entries, trackerKey]);

  const save = useMutation({
    mutationFn: async () => {
      let numeric = Number(value);
      let payload: Record<string, unknown> = {};
      if (trackerKey === "sleep") {
        if (!bedtime || !wake) throw new Error("Add both a bedtime and a wake time.");
        const b = new Date(bedtime);
        const w = new Date(wake);
        let mins = Math.round((w.getTime() - b.getTime()) / 60000);
        if (mins <= 0) mins += 24 * 60;
        if (mins <= 0 || mins > 20 * 60) throw new Error("That sleep window does not add up.");
        numeric = mins;
        payload = { bedtime: b.toISOString(), wakeTime: w.toISOString(), at: w.toISOString() };
      }
      if (!Number.isFinite(numeric) || numeric <= 0) throw new Error("Enter a real number.");
      return addEntry({
        data: {
          key: trackerKey,
          value: numeric,
          ...(context ? { context } : {}),
          ...payload,
        },
      });
    },
    onSuccess: () => {
      setValue("");
      setContext("");
      setBedtime("");
      setWake("");
      setError(null);
      void queryClient.invalidateQueries({ queryKey: ["tracker-entries", trackerKey] });
    },
    onError: (e: Error) => setError(e.message),
  });

  const del = useMutation({
    mutationFn: (id: string) => removeEntry({ data: { key: trackerKey, id } }),
    onSuccess: () => queryClient.invalidateQueries({ queryKey: ["tracker-entries", trackerKey] }),
  });

  const goalMutation = useMutation({
    mutationFn: () => {
      const t = Number(goalDraft);
      if (!Number.isFinite(t) || t <= 0) throw new Error("Enter a real goal.");
      return saveGoal({ data: { key: trackerKey, target: t, unit: meta.unitShort, period: "daily" } });
    },
    onSuccess: () => {
      setGoalDraft("");
      void queryClient.invalidateQueries({ queryKey: ["tracker-goals"] });
    },
    onError: (e: Error) => setError(e.message),
  });

  return (
    <div className="space-y-7 px-5 pb-4 pt-[max(env(safe-area-inset-top),1.5rem)]">
      <BackBar title={meta.label} />

      <SurfaceCard className="p-6">
        <div className="flex items-center gap-3">
          <span className="flex h-11 w-11 items-center justify-center rounded-full bg-primary-soft text-accent-foreground">
            <TrackerIcon name={meta.icon} className="h-5 w-5" />
          </span>
          <div className="min-w-0">
            <p className="text-[12px] font-bold uppercase tracking-[0.08em] text-muted-foreground">
              Today
            </p>
            <p className="text-[28px] font-extrabold leading-tight tracking-[-0.03em]">
              {todayTotal == null ? "No entry" : formatTrackerValue(trackerKey, todayTotal)}
            </p>
          </div>
        </div>
        {goal != null && (
          <p className="mt-3 text-[13px] text-muted-foreground">
            Goal: {formatTrackerValue(trackerKey, goal)} per day
          </p>
        )}
      </SurfaceCard>

      {/* Manual entry */}
      <section>
        <SectionHeader title="Add a reading" />
        <SurfaceCard className="space-y-3">
          {trackerKey === "sleep" ? (
            <div className="grid grid-cols-2 gap-3">
              <label className="block">
                <span className="mb-1 block text-[12px] font-bold text-muted-foreground">
                  Bedtime
                </span>
                <input
                  type="datetime-local"
                  value={bedtime}
                  onChange={(e) => setBedtime(e.target.value)}
                  className="h-11 w-full rounded-full border border-border/70 bg-background px-3 text-[13.5px]"
                />
              </label>
              <label className="block">
                <span className="mb-1 block text-[12px] font-bold text-muted-foreground">
                  Wake time
                </span>
                <input
                  type="datetime-local"
                  value={wake}
                  onChange={(e) => setWake(e.target.value)}
                  className="h-11 w-full rounded-full border border-border/70 bg-background px-3 text-[13.5px]"
                />
              </label>
            </div>
          ) : (
            <label className="block">
              <span className="mb-1 block text-[12px] font-bold text-muted-foreground">
                {meta.label} ({meta.unit})
              </span>
              <input
                type="number"
                inputMode="decimal"
                step={meta.inputStep}
                value={value}
                placeholder={meta.inputHint}
                onChange={(e) => setValue(e.target.value)}
                className="h-12 w-full rounded-full border border-border/70 bg-background px-4 text-[15px] font-semibold"
              />
            </label>
          )}

          {(trackerKey === "glucose" ||
            trackerKey === "heart_rate" ||
            trackerKey === "respiratory" ||
            trackerKey === "sleep") && (
            <label className="block">
              <span className="mb-1 block text-[12px] font-bold text-muted-foreground">
                Context (optional)
              </span>
              <input
                type="text"
                value={context}
                placeholder={trackerKey === "glucose" ? "Fasting, post-meal..." : "Resting, notes..."}
                onChange={(e) => setContext(e.target.value)}
                className="h-11 w-full rounded-full border border-border/70 bg-background px-4 text-[13.5px]"
              />
            </label>
          )}

          {error && (
            <p role="alert" className="text-[12.5px] font-semibold text-destructive">
              {error}
            </p>
          )}

          <button
            type="button"
            disabled={save.isPending}
            onClick={() => save.mutate()}
            className="flex h-12 w-full items-center justify-center gap-2 rounded-full bg-primary text-[14px] font-bold text-primary-foreground disabled:opacity-60"
          >
            {save.isPending && <Loader2 className="h-4 w-4 animate-spin" />}
            Save entry
          </button>
          <p className="text-center text-[11.5px] text-muted-foreground">
            Saved as a manual entry. Wellcare never invents readings for you.
          </p>
        </SurfaceCard>
      </section>

      {/* Goal */}
      <section>
        <SectionHeader title="Daily goal" />
        <SurfaceCard className="flex items-center gap-2">
          <Target className="h-4 w-4 shrink-0 text-muted-foreground" aria-hidden />
          <input
            type="number"
            inputMode="decimal"
            value={goalDraft}
            placeholder={goal != null ? String(goal) : `Target in ${meta.unitShort || meta.unit}`}
            onChange={(e) => setGoalDraft(e.target.value)}
            aria-label={`${meta.label} daily goal`}
            className="h-11 min-w-0 flex-1 rounded-full border border-border/70 bg-background px-4 text-[13.5px]"
          />
          <button
            type="button"
            disabled={goalMutation.isPending || !goalDraft}
            onClick={() => goalMutation.mutate()}
            className="h-11 shrink-0 rounded-full bg-muted px-4 text-[13px] font-bold disabled:opacity-50"
          >
            Set
          </button>
        </SurfaceCard>
      </section>

      {/* Trend */}
      <section>
        <SectionHeader title="Trend" />
        <SurfaceCard>
          {entriesQuery.isPending ? (
            <p className="py-6 text-center text-[13px] text-muted-foreground">Loading history...</p>
          ) : chartPoints.length < 2 ? (
            <p className="py-6 text-center text-[13px] leading-relaxed text-muted-foreground">
              Not enough data for a trend yet. Log a few days and this fills in.
            </p>
          ) : (
            <TrendChart points={chartPoints} goal={goal} />
          )}
        </SurfaceCard>
      </section>

      {/* History */}
      <section>
        <SectionHeader title="History" />
        {entriesQuery.isPending ? (
          <SurfaceCard>
            <p className="text-[13px] text-muted-foreground">Loading...</p>
          </SurfaceCard>
        ) : entriesQuery.isError ? (
          <SurfaceCard>
            <p className="text-[13px] font-semibold text-destructive">
              Could not load your history.
            </p>
            <button
              type="button"
              onClick={() => entriesQuery.refetch()}
              className="mt-3 h-11 rounded-full bg-muted px-5 text-[13px] font-bold"
            >
              Try again
            </button>
          </SurfaceCard>
        ) : entries.length === 0 ? (
          <SurfaceCard>
            <p className="text-[14px] font-bold tracking-tight">No {meta.label.toLowerCase()} data yet</p>
            <p className="mt-1 text-[13px] leading-relaxed text-muted-foreground">
              Add your first entry above and the history starts here.
            </p>
          </SurfaceCard>
        ) : (
          <SurfaceCard className="divide-y divide-border/70 p-0">
            {entries.map((e) => (
              <div key={e.id} className="flex items-center gap-3 px-5 py-3.5">
                <span className="min-w-0 flex-1">
                  <span className="block text-[14.5px] font-bold tabular-nums tracking-tight">
                    {formatTrackerValue(trackerKey, e.value)}
                  </span>
                  <span className="block truncate text-[12.5px] text-muted-foreground">
                    {timeLabel(e.at)}
                    {e.context ? ` · ${e.context}` : ""} ·{" "}
                    {e.source === "manual" ? "Manual" : e.source === "device" ? "Device" : "AI"}
                  </span>
                </span>
                <button
                  type="button"
                  onClick={() => del.mutate(e.id)}
                  aria-label={`Delete entry from ${timeLabel(e.at)}`}
                  className="flex h-10 w-10 shrink-0 items-center justify-center rounded-full text-muted-foreground"
                >
                  <Trash2 className="h-4 w-4" />
                </button>
              </div>
            ))}
          </SurfaceCard>
        )}
      </section>
    </div>
  );
}

/* ------------------------------ medicine --------------------------------- */

function MedicineTracker() {
  const queryClient = useQueryClient();
  const fetchMeds = useServerFn(listMedicines);
  const create = useServerFn(addMedicine);
  const remove = useServerFn(deleteMedicine);
  const log = useServerFn(logMedicine);

  const [name, setName] = useState("");
  const [dose, setDose] = useState("");
  const [times, setTimes] = useState("08:00");
  const [error, setError] = useState<string | null>(null);

  const medsQuery = useQuery({ queryKey: ["medicines"], queryFn: () => fetchMeds() });

  const addMutation = useMutation({
    mutationFn: () => {
      if (!name.trim()) throw new Error("Give the medicine a name.");
      return create({
        data: {
          name: name.trim(),
          dose: dose.trim() || undefined,
          frequency: "daily",
          times: times
            .split(",")
            .map((t) => t.trim())
            .filter(Boolean)
            .slice(0, 8),
          reminderEnabled: false,
        },
      });
    },
    onSuccess: () => {
      setName("");
      setDose("");
      setError(null);
      void queryClient.invalidateQueries({ queryKey: ["medicines"] });
    },
    onError: (e: Error) => setError(e.message),
  });

  const logMutation = useMutation({
    mutationFn: (vars: { medicineId: string; scheduledTime: string | null; status: "taken" | "skipped" }) =>
      log({ data: vars }),
    onSuccess: () => queryClient.invalidateQueries({ queryKey: ["medicines"] }),
  });

  const deleteMutation = useMutation({
    mutationFn: (id: string) => remove({ data: { id } }),
    onSuccess: () => queryClient.invalidateQueries({ queryKey: ["medicines"] }),
  });

  const meds = medsQuery.data?.medicines ?? [];
  const logs = medsQuery.data?.todayLogs ?? [];
  const statusFor = (medId: string, time: string) =>
    logs.find((l) => l.medicineId === medId && (l.scheduledTime ?? "") === time)?.status ?? null;

  return (
    <div className="space-y-7 px-5 pb-4 pt-[max(env(safe-area-inset-top),1.5rem)]">
      <BackBar title="Medicine" />

      <section>
        <SectionHeader title="Today" />
        {medsQuery.isPending ? (
          <SurfaceCard>
            <p className="text-[13px] text-muted-foreground">Loading your medicines...</p>
          </SurfaceCard>
        ) : meds.length === 0 ? (
          <SurfaceCard>
            <p className="text-[14px] font-bold tracking-tight">No medicines added</p>
            <p className="mt-1 text-[13px] leading-relaxed text-muted-foreground">
              Add one below to track doses. Wellcare tracks what you enter, it does not give
              medical advice.
            </p>
          </SurfaceCard>
        ) : (
          <ul className="space-y-2.5">
            {meds.map((m) => (
              <li key={m.id} className="rounded-[1.5rem] border border-border/70 bg-card p-4">
                <div className="flex items-start gap-3">
                  <div className="min-w-0 flex-1">
                    <p className="truncate text-[15px] font-bold tracking-tight">{m.name}</p>
                    <p className="text-[12.5px] text-muted-foreground">
                      {[m.dose, m.frequency].filter(Boolean).join(" · ")}
                    </p>
                  </div>
                  <button
                    type="button"
                    onClick={() => deleteMutation.mutate(m.id)}
                    aria-label={`Remove ${m.name}`}
                    className="flex h-10 w-10 shrink-0 items-center justify-center rounded-full text-muted-foreground"
                  >
                    <Trash2 className="h-4 w-4" />
                  </button>
                </div>
                <div className="mt-3 flex flex-wrap gap-2">
                  {(m.times.length ? m.times : [""]).map((t) => {
                    const status = statusFor(m.id, t);
                    return (
                      <button
                        key={t || "any"}
                        type="button"
                        onClick={() =>
                          logMutation.mutate({
                            medicineId: m.id,
                            scheduledTime: t || null,
                            status: status === "taken" ? "skipped" : "taken",
                          })
                        }
                        aria-pressed={status === "taken"}
                        className={`h-10 rounded-full px-4 text-[12.5px] font-bold transition-colors ${
                          status === "taken"
                            ? "bg-primary text-primary-foreground"
                            : "bg-muted text-foreground"
                        }`}
                      >
                        {t || "Dose"} · {status === "taken" ? "Taken" : status === "skipped" ? "Skipped" : "Mark taken"}
                      </button>
                    );
                  })}
                </div>
              </li>
            ))}
          </ul>
        )}
      </section>

      <section>
        <SectionHeader title="Add a medicine" />
        <SurfaceCard className="space-y-3">
          <label className="block">
            <span className="mb-1 block text-[12px] font-bold text-muted-foreground">Name</span>
            <input
              value={name}
              onChange={(e) => setName(e.target.value)}
              placeholder="e.g. Vitamin D"
              className="h-12 w-full rounded-full border border-border/70 bg-background px-4 text-[15px] font-semibold"
            />
          </label>
          <div className="grid grid-cols-2 gap-3">
            <label className="block">
              <span className="mb-1 block text-[12px] font-bold text-muted-foreground">Dose</span>
              <input
                value={dose}
                onChange={(e) => setDose(e.target.value)}
                placeholder="1000 IU"
                className="h-11 w-full rounded-full border border-border/70 bg-background px-4 text-[13.5px]"
              />
            </label>
            <label className="block">
              <span className="mb-1 block text-[12px] font-bold text-muted-foreground">
                Times
              </span>
              <input
                value={times}
                onChange={(e) => setTimes(e.target.value)}
                placeholder="08:00, 20:00"
                className="h-11 w-full rounded-full border border-border/70 bg-background px-4 text-[13.5px]"
              />
            </label>
          </div>
          {error && (
            <p role="alert" className="text-[12.5px] font-semibold text-destructive">
              {error}
            </p>
          )}
          <button
            type="button"
            disabled={addMutation.isPending}
            onClick={() => addMutation.mutate()}
            className="flex h-12 w-full items-center justify-center gap-2 rounded-full bg-primary text-[14px] font-bold text-primary-foreground disabled:opacity-60"
          >
            {addMutation.isPending && <Loader2 className="h-4 w-4 animate-spin" />}
            Add medicine
          </button>
        </SurfaceCard>
      </section>
    </div>
  );
}
