export type Json =
  | string
  | number
  | boolean
  | null
  | { [key: string]: Json | undefined }
  | Json[]

export type Database = {
  // Allows to automatically instantiate createClient with right options
  // instead of createClient<Database, { PostgrestVersion: 'XX' }>(URL, KEY)
  __InternalSupabase: {
    PostgrestVersion: "14.5"
  }
  public: {
    Tables: {
      ai_interactions: {
        Row: {
          context: Json | null
          created_at: string
          id: string
          kind: Database["public"]["Enums"]["ai_interaction_kind"]
          model: string | null
          prompt: string | null
          response: string | null
          user_id: string
        }
        Insert: {
          context?: Json | null
          created_at?: string
          id?: string
          kind?: Database["public"]["Enums"]["ai_interaction_kind"]
          model?: string | null
          prompt?: string | null
          response?: string | null
          user_id: string
        }
        Update: {
          context?: Json | null
          created_at?: string
          id?: string
          kind?: Database["public"]["Enums"]["ai_interaction_kind"]
          model?: string | null
          prompt?: string | null
          response?: string | null
          user_id?: string
        }
        Relationships: []
      }
      assistant_actions: {
        Row: {
          created_at: string
          id: string
          new_value: Json | null
          op: string
          previous_value: Json | null
          request: string | null
          summary: string
          target_id: string | null
          target_table: string | null
          tool: string
          undone: boolean
          user_id: string
        }
        Insert: {
          created_at?: string
          id?: string
          new_value?: Json | null
          op?: string
          previous_value?: Json | null
          request?: string | null
          summary: string
          target_id?: string | null
          target_table?: string | null
          tool: string
          undone?: boolean
          user_id: string
        }
        Update: {
          created_at?: string
          id?: string
          new_value?: Json | null
          op?: string
          previous_value?: Json | null
          request?: string | null
          summary?: string
          target_id?: string | null
          target_table?: string | null
          tool?: string
          undone?: boolean
          user_id?: string
        }
        Relationships: []
      }
      blood_glucose_entries: {
        Row: {
          context: string | null
          created_at: string
          id: string
          measured_at: string
          source: Database["public"]["Enums"]["data_source"]
          unit: Database["public"]["Enums"]["glucose_unit"]
          user_id: string
          value: number
        }
        Insert: {
          context?: string | null
          created_at?: string
          id?: string
          measured_at?: string
          source?: Database["public"]["Enums"]["data_source"]
          unit?: Database["public"]["Enums"]["glucose_unit"]
          user_id: string
          value: number
        }
        Update: {
          context?: string | null
          created_at?: string
          id?: string
          measured_at?: string
          source?: Database["public"]["Enums"]["data_source"]
          unit?: Database["public"]["Enums"]["glucose_unit"]
          user_id?: string
          value?: number
        }
        Relationships: []
      }
      exercises: {
        Row: {
          created_at: string
          created_by: string | null
          difficulty: string | null
          equipment: string | null
          id: string
          instructions: string | null
          is_public: boolean
          name: string
          primary_muscle: string | null
          secondary_muscles: string[] | null
          updated_at: string
          video_url: string | null
        }
        Insert: {
          created_at?: string
          created_by?: string | null
          difficulty?: string | null
          equipment?: string | null
          id?: string
          instructions?: string | null
          is_public?: boolean
          name: string
          primary_muscle?: string | null
          secondary_muscles?: string[] | null
          updated_at?: string
          video_url?: string | null
        }
        Update: {
          created_at?: string
          created_by?: string | null
          difficulty?: string | null
          equipment?: string | null
          id?: string
          instructions?: string | null
          is_public?: boolean
          name?: string
          primary_muscle?: string | null
          secondary_muscles?: string[] | null
          updated_at?: string
          video_url?: string | null
        }
        Relationships: []
      }
      foods: {
        Row: {
          barcode: string | null
          brand: string | null
          calories: number
          carbs_g: number
          category: string | null
          country: string | null
          created_at: string
          created_by: string | null
          fat_g: number
          fiber_g: number | null
          id: string
          image_url: string | null
          ingredients: string | null
          is_public: boolean
          name: string
          protein_g: number
          serving_grams: number
          serving_label: string
          serving_unit: string
          sodium_mg: number | null
          source: string
          source_product_id: string | null
          sugar_g: number | null
          updated_at: string
        }
        Insert: {
          barcode?: string | null
          brand?: string | null
          calories?: number
          carbs_g?: number
          category?: string | null
          country?: string | null
          created_at?: string
          created_by?: string | null
          fat_g?: number
          fiber_g?: number | null
          id?: string
          image_url?: string | null
          ingredients?: string | null
          is_public?: boolean
          name: string
          protein_g?: number
          serving_grams?: number
          serving_label?: string
          serving_unit?: string
          sodium_mg?: number | null
          source?: string
          source_product_id?: string | null
          sugar_g?: number | null
          updated_at?: string
        }
        Update: {
          barcode?: string | null
          brand?: string | null
          calories?: number
          carbs_g?: number
          category?: string | null
          country?: string | null
          created_at?: string
          created_by?: string | null
          fat_g?: number
          fiber_g?: number | null
          id?: string
          image_url?: string | null
          ingredients?: string | null
          is_public?: boolean
          name?: string
          protein_g?: number
          serving_grams?: number
          serving_label?: string
          serving_unit?: string
          sodium_mg?: number | null
          source?: string
          source_product_id?: string | null
          sugar_g?: number | null
          updated_at?: string
        }
        Relationships: []
      }
      health_connections: {
        Row: {
          created_at: string
          external_account_id: string | null
          granted_metrics: string[]
          id: string
          last_error: string | null
          last_synced_at: string | null
          provider: string
          status: string
          updated_at: string
          user_id: string
        }
        Insert: {
          created_at?: string
          external_account_id?: string | null
          granted_metrics?: string[]
          id?: string
          last_error?: string | null
          last_synced_at?: string | null
          provider: string
          status?: string
          updated_at?: string
          user_id: string
        }
        Update: {
          created_at?: string
          external_account_id?: string | null
          granted_metrics?: string[]
          id?: string
          last_error?: string | null
          last_synced_at?: string | null
          provider?: string
          status?: string
          updated_at?: string
          user_id?: string
        }
        Relationships: []
      }
      heart_rate_entries: {
        Row: {
          bpm: number
          context: string | null
          created_at: string
          id: string
          is_resting: boolean
          measured_at: string
          source: Database["public"]["Enums"]["data_source"]
          user_id: string
        }
        Insert: {
          bpm: number
          context?: string | null
          created_at?: string
          id?: string
          is_resting?: boolean
          measured_at?: string
          source?: Database["public"]["Enums"]["data_source"]
          user_id: string
        }
        Update: {
          bpm?: number
          context?: string | null
          created_at?: string
          id?: string
          is_resting?: boolean
          measured_at?: string
          source?: Database["public"]["Enums"]["data_source"]
          user_id?: string
        }
        Relationships: []
      }
      meal_items: {
        Row: {
          calories: number
          carbs_g: number
          created_at: string
          fat_g: number
          food_id: string | null
          id: string
          meal_id: string
          name: string
          protein_g: number
          quantity: number
          unit: string
          user_id: string
        }
        Insert: {
          calories?: number
          carbs_g?: number
          created_at?: string
          fat_g?: number
          food_id?: string | null
          id?: string
          meal_id: string
          name: string
          protein_g?: number
          quantity?: number
          unit?: string
          user_id: string
        }
        Update: {
          calories?: number
          carbs_g?: number
          created_at?: string
          fat_g?: number
          food_id?: string | null
          id?: string
          meal_id?: string
          name?: string
          protein_g?: number
          quantity?: number
          unit?: string
          user_id?: string
        }
        Relationships: [
          {
            foreignKeyName: "meal_items_food_id_fkey"
            columns: ["food_id"]
            isOneToOne: false
            referencedRelation: "foods"
            referencedColumns: ["id"]
          },
          {
            foreignKeyName: "meal_items_meal_id_fkey"
            columns: ["meal_id"]
            isOneToOne: false
            referencedRelation: "meals"
            referencedColumns: ["id"]
          },
        ]
      }
      meals: {
        Row: {
          ai_analysis: Json | null
          created_at: string
          id: string
          logged_on: string
          meal_type: Database["public"]["Enums"]["meal_type"]
          notes: string | null
          photo_url: string | null
          title: string | null
          updated_at: string
          user_id: string
        }
        Insert: {
          ai_analysis?: Json | null
          created_at?: string
          id?: string
          logged_on?: string
          meal_type?: Database["public"]["Enums"]["meal_type"]
          notes?: string | null
          photo_url?: string | null
          title?: string | null
          updated_at?: string
          user_id: string
        }
        Update: {
          ai_analysis?: Json | null
          created_at?: string
          id?: string
          logged_on?: string
          meal_type?: Database["public"]["Enums"]["meal_type"]
          notes?: string | null
          photo_url?: string | null
          title?: string | null
          updated_at?: string
          user_id?: string
        }
        Relationships: []
      }
      medicine_logs: {
        Row: {
          created_at: string
          id: string
          logged_on: string
          medicine_id: string
          scheduled_time: string | null
          status: Database["public"]["Enums"]["medicine_status"]
          taken_at: string | null
          user_id: string
        }
        Insert: {
          created_at?: string
          id?: string
          logged_on?: string
          medicine_id: string
          scheduled_time?: string | null
          status?: Database["public"]["Enums"]["medicine_status"]
          taken_at?: string | null
          user_id: string
        }
        Update: {
          created_at?: string
          id?: string
          logged_on?: string
          medicine_id?: string
          scheduled_time?: string | null
          status?: Database["public"]["Enums"]["medicine_status"]
          taken_at?: string | null
          user_id?: string
        }
        Relationships: [
          {
            foreignKeyName: "medicine_logs_medicine_id_fkey"
            columns: ["medicine_id"]
            isOneToOne: false
            referencedRelation: "medicines"
            referencedColumns: ["id"]
          },
        ]
      }
      medicines: {
        Row: {
          created_at: string
          dose: string | null
          end_date: string | null
          frequency: string
          id: string
          is_active: boolean
          name: string
          notes: string | null
          reminder_enabled: boolean
          start_date: string
          times: string[]
          unit: string | null
          updated_at: string
          user_id: string
        }
        Insert: {
          created_at?: string
          dose?: string | null
          end_date?: string | null
          frequency?: string
          id?: string
          is_active?: boolean
          name: string
          notes?: string | null
          reminder_enabled?: boolean
          start_date?: string
          times?: string[]
          unit?: string | null
          updated_at?: string
          user_id: string
        }
        Update: {
          created_at?: string
          dose?: string | null
          end_date?: string | null
          frequency?: string
          id?: string
          is_active?: boolean
          name?: string
          notes?: string | null
          reminder_enabled?: boolean
          start_date?: string
          times?: string[]
          unit?: string | null
          updated_at?: string
          user_id?: string
        }
        Relationships: []
      }
      profiles: {
        Row: {
          activity_level: Database["public"]["Enums"]["activity_level"]
          allergies: string[]
          avatar_url: string | null
          avoided_foods: string[]
          birth_date: string | null
          body_fat_pct: number | null
          created_at: string
          daily_calorie_target: number
          daily_carbs_target_g: number
          daily_fat_target_g: number
          daily_protein_target_g: number
          daily_water_target_ml: number
          diet_type: string | null
          display_name: string | null
          equipment: string[]
          first_name: string | null
          goal: Database["public"]["Enums"]["fitness_goal"]
          health_connected: boolean
          health_metrics: string[]
          health_provider: string | null
          height_cm: number | null
          height_unit: string
          id: string
          onboarding_completed: boolean
          secondary_goals: string[]
          sex: string | null
          tdee_estimate: number | null
          tdee_inputs: Json | null
          tdee_method: string | null
          training_days_per_week: number | null
          training_experience: string | null
          updated_at: string
          weight_kg: number | null
          weight_unit: string
        }
        Insert: {
          activity_level?: Database["public"]["Enums"]["activity_level"]
          allergies?: string[]
          avatar_url?: string | null
          avoided_foods?: string[]
          birth_date?: string | null
          body_fat_pct?: number | null
          created_at?: string
          daily_calorie_target?: number
          daily_carbs_target_g?: number
          daily_fat_target_g?: number
          daily_protein_target_g?: number
          daily_water_target_ml?: number
          diet_type?: string | null
          display_name?: string | null
          equipment?: string[]
          first_name?: string | null
          goal?: Database["public"]["Enums"]["fitness_goal"]
          health_connected?: boolean
          health_metrics?: string[]
          health_provider?: string | null
          height_cm?: number | null
          height_unit?: string
          id: string
          onboarding_completed?: boolean
          secondary_goals?: string[]
          sex?: string | null
          tdee_estimate?: number | null
          tdee_inputs?: Json | null
          tdee_method?: string | null
          training_days_per_week?: number | null
          training_experience?: string | null
          updated_at?: string
          weight_kg?: number | null
          weight_unit?: string
        }
        Update: {
          activity_level?: Database["public"]["Enums"]["activity_level"]
          allergies?: string[]
          avatar_url?: string | null
          avoided_foods?: string[]
          birth_date?: string | null
          body_fat_pct?: number | null
          created_at?: string
          daily_calorie_target?: number
          daily_carbs_target_g?: number
          daily_fat_target_g?: number
          daily_protein_target_g?: number
          daily_water_target_ml?: number
          diet_type?: string | null
          display_name?: string | null
          equipment?: string[]
          first_name?: string | null
          goal?: Database["public"]["Enums"]["fitness_goal"]
          health_connected?: boolean
          health_metrics?: string[]
          health_provider?: string | null
          height_cm?: number | null
          height_unit?: string
          id?: string
          onboarding_completed?: boolean
          secondary_goals?: string[]
          sex?: string | null
          tdee_estimate?: number | null
          tdee_inputs?: Json | null
          tdee_method?: string | null
          training_days_per_week?: number | null
          training_experience?: string | null
          updated_at?: string
          weight_kg?: number | null
          weight_unit?: string
        }
        Relationships: []
      }
      program_exercises: {
        Row: {
          created_at: string
          day_index: number
          day_label: string | null
          exercise_id: string | null
          id: string
          notes: string | null
          position: number
          program_id: string
          rest_seconds: number
          target_reps: string
          target_sets: number
          user_id: string
        }
        Insert: {
          created_at?: string
          day_index?: number
          day_label?: string | null
          exercise_id?: string | null
          id?: string
          notes?: string | null
          position?: number
          program_id: string
          rest_seconds?: number
          target_reps?: string
          target_sets?: number
          user_id: string
        }
        Update: {
          created_at?: string
          day_index?: number
          day_label?: string | null
          exercise_id?: string | null
          id?: string
          notes?: string | null
          position?: number
          program_id?: string
          rest_seconds?: number
          target_reps?: string
          target_sets?: number
          user_id?: string
        }
        Relationships: [
          {
            foreignKeyName: "program_exercises_exercise_id_fkey"
            columns: ["exercise_id"]
            isOneToOne: false
            referencedRelation: "exercises"
            referencedColumns: ["id"]
          },
          {
            foreignKeyName: "program_exercises_program_id_fkey"
            columns: ["program_id"]
            isOneToOne: false
            referencedRelation: "workout_programs"
            referencedColumns: ["id"]
          },
        ]
      }
      progress_entries: {
        Row: {
          arm_cm: number | null
          body_fat_pct: number | null
          chest_cm: number | null
          created_at: string
          hips_cm: number | null
          id: string
          notes: string | null
          photo_url: string | null
          recorded_on: string
          thigh_cm: number | null
          user_id: string
          waist_cm: number | null
          weight_kg: number | null
        }
        Insert: {
          arm_cm?: number | null
          body_fat_pct?: number | null
          chest_cm?: number | null
          created_at?: string
          hips_cm?: number | null
          id?: string
          notes?: string | null
          photo_url?: string | null
          recorded_on?: string
          thigh_cm?: number | null
          user_id: string
          waist_cm?: number | null
          weight_kg?: number | null
        }
        Update: {
          arm_cm?: number | null
          body_fat_pct?: number | null
          chest_cm?: number | null
          created_at?: string
          hips_cm?: number | null
          id?: string
          notes?: string | null
          photo_url?: string | null
          recorded_on?: string
          thigh_cm?: number | null
          user_id?: string
          waist_cm?: number | null
          weight_kg?: number | null
        }
        Relationships: []
      }
      reminders: {
        Row: {
          category: string
          created_at: string
          days_of_week: number[]
          enabled: boolean
          id: string
          notes: string | null
          time_of_day: string
          title: string
          updated_at: string
          user_id: string
        }
        Insert: {
          category?: string
          created_at?: string
          days_of_week?: number[]
          enabled?: boolean
          id?: string
          notes?: string | null
          time_of_day: string
          title: string
          updated_at?: string
          user_id: string
        }
        Update: {
          category?: string
          created_at?: string
          days_of_week?: number[]
          enabled?: boolean
          id?: string
          notes?: string | null
          time_of_day?: string
          title?: string
          updated_at?: string
          user_id?: string
        }
        Relationships: []
      }
      respiratory_rate_entries: {
        Row: {
          breaths_per_min: number
          context: string | null
          created_at: string
          id: string
          measured_at: string
          source: Database["public"]["Enums"]["data_source"]
          user_id: string
        }
        Insert: {
          breaths_per_min: number
          context?: string | null
          created_at?: string
          id?: string
          measured_at?: string
          source?: Database["public"]["Enums"]["data_source"]
          user_id: string
        }
        Update: {
          breaths_per_min?: number
          context?: string | null
          created_at?: string
          id?: string
          measured_at?: string
          source?: Database["public"]["Enums"]["data_source"]
          user_id?: string
        }
        Relationships: []
      }
      sleep_entries: {
        Row: {
          bedtime: string | null
          created_at: string
          id: string
          logged_on: string
          minutes: number
          notes: string | null
          quality: number | null
          source: Database["public"]["Enums"]["data_source"]
          updated_at: string
          user_id: string
          wake_time: string | null
        }
        Insert: {
          bedtime?: string | null
          created_at?: string
          id?: string
          logged_on?: string
          minutes?: number
          notes?: string | null
          quality?: number | null
          source?: Database["public"]["Enums"]["data_source"]
          updated_at?: string
          user_id: string
          wake_time?: string | null
        }
        Update: {
          bedtime?: string | null
          created_at?: string
          id?: string
          logged_on?: string
          minutes?: number
          notes?: string | null
          quality?: number | null
          source?: Database["public"]["Enums"]["data_source"]
          updated_at?: string
          user_id?: string
          wake_time?: string | null
        }
        Relationships: []
      }
      step_entries: {
        Row: {
          created_at: string
          id: string
          logged_on: string
          source: Database["public"]["Enums"]["data_source"]
          steps: number
          updated_at: string
          user_id: string
        }
        Insert: {
          created_at?: string
          id?: string
          logged_on?: string
          source?: Database["public"]["Enums"]["data_source"]
          steps?: number
          updated_at?: string
          user_id: string
        }
        Update: {
          created_at?: string
          id?: string
          logged_on?: string
          source?: Database["public"]["Enums"]["data_source"]
          steps?: number
          updated_at?: string
          user_id?: string
        }
        Relationships: []
      }
      tracker_goals: {
        Row: {
          created_at: string
          id: string
          period: string
          target: number
          tracker_key: string
          unit: string | null
          updated_at: string
          user_id: string
        }
        Insert: {
          created_at?: string
          id?: string
          period?: string
          target: number
          tracker_key: string
          unit?: string | null
          updated_at?: string
          user_id: string
        }
        Update: {
          created_at?: string
          id?: string
          period?: string
          target?: number
          tracker_key?: string
          unit?: string | null
          updated_at?: string
          user_id?: string
        }
        Relationships: []
      }
      tracker_prefs: {
        Row: {
          created_at: string
          enabled: boolean
          id: string
          pinned_home: boolean
          position: number
          tracker_key: string
          updated_at: string
          user_id: string
        }
        Insert: {
          created_at?: string
          enabled?: boolean
          id?: string
          pinned_home?: boolean
          position?: number
          tracker_key: string
          updated_at?: string
          user_id: string
        }
        Update: {
          created_at?: string
          enabled?: boolean
          id?: string
          pinned_home?: boolean
          position?: number
          tracker_key?: string
          updated_at?: string
          user_id?: string
        }
        Relationships: []
      }
      user_goals: {
        Row: {
          created_at: string
          current_value: number | null
          due_on: string | null
          id: string
          metric: string | null
          notes: string | null
          status: string
          target_value: number | null
          title: string
          unit: string | null
          updated_at: string
          user_id: string
        }
        Insert: {
          created_at?: string
          current_value?: number | null
          due_on?: string | null
          id?: string
          metric?: string | null
          notes?: string | null
          status?: string
          target_value?: number | null
          title: string
          unit?: string | null
          updated_at?: string
          user_id: string
        }
        Update: {
          created_at?: string
          current_value?: number | null
          due_on?: string | null
          id?: string
          metric?: string | null
          notes?: string | null
          status?: string
          target_value?: number | null
          title?: string
          unit?: string | null
          updated_at?: string
          user_id?: string
        }
        Relationships: []
      }
      water_logs: {
        Row: {
          amount_ml: number
          created_at: string
          id: string
          logged_on: string
          user_id: string
        }
        Insert: {
          amount_ml: number
          created_at?: string
          id?: string
          logged_on?: string
          user_id: string
        }
        Update: {
          amount_ml?: number
          created_at?: string
          id?: string
          logged_on?: string
          user_id?: string
        }
        Relationships: []
      }
      workout_programs: {
        Row: {
          created_at: string
          days_per_week: number
          description: string | null
          generated_by_ai: boolean
          goal: Database["public"]["Enums"]["fitness_goal"] | null
          id: string
          is_active: boolean
          name: string
          updated_at: string
          user_id: string
          weeks: number
        }
        Insert: {
          created_at?: string
          days_per_week?: number
          description?: string | null
          generated_by_ai?: boolean
          goal?: Database["public"]["Enums"]["fitness_goal"] | null
          id?: string
          is_active?: boolean
          name: string
          updated_at?: string
          user_id: string
          weeks?: number
        }
        Update: {
          created_at?: string
          days_per_week?: number
          description?: string | null
          generated_by_ai?: boolean
          goal?: Database["public"]["Enums"]["fitness_goal"] | null
          id?: string
          is_active?: boolean
          name?: string
          updated_at?: string
          user_id?: string
          weeks?: number
        }
        Relationships: []
      }
      workout_sessions: {
        Row: {
          calories_burned: number | null
          completed_at: string | null
          created_at: string
          duration_seconds: number | null
          id: string
          notes: string | null
          perceived_effort: number | null
          performed_on: string
          program_id: string | null
          started_at: string | null
          title: string | null
          updated_at: string
          user_id: string
        }
        Insert: {
          calories_burned?: number | null
          completed_at?: string | null
          created_at?: string
          duration_seconds?: number | null
          id?: string
          notes?: string | null
          perceived_effort?: number | null
          performed_on?: string
          program_id?: string | null
          started_at?: string | null
          title?: string | null
          updated_at?: string
          user_id: string
        }
        Update: {
          calories_burned?: number | null
          completed_at?: string | null
          created_at?: string
          duration_seconds?: number | null
          id?: string
          notes?: string | null
          perceived_effort?: number | null
          performed_on?: string
          program_id?: string | null
          started_at?: string | null
          title?: string | null
          updated_at?: string
          user_id?: string
        }
        Relationships: [
          {
            foreignKeyName: "workout_sessions_program_id_fkey"
            columns: ["program_id"]
            isOneToOne: false
            referencedRelation: "workout_programs"
            referencedColumns: ["id"]
          },
        ]
      }
      workout_set_logs: {
        Row: {
          created_at: string
          duration_seconds: number | null
          exercise_id: string | null
          exercise_name: string
          form_score: number | null
          id: string
          is_warmup: boolean
          reps: number | null
          session_id: string
          set_number: number
          user_id: string
          weight_kg: number | null
        }
        Insert: {
          created_at?: string
          duration_seconds?: number | null
          exercise_id?: string | null
          exercise_name: string
          form_score?: number | null
          id?: string
          is_warmup?: boolean
          reps?: number | null
          session_id: string
          set_number?: number
          user_id: string
          weight_kg?: number | null
        }
        Update: {
          created_at?: string
          duration_seconds?: number | null
          exercise_id?: string | null
          exercise_name?: string
          form_score?: number | null
          id?: string
          is_warmup?: boolean
          reps?: number | null
          session_id?: string
          set_number?: number
          user_id?: string
          weight_kg?: number | null
        }
        Relationships: [
          {
            foreignKeyName: "workout_set_logs_exercise_id_fkey"
            columns: ["exercise_id"]
            isOneToOne: false
            referencedRelation: "exercises"
            referencedColumns: ["id"]
          },
          {
            foreignKeyName: "workout_set_logs_session_id_fkey"
            columns: ["session_id"]
            isOneToOne: false
            referencedRelation: "workout_sessions"
            referencedColumns: ["id"]
          },
        ]
      }
    }
    Views: {
      [_ in never]: never
    }
    Functions: {
      [_ in never]: never
    }
    Enums: {
      activity_level:
        | "sedentary"
        | "light"
        | "moderate"
        | "active"
        | "very_active"
      ai_interaction_kind:
        | "coach_chat"
        | "meal_scan"
        | "form_analysis"
        | "insight"
        | "plan_generation"
      data_source: "manual" | "device" | "ai"
      fitness_goal:
        | "lose_fat"
        | "maintain"
        | "build_muscle"
        | "recomp"
        | "performance"
      glucose_unit: "mg_dl" | "mmol_l"
      meal_type: "breakfast" | "lunch" | "dinner" | "snack"
      medicine_status: "taken" | "missed" | "skipped"
    }
    CompositeTypes: {
      [_ in never]: never
    }
  }
}

type DatabaseWithoutInternals = Omit<Database, "__InternalSupabase">

type DefaultSchema = DatabaseWithoutInternals[Extract<keyof Database, "public">]

export type Tables<
  DefaultSchemaTableNameOrOptions extends
    | keyof (DefaultSchema["Tables"] & DefaultSchema["Views"])
    | { schema: keyof DatabaseWithoutInternals },
  TableName extends DefaultSchemaTableNameOrOptions extends {
    schema: keyof DatabaseWithoutInternals
  }
    ? keyof (DatabaseWithoutInternals[DefaultSchemaTableNameOrOptions["schema"]]["Tables"] &
        DatabaseWithoutInternals[DefaultSchemaTableNameOrOptions["schema"]]["Views"])
    : never = never,
> = DefaultSchemaTableNameOrOptions extends {
  schema: keyof DatabaseWithoutInternals
}
  ? (DatabaseWithoutInternals[DefaultSchemaTableNameOrOptions["schema"]]["Tables"] &
      DatabaseWithoutInternals[DefaultSchemaTableNameOrOptions["schema"]]["Views"])[TableName] extends {
      Row: infer R
    }
    ? R
    : never
  : DefaultSchemaTableNameOrOptions extends keyof (DefaultSchema["Tables"] &
        DefaultSchema["Views"])
    ? (DefaultSchema["Tables"] &
        DefaultSchema["Views"])[DefaultSchemaTableNameOrOptions] extends {
        Row: infer R
      }
      ? R
      : never
    : never

export type TablesInsert<
  DefaultSchemaTableNameOrOptions extends
    | keyof DefaultSchema["Tables"]
    | { schema: keyof DatabaseWithoutInternals },
  TableName extends DefaultSchemaTableNameOrOptions extends {
    schema: keyof DatabaseWithoutInternals
  }
    ? keyof DatabaseWithoutInternals[DefaultSchemaTableNameOrOptions["schema"]]["Tables"]
    : never = never,
> = DefaultSchemaTableNameOrOptions extends {
  schema: keyof DatabaseWithoutInternals
}
  ? DatabaseWithoutInternals[DefaultSchemaTableNameOrOptions["schema"]]["Tables"][TableName] extends {
      Insert: infer I
    }
    ? I
    : never
  : DefaultSchemaTableNameOrOptions extends keyof DefaultSchema["Tables"]
    ? DefaultSchema["Tables"][DefaultSchemaTableNameOrOptions] extends {
        Insert: infer I
      }
      ? I
      : never
    : never

export type TablesUpdate<
  DefaultSchemaTableNameOrOptions extends
    | keyof DefaultSchema["Tables"]
    | { schema: keyof DatabaseWithoutInternals },
  TableName extends DefaultSchemaTableNameOrOptions extends {
    schema: keyof DatabaseWithoutInternals
  }
    ? keyof DatabaseWithoutInternals[DefaultSchemaTableNameOrOptions["schema"]]["Tables"]
    : never = never,
> = DefaultSchemaTableNameOrOptions extends {
  schema: keyof DatabaseWithoutInternals
}
  ? DatabaseWithoutInternals[DefaultSchemaTableNameOrOptions["schema"]]["Tables"][TableName] extends {
      Update: infer U
    }
    ? U
    : never
  : DefaultSchemaTableNameOrOptions extends keyof DefaultSchema["Tables"]
    ? DefaultSchema["Tables"][DefaultSchemaTableNameOrOptions] extends {
        Update: infer U
      }
      ? U
      : never
    : never

export type Enums<
  DefaultSchemaEnumNameOrOptions extends
    | keyof DefaultSchema["Enums"]
    | { schema: keyof DatabaseWithoutInternals },
  EnumName extends DefaultSchemaEnumNameOrOptions extends {
    schema: keyof DatabaseWithoutInternals
  }
    ? keyof DatabaseWithoutInternals[DefaultSchemaEnumNameOrOptions["schema"]]["Enums"]
    : never = never,
> = DefaultSchemaEnumNameOrOptions extends {
  schema: keyof DatabaseWithoutInternals
}
  ? DatabaseWithoutInternals[DefaultSchemaEnumNameOrOptions["schema"]]["Enums"][EnumName]
  : DefaultSchemaEnumNameOrOptions extends keyof DefaultSchema["Enums"]
    ? DefaultSchema["Enums"][DefaultSchemaEnumNameOrOptions]
    : never

export type CompositeTypes<
  PublicCompositeTypeNameOrOptions extends
    | keyof DefaultSchema["CompositeTypes"]
    | { schema: keyof DatabaseWithoutInternals },
  CompositeTypeName extends PublicCompositeTypeNameOrOptions extends {
    schema: keyof DatabaseWithoutInternals
  }
    ? keyof DatabaseWithoutInternals[PublicCompositeTypeNameOrOptions["schema"]]["CompositeTypes"]
    : never = never,
> = PublicCompositeTypeNameOrOptions extends {
  schema: keyof DatabaseWithoutInternals
}
  ? DatabaseWithoutInternals[PublicCompositeTypeNameOrOptions["schema"]]["CompositeTypes"][CompositeTypeName]
  : PublicCompositeTypeNameOrOptions extends keyof DefaultSchema["CompositeTypes"]
    ? DefaultSchema["CompositeTypes"][PublicCompositeTypeNameOrOptions]
    : never

export const Constants = {
  public: {
    Enums: {
      activity_level: [
        "sedentary",
        "light",
        "moderate",
        "active",
        "very_active",
      ],
      ai_interaction_kind: [
        "coach_chat",
        "meal_scan",
        "form_analysis",
        "insight",
        "plan_generation",
      ],
      data_source: ["manual", "device", "ai"],
      fitness_goal: [
        "lose_fat",
        "maintain",
        "build_muscle",
        "recomp",
        "performance",
      ],
      glucose_unit: ["mg_dl", "mmol_l"],
      meal_type: ["breakfast", "lunch", "dinner", "snack"],
      medicine_status: ["taken", "missed", "skipped"],
    },
  },
} as const
