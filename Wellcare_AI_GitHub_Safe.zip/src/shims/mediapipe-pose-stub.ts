/**
 * Stub for `@mediapipe/pose`.
 *
 * `@tensorflow-models/pose-detection` statically imports `{ Pose }` from
 * `@mediapipe/pose` at the top of its ESM bundle, but that package ships a
 * UMD script with no ESM named exports, which breaks the Vite 8 / Rolldown
 * build. Coach Cam uses MoveNet through the TF.js runtime only, so the
 * MediaPipe solution is never constructed — this stub only satisfies the
 * bundler.
 */
export class Pose {
  constructor() {
    throw new Error(
      "@mediapipe/pose is not available in this build; use the MoveNet (tfjs) runtime instead.",
    );
  }
}

export const VERSION = "stub";
export default { Pose, VERSION };
